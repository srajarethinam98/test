import { setMessageInfo, setMessageNotify, setMessageType } from "../base/reducer/alertReducer";
import {
    setEmailErrorMessage,
    setNameErrorMessage,
    setPasswordErrorMessage,
    setEditPasswordErrorMessage,
    setMobileErrorMessage,
    setProjectErrorMessage,
    setAlternateMobileErrorMessage,
    setAreaOfCurrentResidentErrorMessage,
    setHowDidYouKnowAboutUsErrorMessage,
    setPreferredBudgetErrorMessage,
    setPreferredUnitsErrorMessage,
    setLeadIdErrorMessage,
    setStatusErrorMessage,
    setFlsErrorMessage,
    setFlsTlErrorMessage,
    setFirstNameErrorMessage,
    setLastNameErrorMessage,
    setUserMobileErrorMessage,
    setUserRoleErrorMessage,
    setDepartmentNameErrorMessage,
    setRoleNameErrorMessage,
    setOccupationErrorMessage,
    setPreferredUnitErrorMessage,
    setProjectNameErrorMessage,
    setPurposeOfPurchaseErrorMessage,
    setStatusNameErrorMessage,
    setknowAboutUsErrorMessage,
    setMaxPreferredSizeErrorMessage,
    setMaxBudgetErrorMessage,
    setMinBudgetErrorMessage,
    setMaxAgeErrorMessage,
    setMinAgeErrorMessage,
    setMinPreferredSizeErrorMessage,
    setTlErrorMessage,
    setSvcErrorMessage,
    setSalesRoleErrorMessage,
    setRemarks,
    setSocialMediaErrorMessage,
    setPartnerNameErrorMessage,
    setEmpNameErrorMessage,
    setEmpIdErrorMessage,
    setContactErrorMessage,
    setRefProjectErrorMessage,
    setLabelErrorMessage,
    setDescriptionErrorMessage,
    setUnitNoErrorMessage,
    setPurposeOfVisitErrorMessage,
    setQuestionErrorMessage,
    setOptionErrors,
    setMultipleSelectionErrorMessage,
    setSingleSelectionErrorMessage,
    setAnswerErrorMessage,
    setDropdownErrorMessage,
    setRatingErrorMessage,
    setQuestionTypeErrorMessage,
    setZoneErrorMessage,
    setLeadOwnerErrorMessage,
    setLeadTypeErrorMessage
} from "../base/reducer/errorMessageReducer";

import messages from '../constants/messageConstants'
import { regex } from "../constants/regexConstants";

export const isAuthorized = () => {
    let token = localStorage.getItem('cw-token')
    return token ? true : false
}

export const doValidateEmailOrName = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ')) {
            dispatch(setNameErrorMessage(''));
            return true;
        }
        dispatch(setNameErrorMessage(` Email or User Name ${messages.startsWithSpace}`));
        return false;
    } else {
        dispatch(setNameErrorMessage(`${messages.emptyField} Email or User Name`));
    }
}

export const doNotify = (type: any, message: any, dispatch: any) => {
    dispatch(setMessageNotify(true))
    dispatch(setMessageInfo(message))
    dispatch(setMessageType(type))
}

export const doValidateEmail = (fieldValue: any, dispatch: any) => {
    if (fieldValue?.trim()) {
        if (regex.emailRegex.test(fieldValue)) {
            dispatch(setEmailErrorMessage(''));
            return true;
        } else {
            dispatch(setEmailErrorMessage(messages.invalidEmail));
        }
    } else {
        dispatch(setEmailErrorMessage(`${messages.emptyField} email`));
    }
}

export const doValidatePassword = (fieldValue: any, dispatch: any) => {
    if (fieldValue?.trim()) {
        if (fieldValue.length >= 8) {
            dispatch(setPasswordErrorMessage(""));
            return true;
        } else {
            dispatch(setPasswordErrorMessage(messages?.invalidPassword));
        }
    } else {
        dispatch(setPasswordErrorMessage((`${messages.emptyField} password`)));
    }
}
export const doValidateEditPassword = (fieldValue: any, dispatch: any) => {
    if (fieldValue?.trim()) {
        if (fieldValue.length >= 8) {
            dispatch(setEditPasswordErrorMessage(""));
            return true;
        } else {
            dispatch(setEditPasswordErrorMessage(messages?.invalidPassword));
            return false;
        }
    } 
    else {
        // Do not validate if the field is empty
        dispatch(setEditPasswordErrorMessage(""));
        return true;
    }
};



export const doValidateProject = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setProjectErrorMessage(''));
        return true;
    } else {
        dispatch(setProjectErrorMessage(`${messages.select} Project`));
        return false;
    }
}

export const doValidatefullName = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.spString.test(fieldValue) ) {
            dispatch(setNameErrorMessage(''));
            return true;
        }
        dispatch(setNameErrorMessage(`Name ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setNameErrorMessage(`${messages.emptyField} Name`));
    }
}
export const doValidateAreaOfCurrentResident = (fieldValue: any, dispatch: any) => {
    if (fieldValue && !fieldValue.startsWith(' ')) {
        dispatch(setAreaOfCurrentResidentErrorMessage(''));
        return true;
    } else if (fieldValue && fieldValue.startsWith(' ')) {
        dispatch(setAreaOfCurrentResidentErrorMessage(`Area Of Current Resident ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setAreaOfCurrentResidentErrorMessage(`${messages.emptyField} Area Of Current Resident`));
        return false;
    }
}

// export const doValidateAreaOfCurrentResident = (fieldValue: any, dispatch: any) => {
//     if (fieldValue) {
//         dispatch(setAreaOfCurrentResidentErrorMessage(''));
//         return true;
//     } else {
//         dispatch(setAreaOfCurrentResidentErrorMessage(`${messages.select} Area Of Current Resident`));
//     }
// }

// export const doValidateMobileNumber = (fieldValue: any, dispatch: any) => {
//     if (fieldValue) {
//         if (regex.mobileRegex.test(fieldValue)) {
//             dispatch(setMobileErrorMessage(''));

//             return true;
//         } else {
//             dispatch(setMobileErrorMessage(messages.invalidMobile));
//         }
//     } else {
//         dispatch(setMobileErrorMessage(`${messages.emptyField} Mobile Number`));
//     }
// };
export const doValidateMobileNumber = (fieldValue: any, dispatch: any, selectedCountryCode: any) => {
    let phoneLength = selectedCountryCode?.phoneLength || 10; // set default value to 10 if selectedCountryCode is null or undefined
    let isArray = Array.isArray(phoneLength);
    let mobileRegex = new RegExp("^\\d{" + phoneLength + "}$");
    if (fieldValue) {
        if (isArray) {
            if (regex.numericRegex.test(fieldValue) && phoneLength.includes(fieldValue.length)) {
                dispatch(setMobileErrorMessage(''));
                return true;
            } else {
                dispatch(setMobileErrorMessage(`Mobile No should be ${phoneLength.join(" or ")} numeric digits`))
            }
        } else {
            if (mobileRegex.test(fieldValue)) {
                dispatch(setMobileErrorMessage(''));
                return true;
            } else {
                dispatch(setMobileErrorMessage(`Mobile No should contain ${phoneLength} digits`))
            }
        }
    } else {
        dispatch(setMobileErrorMessage(`${messages.emptyField} Mobile Number`));
    }
    return false;
};


// export const doValidateAlternateMobileNumber = (fieldValue: any, dispatch: any) => {
//         if (fieldValue === '') {
//             dispatch(setAlternateMobileErrorMessage(''));
//         }
//         else if (fieldValue) {
//         if (regex.mobileRegex.test(fieldValue)) {
//             dispatch(setAlternateMobileErrorMessage(''));

//             return true;
//         } else {
//             dispatch(setAlternateMobileErrorMessage(messages.invalidMobile));
//         }
//     }
// };

export const doValidateAlternateMobileNumber = (fieldValue: any, dispatch: any, selectedCountryCode: any) => {
    let phoneLength = selectedCountryCode?.phoneLength || 10;
    let isArray = Array.isArray(phoneLength);
    let mobileRegex = new RegExp("^\\d{" + phoneLength + "}$");
    
    if (fieldValue === ''|| !fieldValue) {
        dispatch(setAlternateMobileErrorMessage(''));
        return true;
        } else if (fieldValue) {
        if (isArray) {
            if (regex.numericRegex.test(fieldValue) && phoneLength.includes(fieldValue.length)) {
            dispatch(setAlternateMobileErrorMessage(''));
            return true;
            } else {
            dispatch(setAlternateMobileErrorMessage(`Alternate Mobile No should be ${phoneLength.join(" or ")} numeric digits`));
            return false;
            }
        } else {
            if (mobileRegex.test(fieldValue)) {
            dispatch(setAlternateMobileErrorMessage(''));
            return true;
            } else {
            dispatch(setAlternateMobileErrorMessage(`Alternate Mobile No should contain ${phoneLength} digits`));
            return false;
            }
        }
        } else {
        dispatch(setAlternateMobileErrorMessage(`${messages.emptyField} Alternate Mobile Number`));
        return false;
    }
  };
  

export const doValidatePreferredUnits = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setProjectErrorMessage(''));
        return true;
    } else {
        dispatch(setPreferredUnitsErrorMessage(`${messages.select} Preferred Units`));
    }
}


export const doValidatePreferredBudgetRange = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setPreferredBudgetErrorMessage(''));
        return true;
    } else {
        dispatch(setPreferredBudgetErrorMessage(`${messages.select} Preferred Budget Range`));
    }
}

export const doValidateLeadId = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setLeadIdErrorMessage(''));
        return true;
    } else {
        dispatch(setLeadIdErrorMessage(`${messages.emptyField} Lead Id`));
    }
}
export const doValidateHowDidYouKnowAboutUs = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setHowDidYouKnowAboutUsErrorMessage(''));
        return true;
    } else {
        dispatch(setHowDidYouKnowAboutUsErrorMessage(`${messages.select} How you know`));
    }
}
export const doValidateLeadOwner = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setLeadOwnerErrorMessage(''));
        return true;
    } else {
        dispatch(setLeadOwnerErrorMessage(`${messages.select} Lead Owner Email`));
    }
}
export const doValidateLeadType = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setLeadTypeErrorMessage(''));
        return true;
    } else {
        dispatch(setLeadTypeErrorMessage(`${messages.select} Lead Owner Type`));
    }
}



export const doValidateStatus = (fieldValue: any, dispatch: any) => {
    // Allow empty status value
    dispatch(setStatusErrorMessage(''));
    return true;
};


export const doValidateFls = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setFlsErrorMessage(''));
        return true;
    } else {
        dispatch(setFlsErrorMessage(`${messages.select} FLS`));
    }
}

export const doValidateFlsTL = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setFlsTlErrorMessage(''));
        return true;
    } else {
        dispatch(setFlsTlErrorMessage(`${messages.select} FLS TL`));
    }
}

export const doValidateFirstName = (fieldValue: any, dispatch: any) => {

    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setFirstNameErrorMessage(''));
            return true;
        }
        dispatch(setFirstNameErrorMessage(`First Name ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setFirstNameErrorMessage(`${messages.emptyField} First Name`));
    }
}

export const doValidateLatName = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setLastNameErrorMessage(''));
            return true;
        }
        dispatch(setLastNameErrorMessage(`Last Name ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setLastNameErrorMessage(`${messages.emptyField} Last Name`));
    }
}

export const doValidateUserMobileNumber = (fieldValue: any, dispatch: any) => {

    if (fieldValue) {
        if (regex.mobileRegex.test(fieldValue)) {
            dispatch(setUserMobileErrorMessage(''));
            return true;
        } else {
            dispatch(setUserMobileErrorMessage(messages.invalidMobile));
        }
    } else {
        dispatch(setUserMobileErrorMessage(''));
        return true
    }
};


export const doValidateUserRole = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setUserRoleErrorMessage(''));
        return true;
    } else {
        dispatch(setUserRoleErrorMessage(`${messages.select} User Role`));
    }
}

export const doValidateRoleName = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ')  && regex.commonRegex.test(fieldValue)) {
            dispatch(setRoleNameErrorMessage(''));
            return true;
        }
        dispatch(setRoleNameErrorMessage(`Role Name ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setRoleNameErrorMessage(`${messages.emptyField} Role Name`));
    }
}

export const doValidateDepartmentName = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setDepartmentNameErrorMessage(''));
            return true;
        }
        dispatch(setDepartmentNameErrorMessage(`Department Name ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setDepartmentNameErrorMessage(`${messages.emptyField} Department Name`));
    }
}

export const doValidateOccupationName = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setOccupationErrorMessage(''));
            return true;
        }
        dispatch(setOccupationErrorMessage(`Occupation ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setOccupationErrorMessage(`${messages.emptyField} Occupation`));
    }
}

export const doValidateMinAge = (fieldValue: any, dispatch: any) => {
    if (!fieldValue && !regex.commonRegex.test(fieldValue)) {
        dispatch(setMinAgeErrorMessage(`${messages.emptyField} Min Age`));
        return false;
    }
    const age = parseInt(fieldValue, 10);
    if (regex.commonRegex.test(fieldValue) && age <= 100) {
        dispatch(setMinAgeErrorMessage(''));
        return true;
    }
    dispatch(setMinAgeErrorMessage(`Min Age ${messages.numeric} and must be between 0 to 100 yrs`));
    return false;
}

export const doValidateMaxAge = (fieldValue:any, min:any, dispatch:any) => {
    const numericPart = fieldValue.match(regex.commonRegex
    );

    if (fieldValue) {
        if (numericPart) {
            const age = parseInt(numericPart[0], 10);
            const minAge = parseInt(min, 10);
            if (age > 0 && age <= 100 && age > minAge) {
                dispatch(setMaxAgeErrorMessage(''));
                return true;
            }
            dispatch(setMaxAgeErrorMessage(`Max Age should be greater than min age and in between 0 to 100 yrs`));
        } else {
            dispatch(setMaxAgeErrorMessage(`${messages.numeric} Max Age`));
        }
    } else {
        dispatch(setMaxAgeErrorMessage(`${messages.emptyField} Max Age`));
    }
    return false
}

export const doValidateMinBudget = (fieldValue: any, dispatch: any) => {

    if (fieldValue) {
        if (regex.numericRegex.test(fieldValue) || regex.commonRegex.test(fieldValue)) {
            dispatch(setMinBudgetErrorMessage(''));
            return true;
        }
        dispatch(setMinBudgetErrorMessage(`Min Budget ${messages.alphanumeric}`));
        return false;
    } else {
        dispatch(setMinBudgetErrorMessage(`${messages.emptyField} Min Budget`));
    }
}

export const doValidateMaxBudget = (fieldValue: any, min: any, dispatch: any) => {
    if (fieldValue) {
        if (regex.commonRegex.test(fieldValue) /*&& parseInt(fieldValue) > 0*/) {
            if (parseInt(fieldValue) > parseInt(min)) {
            dispatch(setMaxBudgetErrorMessage(''));
            return true;
            }
            dispatch(setMaxBudgetErrorMessage('Max Budget should be greater than Min Budget'));
            return false;
        }
        dispatch(setMaxBudgetErrorMessage(`Max Budget ${messages.alphanumeric}`));
        return false;
        } else {
        dispatch(setMaxBudgetErrorMessage(`${messages.emptyField} Max Budget`));
        return false;
        }
    };

export const doValidateMinPreferredSize = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (regex.numericRegex.test(fieldValue) || regex.commonRegex.test(fieldValue)) {
            dispatch(setMinPreferredSizeErrorMessage(''));
            return true;
        }
        dispatch(setMinPreferredSizeErrorMessage(`Min Preferred Size ${messages.alphanumeric}`));
        return false;
    } else {
        dispatch(setMinPreferredSizeErrorMessage(`${messages.emptyField} Min Preferred Size`));
    }

}

export const doValidateMaxPreferredSize = (fieldValue: any, min: any, dispatch: any) => {
    if (fieldValue) {
        if (regex.commonRegex.test(fieldValue) /*&& parseInt(fieldValue) > 0*/) {
            if (parseInt(fieldValue) > parseInt(min)) {
                dispatch(setMaxPreferredSizeErrorMessage(''));
                return true;
            }
            dispatch(setMaxPreferredSizeErrorMessage(`Max Preferred Size should be greater than Min Preferred Size`));
            return false;
        } else {
            dispatch(setMaxPreferredSizeErrorMessage(`Max Preferred Size ${messages.alphanumeric}`));
            return false;
        }

    } else {
        dispatch(setMaxPreferredSizeErrorMessage(`${messages.emptyField} Max Preferred Size`));
    }

}

export const doValidatepreferredUnit = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setPreferredUnitErrorMessage(''));
            return true;
        }
        dispatch(setPreferredUnitErrorMessage(`Unit should be positive numeric and not start with space`));
        return false;
    } else {
        dispatch(setPreferredUnitErrorMessage(`${messages.emptyField} Preferred Unit`));
    }
}

export const doValidateProjectName = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setProjectNameErrorMessage(''));
            return true;
        }
        dispatch(setProjectNameErrorMessage(`Project Name ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setProjectNameErrorMessage(`${messages.emptyField} Occupation Name`));
    }
}

export const doValidatePurposeOfPurchase = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setPurposeOfPurchaseErrorMessage(''));
            return true;
        }
        dispatch(setPurposeOfPurchaseErrorMessage(`Purpose Of Purchase ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setPurposeOfPurchaseErrorMessage(`${messages.emptyField} Purpose Of Purchase`));
    }
}

export const doValidateKnowAboutUs = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setknowAboutUsErrorMessage(''));
            return true;
        }
        dispatch(setknowAboutUsErrorMessage(`Source Of Info ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setknowAboutUsErrorMessage(`${messages.emptyField} Source Of Info`));
    }
}

export const doValidateStatusName = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ')) {
            dispatch(setStatusNameErrorMessage(''));
            return true;
        }
        dispatch(setStatusNameErrorMessage(`Status ${messages.startsWithSpace}`));
        return false;
    } else {
        dispatch(setStatusNameErrorMessage(`${messages.emptyField} Status`));
    }
}


export const doValidateTl = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setTlErrorMessage(''));
        return true;
    } else {
        dispatch(setTlErrorMessage(`${messages.select} TL`));
    }
}

export const doValidateSvc = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setSvcErrorMessage(''));
        return true;
    } else {
        dispatch(setSvcErrorMessage(`${messages.select} SVC`));
    }
}

export const doValidateSalesRole = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setSalesRoleErrorMessage(''));
        return true;
    } else {
        dispatch(setSalesRoleErrorMessage(`${messages.select} Sales Role`));
    }
}
export const doValidateEmployeeEmail = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setEmailErrorMessage(''));
        return true;
    } else {
        dispatch(setEmailErrorMessage(`${messages.select} Email`));
    }
} 
export const doValidateRemarks = (fieldValue: any, dispatch: any) => {
    if (!fieldValue) {
        dispatch(setRemarks(`${messages.emptyField} remarks`));
        return false;
    } else {
        dispatch(setRemarks(''));
        return true;
    }
}

export const doValidateSocialMedia = (fieldValue: any, dispatch: any) => {

    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setSocialMediaErrorMessage(''));
            return true;
        }
        dispatch(setSocialMediaErrorMessage(`Social Media Name ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setSocialMediaErrorMessage(`${messages.emptyField} Social Media Name`));
    }
}
export const doValidatePartnerName = (fieldValue: any, dispatch: any) => {
    if (fieldValue === '') {
        dispatch(setPartnerNameErrorMessage(''));
    }
    else if (fieldValue) {
    if (regex.commonRegex.test(fieldValue)) {
        dispatch(setPartnerNameErrorMessage(''));

        return true;
    } else {
        dispatch(setPartnerNameErrorMessage(messages.startsWithSpaceAndString));
    }
}
}

export const doValidateEmpName = (fieldValue: any, dispatch: any) => {

    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setEmpNameErrorMessage(''));
            return true;
        }
        dispatch(setEmpNameErrorMessage(`refferred Employee Name ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setEmpNameErrorMessage(`${messages.emptyField} refferred employee Name`));
    }
}

export const doValidateEmpId = (fieldValue: any, dispatch: any) => {
    if (fieldValue === '') {
        dispatch(setEmpIdErrorMessage(''));
        return true;
    }
    else if (fieldValue) {
    if (regex.commonRegex.test(fieldValue)) {
        dispatch(setEmpIdErrorMessage(''));
        return true;
    } else {
        dispatch(setEmpIdErrorMessage(messages.startsWithSpaceAndString));
        return false;
    }
}
}
export const doValidateLabel = (fieldValue: any, dispatch: any, isMandatory: boolean) => {
    if (isMandatory === false) {
        if (fieldValue === '' || fieldValue === null || fieldValue === undefined) {
            dispatch(setLabelErrorMessage(''));
            return true;
        } else if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setLabelErrorMessage(''));
            return true;
        } else {
            dispatch(setLabelErrorMessage(`Label ${messages.startsWithSpaceAndString}`));
            return false;
        }
    } else if (isMandatory) {
        if (fieldValue && !fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setLabelErrorMessage(''));
            return true;
        } else if (fieldValue) {
            dispatch(setLabelErrorMessage(`Label ${messages.startsWithSpaceAndString}`));
            return false;
        } else {
            dispatch(setLabelErrorMessage(`${messages.emptyField} Label`));
            return false;
        }
    }
};

export const doValidateDescription = (fieldValue: any, dispatch: any) => {
        if (fieldValue === '' || !fieldValue) {
            dispatch(setDescriptionErrorMessage(''));
            return true;
        } else if (regex.commonRegex.test(fieldValue)) {
            dispatch(setDescriptionErrorMessage(''));
            return true;
        } else {
            dispatch(setDescriptionErrorMessage(`Description ${messages.startsWithSpaceAndString}`));
            return false;
        }
};

export const doValidatePurposeOfVisit = (fieldValue: any, dispatch: any) => {

    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setPurposeOfVisitErrorMessage(''));
            return true;
        }
        dispatch(setPurposeOfVisitErrorMessage(`PurposeOfVisit ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setPurposeOfVisitErrorMessage(`${messages.emptyField} PurposeOfVisit`));
    }
}


// export const doValidateContactNumber = (fieldValue: any, dispatch: any) => {
//     if (fieldValue) {
//         if (regex.mobileRegex.test(fieldValue)) {
//             dispatch(setContactErrorMessage(''));

//             return true;
//         } else {
//             dispatch(setContactErrorMessage(messages.invalidMobile));
//         }
//     } else {
//         dispatch(setContactErrorMessage(`${messages.emptyField} Contact Number`));
//     }
// };

export const doValidateContactNumber = (fieldValue: any, dispatch: any, selectedCountryCode: any) => {
    let phoneLength = selectedCountryCode?.phoneLength || 10;
    let isArray = Array.isArray(phoneLength);
    let mobileRegex = new RegExp("^\\d{" + phoneLength + "}$");
  
    if (fieldValue === '') {
      dispatch(setContactErrorMessage('Contact No is required'));
    } else if (fieldValue) {
      if (isArray) {
        if (regex.mobileRegex.test(fieldValue) && phoneLength.includes(fieldValue.length)) {
          dispatch(setContactErrorMessage(''));
          return true;
        } else {
          dispatch(setContactErrorMessage(`Contact No should be ${phoneLength.join(" or ")} numeric digits`));
        }
      } else {
        if (mobileRegex.test(fieldValue)) {
          dispatch(setContactErrorMessage(''));
          return true;
        } else {
          dispatch(setContactErrorMessage(`Contact No should contain ${phoneLength} digits`));
        }
      }
    } else {
      dispatch(setContactErrorMessage('Contact No is required'));
    }
  };
  

export const doValidateRefProject = (fieldValue: any, dispatch: any) => {
    if (fieldValue === '') {
        dispatch(setRefProjectErrorMessage(''));
        return true;
    } else if (fieldValue && regex.commonRegex.test(fieldValue)) {
        dispatch(setRefProjectErrorMessage(''));
        return true;
    } else if (fieldValue) {
        dispatch(setRefProjectErrorMessage(`Project Name ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setRefProjectErrorMessage(`${messages.emptyField} Project Name`));
        return false;
    }
}
export const doValidateUnitNo = (fieldValue: any, dispatch: any, isMandatory: boolean) => {
    if (isMandatory === false) {
        if (fieldValue === '' || fieldValue === null || fieldValue === undefined) {
            dispatch(setUnitNoErrorMessage(''));
            return true;
        } else if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setUnitNoErrorMessage(''));
            return true;
        } else {
            dispatch(setUnitNoErrorMessage(`Unit No ${messages.startsWithSpaceAndString}`));
            return false;
        }
    } else if (isMandatory) {
        if (fieldValue && !fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setUnitNoErrorMessage(''));
            return true;
        } else if (fieldValue) {
            dispatch(setUnitNoErrorMessage(`Unit No ${messages.startsWithSpaceAndString}`));
            return false;
        } else {
            dispatch(setUnitNoErrorMessage(`${messages.emptyField} Unit No`));
            return false;
        }
    }
};

export const convertToNumeric: (input: string) => number | null = (input: string) => {
    const lakhsFactor = 100000;
    const croresFactor = 10000000;

    const cleanedInput = input.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

    if (cleanedInput.endsWith('l')) {
        const numericValue = parseInt(cleanedInput);
        if (!isNaN(numericValue)) {
            return numericValue * lakhsFactor;
        }
    }

    if (cleanedInput.endsWith('cr')) {
        const numericValue = parseInt(cleanedInput);
        if (!isNaN(numericValue)) {
            return numericValue * croresFactor;
        }
    }

    return null;
};
// Customer Review


export const doValidateQuestion = (fieldValue: any, dispatch: any) => {

    if (fieldValue) {
        if (!fieldValue.startsWith(' ')) {
            dispatch(setQuestionErrorMessage(''));
            return true;
        }
        dispatch(setQuestionErrorMessage(`Question ${messages.startsWithSpaceAndString}`));
        return false;
    } else {
        dispatch(setQuestionErrorMessage(`${messages.emptyField} Question`));
    }
}

export const doValidateOption = (optionValue: string, index: number, dispatch: any, optionErrors: string[], setOptionErrors: any) => {
    if (optionValue) {
        if (!optionValue.startsWith(' ')) {
            const newOptionErrors = [...optionErrors];
            newOptionErrors[index] = '';
            setOptionErrors(newOptionErrors);
            return true;
        }
        const newOptionErrors = [...optionErrors];
        newOptionErrors[index] = `Option ${index + 1} ${messages.startsWithSpaceAndString}`;
        setOptionErrors(newOptionErrors);
        return false;
    } else {
        const newOptionErrors = [...optionErrors];
        newOptionErrors[index] = `${messages.emptyField} Option ${index + 1}`;
        setOptionErrors(newOptionErrors);
    }
};
// Dropdown validation
export const doValidateQuestionType = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setQuestionTypeErrorMessage(''));
        return true;
    } else {
        dispatch(setQuestionTypeErrorMessage(`${messages.emptyField} QuestionType`));
        return false;
    }
};
export const doValidateRating = (fieldValue: any, dispatch: any) => {
    if (fieldValue) {
        dispatch(setRatingErrorMessage(''));
        return true;
    } else {
        dispatch(setRatingErrorMessage(`${messages.emptyField} Rating`));
        return false;
    }
};


// Text Field validation
export const doValidateTextField = (fieldId: string, fieldValue: string, dispatch: any, setFormState: any) => {
    if (fieldValue) {
        if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            setFormState((prevState: { errors: any; }) => ({
                ...prevState,
                errors: {
                    ...prevState.errors,
                    [fieldId]: '',
                },
            }));
            return true;
        }
        setFormState((prevState: { errors: any; }) => ({
            ...prevState,
            errors: {
                ...prevState.errors,
                [fieldId]: `Text ${messages.startsWithSpaceAndString}`,
            },
        }));
        return false;
    } else {
        setFormState((prevState: { errors: any; }) => ({
            ...prevState,
            errors: {
                ...prevState.errors,
                [fieldId]: `${messages.emptyField} Text`,
            },
        }));
        return false;
    }
};

// Single Selection validation (e.g., radio button)
export const doValidateSingleSelection = (fieldId: string, fieldValue: string, dispatch: any, setFormState: any) => {
    if (fieldValue) {
        setFormState((prevState: { errors: any; }) => ({
            ...prevState,
            errors: {
                ...prevState.errors,
                [fieldId]: '',
            },
        }));
        return true;
    } else {
        setFormState((prevState: { errors: any; }) => ({
            ...prevState,
            errors: {
                ...prevState.errors,
                [fieldId]: `${messages.emptyField} Single Selection`,
            },
        }));
        return false;
    }
};

export const doValidateMultipleSelection = (fieldId: string, fieldValue: string[], dispatch: any, setFormState: any) => {
    if (fieldValue && fieldValue.length > 0) {
        setFormState((prevState: { errors: any; }) => ({
            ...prevState,
            errors: {
                ...prevState.errors,
                [fieldId]: '',
            },
        }));
        return true;
    } else {
        setFormState((prevState: { errors: any; }) => ({
            ...prevState,
            errors: {
                ...prevState.errors,
                [fieldId]: `${messages.emptyField} Multiple Selection`,
            },
        }));
        return false;
    }
};
export const doValidateZone = (fieldValue: any, dispatch: any) => {
        if (fieldValue === '' || fieldValue === null || fieldValue === undefined) {
            dispatch(setZoneErrorMessage(''));
            return true;
        } else if (!fieldValue.startsWith(' ') && regex.commonRegex.test(fieldValue)) {
            dispatch(setZoneErrorMessage(''));
            return true;
        } else {
            dispatch(setZoneErrorMessage(`Zone ${messages.startsWithSpaceAndString}`));
            return false;
        }
};
