import { PATH } from "../constants/path";
import { jwtDecode } from "jwt-decode";
import * as XLSX from 'xlsx';

export const convertToSelectOptions = (data: any) => {
    return data?.map(
        (data: any) => ({
            value: data.value,
            label: data.label,
        })
    );
}
export const convertToBudgetOptions = (data: any) => {
    return data?.map(
        (data: any) => ({
            value: data.value,
            label: data.description,
        })
    );
}
export const convertToSizeOptions = (data: any) => {
    return data?.map(
        (data: any) => ({
            value: data.value,
            label: data.description,
        })
    );
}

export const convertToSelectOptionsAssign = (data: any) => {
    return data?.map(
        (data: any) => ({
            value: data.email,
            label: data.email,
        })
    );
}
export const getOptionObject = (data: any, value: any) => {
    let optionObj = data?.find((dataObj: any) => dataObj?.value === value)
    return optionObj ? {
        value: optionObj?.value,
        label: optionObj?.label
    } : null
}
export const getOptionObjects = (data: any[], value: any) => {
    const optionObj = data?.find((dataObj: any) => dataObj?.phone === value);
    return optionObj
      ? {
          code: optionObj?.code,
          value: optionObj?.phone,
          label: optionObj?.label,
          phone: optionObj?.phone,
          phoneLength: optionObj?.phoneLength
        }
      : {
          code: 'IN',
          value: '91',
          label: 'India',
          phone: '91',
          phoneLength: 10
        };
  };
  
export const getSFOptionObject = (data: any, value: any) => {
    let optionObj = data?.find((dataObj: any) => dataObj?.value === value)
    return optionObj ? {
        value: optionObj?.value,
        label: optionObj?.value
    } : null
}
export const getAquisitionFormOptionsInfo = (dropdowndata: any) => {
    return {
        projects: convertToSelectOptions(dropdowndata?.projects || []),
        ageRanges: convertToSelectOptions(dropdowndata?.ageRanges || []),
        budgetRanges: convertToBudgetOptions(dropdowndata?.budgetRanges || []),
        occupations: convertToSelectOptions(dropdowndata?.occupations || []),
        preferredUnits: convertToSelectOptions(dropdowndata?.preferredUnits || []),
        purposeOfPurchases: convertToSelectOptions(dropdowndata?.purposeOfPurchases || []),
        sizes: convertToSizeOptions(dropdowndata?.sizes || []),
        sourceOfInformations: convertToSelectOptions(dropdowndata?.sourceOfInformations || []),
        areaOfResidence: convertToSelectOptions(dropdowndata?.areaOfResidence || [])
    }
}

export const logoutHandler = (navigate: any) => {
    localStorage.clear()
    navigate(PATH.LOGIN)
    window.location.reload();
}

export const filterSalesForceDetails = (data: any, value: any) => {
    let res = data?.find((dataObj: any) => dataObj?.email === value)
    return res
}

export const isAccessible = (permissionList: any, screenCode: string) => {
    const screenObj = permissionList?.data?.permissions?.find((activeList: any) => activeList.screenCode === screenCode);
    return screenObj?.isSelected ? true : false;
}

export const checkScreenAccess = (permissionList: any, screenCode: string, navigate: any) => {
    if (!isAccessible(permissionList, screenCode)) {
        navigate(PATH.ACCESS_DENIED)
    }
}

export const decodedJwtToken = () => {
    let token: any = localStorage.getItem('cw-token')
    let userData: any = jwtDecode(token)
    return userData
}

const getcurrentdateWithTime = () => {
    const currentDate = new Date();
    const year = currentDate.getFullYear().toString().slice(-2);
    const month = ('0' + (currentDate.getMonth() + 1)).slice(-2);
    const day = ('0' + currentDate.getDate()).slice(-2);
    const hours = ('0' + currentDate.getHours()).slice(-2);
    const minutes = ('0' + currentDate.getMinutes()).slice(-2);
    const period = currentDate.getHours() < 12 ? 'am' : 'pm';
    console.log(`${day}-${month}-${year}-${hours}-${minutes}-${period}`)
    return `${day}-${month}-${year}-${hours}-${minutes}-${period}`;
}

export const downloadExcel = (data: unknown[], type: string) => {
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/octet-stream' });
    const currentDate = getcurrentdateWithTime();
    const fileName = type === 'sample' ? `sample.xlsx` : (type === 'success') ? `success list ${currentDate}.xlsx` : `failed list ${currentDate}.xlsx`;
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
    return blob;
};
