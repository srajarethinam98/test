import { Outlet, Navigate } from "react-router-dom";
import {jwtDecode} from "jwt-decode";
import { PATH } from "../constants/path";

const AdminRoutes = () => {
  const token: any = localStorage.getItem("dashboard-token")
  let userData: any = jwtDecode(token);
  return userData.type === "admin" ? <Outlet /> : userData.type === "staff"? <Navigate to={PATH.DASHBOARD} />:<Navigate to = {PATH.LOGIN}/>;
};

export default AdminRoutes;
