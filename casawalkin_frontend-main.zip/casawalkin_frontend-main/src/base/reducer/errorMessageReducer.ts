import { createSlice, PayloadAction } from "@reduxjs/toolkit";

type initialState = {
    unAuthorized: boolean
    notFound: boolean,
    currentScreen:string,
    emailErrorMessage: string,
    passwordErrorMessage: string,
    editPasswordErrorMessage : string,

    //project
    nameErrorMessage: string,

    projectErrorMessage: string,
    areaOfCurrentResidentErrorMessage: string,
    mobileErrorMessage: string,
    alternateMobileErrorMessage: string,
    preferredUnitsErrorMessage: string,
    preferredBudgetRangeErrorMessage: string,
    howDidYouKnowAboutUsErrorMessage: string,
    socialMediaErrorMessage : string,
    partnerNameErrorMessage : string,
    empNameErrorMessage: string,
    empIdErrorMessage:string,
    contactErrorMessage:string,
    refProjectErrorMessage:string,
    labelErrorMessage:string,
    descriptionErrorMessage: string,
    purposeOfVisitErrorMessage : string,
    unitNoErrorMessage: string,
    zoneErrorMessage: string,

    leadIdErrorMessage: string,
    statusErrorMessage: string,
    flsErrorMessage: string,
    flsTlErrorMessage: string,
    remarksErrorMessage:string,

    //user
    firstNameErrorMessage: string,
    lastNameErrorMessage: string,
    userMobileErrorMessage: string,
    userRoleErrorMessage: string,
    tlErrorMessage: string,
    svcErrorMessage: string,
    salesRoleErrorMessage: string,

    //master
    roleNameErrorMessage: string,
    departmentNameErrorMessage: string,
    minAgeErrorMessage: string,
    maxAgeErrorMessage: string,
    occupationErrorMessage: string,
    minbudgetErrorMessage: string,
    maxbudgetErrorMessage: string,
    minPreferredSizeErrorMessage: string,
    maxPreferredSizeErrorMessage: string,
    preferredUnitErrorMessage: string,
    projectNameErrorMessage: string,
    purposeOfPurchaseErrorMessage: string,
    knowAboutUsErrorMessage: string,
    statusNameErrorMessage: string,
    leadOwnerErrorMessage: string,
    leadTypeErrorMessage: string

    //Review
    questionErrorMessage: string,
    optionErrors: string,
    dropdownErrorMessage: string,
    answerErrorMessage: string,
    singleSelectionErrorMessage: string,
    multipleSelectionErrorMessage: string,
    questionTypeErrorMessage: string,
    ratingErrorMessage: string

    //upload 
    excelFileErrorMessage:string,

}

const initialState: initialState = {
    unAuthorized: false,
    notFound: false,
    currentScreen:'',
    emailErrorMessage: '',
    passwordErrorMessage: '',
    editPasswordErrorMessage:'',


    nameErrorMessage: '',
    projectErrorMessage: '',
    areaOfCurrentResidentErrorMessage: '',
    mobileErrorMessage: '',
    alternateMobileErrorMessage: '',
    preferredUnitsErrorMessage: '',
    preferredBudgetRangeErrorMessage: '',
    howDidYouKnowAboutUsErrorMessage: '',
    socialMediaErrorMessage: '',
    partnerNameErrorMessage: '',
    empNameErrorMessage: '',
    empIdErrorMessage:'',
    labelErrorMessage:'',
    descriptionErrorMessage:'',
    purposeOfVisitErrorMessage: '',
    contactErrorMessage: '',
    refProjectErrorMessage: '',
    unitNoErrorMessage: '',
    zoneErrorMessage: '',
    leadOwnerErrorMessage: '',
    leadTypeErrorMessage: '',

    leadIdErrorMessage: '',
    statusErrorMessage: '',
    flsErrorMessage: '',
    flsTlErrorMessage: '',
    remarksErrorMessage:'',

    //user
    firstNameErrorMessage: '',
    lastNameErrorMessage: '',
    userMobileErrorMessage: '',
    userRoleErrorMessage: '',
    tlErrorMessage: '',
    svcErrorMessage: '',
    salesRoleErrorMessage: '',

    //master
    roleNameErrorMessage: '',
    departmentNameErrorMessage: '',
    minAgeErrorMessage: '',
    maxAgeErrorMessage: '',
    occupationErrorMessage: '',
    minbudgetErrorMessage: '',
    maxbudgetErrorMessage: '',
    minPreferredSizeErrorMessage: '',
    maxPreferredSizeErrorMessage: '',

    preferredUnitErrorMessage: '',
    projectNameErrorMessage: '',
    purposeOfPurchaseErrorMessage: '',

    knowAboutUsErrorMessage: '',
    statusNameErrorMessage: '',

    //Review
    questionErrorMessage:'',
    optionErrors: '',
    dropdownErrorMessage: '',
    answerErrorMessage: '',
    singleSelectionErrorMessage: '',
    multipleSelectionErrorMessage: '',
    questionTypeErrorMessage: '',
    ratingErrorMessage: '',

    //upload
    excelFileErrorMessage:'',
}

const ErrorSlice = createSlice({
    name: 'errorMessage',
    initialState,
    reducers: {
        setUnAuthorized: (state: initialState, action: PayloadAction<boolean>) => {
            state.unAuthorized = action.payload;
        },
        setNotfound: (state: initialState, action: PayloadAction<boolean>) => {
            state.notFound = action.payload;
        },
        setCurrentScreen: (state: initialState, action: PayloadAction<string>) => {
            state.currentScreen = action.payload;
        },
        setEmailErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.emailErrorMessage = action.payload;
        },
        setPasswordErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.passwordErrorMessage = action.payload;
        },
        setEditPasswordErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.editPasswordErrorMessage = action.payload;
        },
        //Aquicistion
        setProjectErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.projectErrorMessage = action.payload;
        },
        setNameErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.nameErrorMessage = action.payload;
        },
        setAreaOfCurrentResidentErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.areaOfCurrentResidentErrorMessage = action.payload;
        },
        setMobileErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.mobileErrorMessage = action.payload;
        },
        setAlternateMobileErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.alternateMobileErrorMessage = action.payload;
        },
        setPreferredUnitsErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.preferredUnitsErrorMessage = action.payload;
        },
        setPreferredBudgetErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.preferredBudgetRangeErrorMessage = action.payload;
        },
        setHowDidYouKnowAboutUsErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.howDidYouKnowAboutUsErrorMessage = action.payload;
        },
        setSocialMediaErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.socialMediaErrorMessage = action.payload;
        }, 
        setPartnerNameErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.partnerNameErrorMessage = action.payload;
        },               
        setEmpNameErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.empNameErrorMessage = action.payload;
        },
        setEmpIdErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.empIdErrorMessage = action.payload;
        },
        setLabelErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.labelErrorMessage = action.payload;
        },
        setDescriptionErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.descriptionErrorMessage = action.payload;
        },
        setPurposeOfVisitErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.purposeOfVisitErrorMessage = action.payload;
        },

        setContactErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.contactErrorMessage = action.payload;
        },        
        setRefProjectErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.refProjectErrorMessage = action.payload;
        },
        setUnitNoErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.unitNoErrorMessage = action.payload;
        },
        setZoneErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.zoneErrorMessage = action.payload;
        },  
        setLeadOwnerErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.leadOwnerErrorMessage = action.payload;
        },
        setLeadTypeErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.leadTypeErrorMessage = action.payload;
        },       

        //******************* */
        setLeadIdErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.leadIdErrorMessage = action.payload;
        },
        setStatusErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.statusErrorMessage = action.payload;
        },
        setFlsErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.flsErrorMessage = action.payload;
        },
        setFlsTlErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.flsTlErrorMessage = action.payload;
        },
        setRemarks: (state: initialState, action: PayloadAction<string>) => {
            state.remarksErrorMessage = action.payload;
        },
        //user
        setFirstNameErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.firstNameErrorMessage = action.payload;
        },
        setLastNameErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.lastNameErrorMessage = action.payload;
        },
        setUserMobileErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.userMobileErrorMessage = action.payload;
        },
        setUserRoleErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.userRoleErrorMessage = action.payload;
        },

        //master
        setRoleNameErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.roleNameErrorMessage = action.payload;
        },
        setDepartmentNameErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.departmentNameErrorMessage = action.payload;
        },
        setMinAgeErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.minAgeErrorMessage = action.payload;
        },
        setMaxAgeErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.maxAgeErrorMessage = action.payload;
        },
        setOccupationErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.occupationErrorMessage = action.payload;
        },

        setMinBudgetErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.minbudgetErrorMessage = action.payload;
        },
        setMaxBudgetErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.maxbudgetErrorMessage = action.payload;
        },
        setMinPreferredSizeErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.minPreferredSizeErrorMessage = action.payload;
        },
        setMaxPreferredSizeErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.maxPreferredSizeErrorMessage = action.payload;
        },
        setPreferredUnitErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.preferredUnitErrorMessage = action.payload;
        },
        setProjectNameErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.projectNameErrorMessage = action.payload;
        },

        setPurposeOfPurchaseErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.purposeOfPurchaseErrorMessage = action.payload;
        },
        setknowAboutUsErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.knowAboutUsErrorMessage = action.payload;
        },
        setStatusNameErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.statusNameErrorMessage = action.payload;
        },


        setTlErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.tlErrorMessage = action.payload;
        },
        setSvcErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.svcErrorMessage = action.payload;
        },
        setSalesRoleErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.salesRoleErrorMessage = action.payload;
        },

        //Review
        setQuestionErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.questionErrorMessage = action.payload;
        },
        setOptionErrors: (state: initialState, action: PayloadAction<string>) => {
            state.optionErrors = action.payload;
        },
        setDropdownErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.dropdownErrorMessage = action.payload;
        },
        setAnswerErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.answerErrorMessage = action.payload;
        },
        setSingleSelectionErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.singleSelectionErrorMessage = action.payload;
        },
        setMultipleSelectionErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.multipleSelectionErrorMessage = action.payload;
        },
        setQuestionTypeErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.questionTypeErrorMessage = action.payload;
        },
        setRatingErrorMessage: (state: initialState, action: PayloadAction<string>) => {
            state.ratingErrorMessage = action.payload;
        },
        //upload
        setExcelFileErrorMessage:(state:initialState,action:PayloadAction<string>) => {
            state.excelFileErrorMessage = action.payload;
        },
}})

export default ErrorSlice.reducer

export const {
    setUnAuthorized,
    setNotfound,
    setCurrentScreen,
    setEmailErrorMessage,
    setPasswordErrorMessage,
    setEditPasswordErrorMessage,

    setProjectErrorMessage,
    setNameErrorMessage,
    setAreaOfCurrentResidentErrorMessage,
    setMobileErrorMessage,
    setAlternateMobileErrorMessage,
    setPreferredUnitsErrorMessage,
    setPreferredBudgetErrorMessage,
    setHowDidYouKnowAboutUsErrorMessage,
    setSocialMediaErrorMessage,
    setPartnerNameErrorMessage,
    setEmpNameErrorMessage,
    setEmpIdErrorMessage,
    setContactErrorMessage,
    setRefProjectErrorMessage,
    setLabelErrorMessage,
    setDescriptionErrorMessage,
    setPurposeOfVisitErrorMessage,
    setUnitNoErrorMessage,
    setZoneErrorMessage,
    setLeadOwnerErrorMessage,
    setLeadTypeErrorMessage,

    //AquisitionEdit
    setFlsErrorMessage,
    setLeadIdErrorMessage,
    setFlsTlErrorMessage,
    setStatusErrorMessage,
    setRemarks,
    //user
    setUserMobileErrorMessage,
    setUserRoleErrorMessage,
    setFirstNameErrorMessage,
    setLastNameErrorMessage,
    setSvcErrorMessage,
    setTlErrorMessage,
    //master
    setDepartmentNameErrorMessage,
    setRoleNameErrorMessage,
    setMinAgeErrorMessage,
    setMaxAgeErrorMessage,
    setMinBudgetErrorMessage,
    setMaxBudgetErrorMessage,
    setOccupationErrorMessage,
    setMinPreferredSizeErrorMessage,
    setMaxPreferredSizeErrorMessage,
    setPreferredUnitErrorMessage,
    setProjectNameErrorMessage,
    setPurposeOfPurchaseErrorMessage,
    setStatusNameErrorMessage,
    setknowAboutUsErrorMessage,
    setSalesRoleErrorMessage,

    //Review
    setQuestionErrorMessage,
    setOptionErrors,
    setDropdownErrorMessage,
    setAnswerErrorMessage,
    setSingleSelectionErrorMessage,
    setMultipleSelectionErrorMessage,
    setQuestionTypeErrorMessage,
    setRatingErrorMessage,

    //upload
    setExcelFileErrorMessage,


} = ErrorSlice.actions;
