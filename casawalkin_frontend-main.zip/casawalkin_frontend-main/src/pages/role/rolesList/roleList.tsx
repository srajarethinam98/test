import { useMemo, useState } from 'react'
import { Badge, Button, Form, Spinner } from 'react-bootstrap'
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { useDeleteRoleMutation, useGetRoleListQuery } from '../../../services/apiService/roles/roles';
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import Loading from '../../miscellanious/tableLoader/index'
import ResponsivePagination from 'react-responsive-pagination';
import NoData from '../../miscellanious/noData/index'
import { searchParamsInitialData, searchParamsType } from '../../../constants/dropdowns';
import { BiSearch } from "react-icons/bi";
import { AiOutlinePlus,AiOutlineEdit ,AiOutlineDelete} from "react-icons/ai";

function RoleList() {
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const [deleteRoleApi] = useDeleteRoleMutation()
    const [apiParams, setApiParams] = useState<searchParamsType>(searchParamsInitialData)
    const { data: roleListData, isFetching: roleListApiIsFetching, isSuccess: roleListApiIsSuccess } = useGetRoleListQuery(apiParams)
    const deleteRole = async (id: any) => {
        await deleteRoleApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'Role deleted successfully', dispatch)
        }).catch((err: any) => {
            if (err?.data?.statusCode === 401) {
                dispatch(setUnAuthorized(true))
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete Role', dispatch)
        })
    }
    
    const doFormArrayOfObject = (apiValue: any) => {
        if (roleListApiIsSuccess) {
            return apiValue?.data?.roles?.map((roleObj: any) => {
                return {
                    id: roleObj._id,
                    title: roleObj?.title,
                    description: roleObj?.description,
                }
            })
        }
        return []
    }

    const rolesTableList = useMemo(() => doFormArrayOfObject(roleListData), [roleListData])

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <div className='d-flex align-items-center gap-3'>
                    <h5 className='page-title'>Roles List <Badge bg="success">{!roleListApiIsFetching ? roleListData?.data?.totalCount || 0 : <Spinner size="sm" />}</Badge> </h5>
                    <div className="col-md-6 search-input">
                        <Form.Group controlId="userName">
                            <Form.Control type="text" name='name'
                                onChange={(event) => setApiParams({ ...apiParams, currentPage: 1, searchString: event.target.value })}
                                placeholder="Search Role.."
                            />
                        </Form.Group>
                        <BiSearch className='search-icon' />
                    </div>
                    </div>
                    <Button className='add-btn mx-3' onClick={() => navigate('/role/add-role')}><span><AiOutlinePlus /> Create Role</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ textAlign: 'left' }}>S.No</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Role</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Description</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        !roleListApiIsFetching ? roleListApiIsSuccess ? roleListData?.data?.roles?.length > 0 ?
                                            rolesTableList?.map((roleObj: any, index: any) => {
                                                return (
                                                    <tr key={index}>
                                                        <td>{index + 1 + (apiParams.currentPage - 1) * roleListData?.data?.limit}</td>
                                                        <td>{roleObj?.title || '-'}</td>
                                                        <td>{roleObj?.description || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>

                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/role/edit-role/?id=${roleObj?.id}`)

                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deleteRole(roleObj?.id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }) : <NoData /> : <>Api error</> : <Loading />
                                    }
                                </tbody>
                            </table>
                        </div>
                        <div className='export-data-footer'>
                            <ResponsivePagination
                                current={apiParams.currentPage}
                                total={roleListData?.data?.totalPages || 1}
                                maxWidth={7}
                                onPageChange={(page: any) => setApiParams({ ...apiParams, currentPage: page })}
                            />
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default RoleList