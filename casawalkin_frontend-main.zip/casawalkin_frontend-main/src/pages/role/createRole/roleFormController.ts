import { setRoleNameErrorMessage, setDescriptionErrorMessage } from "../../../base/reducer/errorMessageReducer"
import messages from '../../../constants/messageConstants'
import { doValidateDescription, doValidateRoleName } from "../../../utils/utils"

export type roleInfoType = {
    name: string,
    description: string,
    isAdmin:boolean,
    permissions:any
}

export const roleInitialState: roleInfoType = {
    name: '',
    description: '',
    isAdmin:false,
    permissions:[]
}

export const roleFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'name':
            value !== '' ? dispatch(setRoleNameErrorMessage('')) : dispatch(setRoleNameErrorMessage(`${messages.emptyField} Role Name`))
            break
       
    }
}

export const checkRolesFieldsErrors = (roleInfo: roleInfoType, dispatch: any) => {
    doValidateRoleName((roleInfo.name), dispatch)
    doValidateDescription((roleInfo.description), dispatch)
   
    if (doValidateRoleName((roleInfo.name), dispatch) && doValidateDescription((roleInfo.description), dispatch)
    ) {
        return false
    }
    return true
}

export const emptyRoleFieldsErrors = (dispatch: any) => {
    dispatch(setRoleNameErrorMessage(''))
    dispatch(setDescriptionErrorMessage(''))
}