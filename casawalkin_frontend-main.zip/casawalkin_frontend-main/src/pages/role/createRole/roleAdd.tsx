import { useEffect, useState } from 'react'
import { roleInfoType, roleFieldsValidation, roleInitialState, checkRolesFieldsErrors, emptyRoleFieldsErrors } from './roleFormController';
import { doNotify, doValidateRoleName, doValidateDepartmentName, doValidateDescription } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { useCreateRoleMutation, useEditRoleMutation, useGetRolePermissionsQuery, useGetSingleRoleQuery } from '../../../services/apiService/roles/roles';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { useGetScreenListQuery } from '../../../services/apiService/permissions/rolePermissions';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function RoleAdd() {
    const [roleInfo, setRoleInfo] = useState<roleInfoType>(roleInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { roleNameErrorMessage, descriptionErrorMessage }: any = useAppSelector((state) => state.ErrorMessageReducer)
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()

    const [creatrolesApi, { isLoading: creatroleApiIsloading }] = useCreateRoleMutation()
    const [editrolesApi, { isLoading: editroleApiIsloading }] = useEditRoleMutation()
    const { data: getSingleRole, isSuccess: getSingleRoleApiIsSuccess, isError: getSingleRoleApiIsError, error: getSingleRoleApiError }: any = useGetSingleRoleQuery(id, { skip: !id })
    const { data: getScreenList, isSuccess: getScreenListApiIsSuccess, isLoading: getScreenListApiisLoading }: any = useGetScreenListQuery()

    const getRoleInfo = (event: any) => {
        const { name, value }: any = event.target
        if (name === "isAdmin") {
        setRoleInfo({ ...roleInfo, [name]: event.target.checked,permissions: checkAllPermissions() })
        } else {
            setRoleInfo({ ...roleInfo, [name]: value })
        }
        roleFieldsValidation(event, dispatch)
    }

    const checkAllPermissions = () => {
        return roleInfo?.permissions?.map((item: any) =>{
            item={...item, isSelected: true}
            return item
        } )
    }

    const handleSubmit = async () => {
        if (!checkRolesFieldsErrors(roleInfo, dispatch)) {
            let body: any = {
                title: roleInfo.name,
                adminRole:roleInfo.isAdmin,
                description: roleInfo.description,
                permissions: roleInfo?.permissions 
            }
            if (id) {
                await editrolesApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'role updated successfully', dispatch)
                    navigate(PATH.ROLES_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update role', dispatch)
                })
            } else {
                await creatrolesApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'role created successfully', dispatch)
                    navigate(PATH.ROLES_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create role', dispatch)
                })
            }
        }
    }

    const getPermissionInfo = (rowObj: any) => {
        let updatedData = roleInfo?.permissions?.map((item: any) => {
            if (item?.screenCode === rowObj?.screenCode) {
                return { ...item, isSelected: !item.isSelected };
            }
            return item;
        });
        setRoleInfo({
            ...roleInfo,
            permissions: updatedData
        })
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.ROLE, navigate)
        }
        if (type === 'edit-role') {
            !id && navigate(PATH.ROLES_LIST)
            if (getSingleRoleApiIsSuccess) {
                let roleObj: any = getSingleRole?.data?.role
                setRoleInfo({
                    ...roleInfo,
                    name: roleObj?.title,
                    isAdmin: roleObj?.adminRole,
                    description: roleObj?.description,
                    permissions: roleObj?.permissions
                })
            }
            if (getSingleRoleApiIsError) {
                navigate(PATH.ROLES_LIST)
                doNotify('error', getSingleRoleApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        } else {
            if (getScreenListApiIsSuccess) {
                let screensList: any = getScreenList?.data?.data
                setRoleInfo({
                    ...roleInfo,
                    permissions: screensList,
                })
            }
        }
        return () => {
            emptyRoleFieldsErrors(dispatch)
            setRoleInfo(roleInitialState)
        }
    }, [getSingleRole, id, getScreenList, permissionsList, getSingleRoleApiIsError])

    const handleCancel = () => {
        emptyRoleFieldsErrors(dispatch)
        navigate(PATH.ROLES_LIST)
        setRoleInfo(roleInitialState)
    }

    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)} >Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel}>
                            Role List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type === 'edit-role' ? 'Edit Role' : "Create New Role"}</Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-4">
                                <div className="col-md-5">
                                    <Form.Group className="mb-3" controlId="userName">
                                        <Form.Label>Role Name*</Form.Label>
                                        <Form.Control type="text" value={roleInfo?.name} name='name' onChange={getRoleInfo} onBlur={(event) => doValidateRoleName(event.target.value, dispatch)} placeholder="Enter Role Name" />
                                        <p className='error-msg'>{roleNameErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-5">
                                    <Form.Group className="mb-3" controlId="userName">
                                        <Form.Label>Description</Form.Label>
                                        <Form.Control type="text" value={roleInfo?.description} name='description' onChange={getRoleInfo} placeholder="Enter Description"
                                        onBlur={(event) => doValidateDescription(event.target.value, dispatch)} />
                                        <p className='error-msg'>{descriptionErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-2 justify-content-center d-flex align-items-center">
                                    <Form.Check // prettier-ignore
                                        type="switch"
                                        id="custom-switch"
                                        label=" Admin"
                                        onChange={getRoleInfo}
                                        checked={roleInfo.isAdmin}
                                        name='isAdmin'
                                    />
                                </div>
                            </div>

                        </Form>
                        <div className="table-responsive role-table">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ width: '700px', textAlign: 'left' }}>Screens</th>
                                        <th scope="col">View Access</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    {
                                        !getScreenListApiisLoading ? getScreenListApiIsSuccess ?
                                            roleInfo?.permissions?.map((rowObj: any, index: any) => {
                                                return (
                                                    <tr key={index}>
                                                        <td>{rowObj?.screenName || '-'}</td>
                                                        <td style={{ textAlign: 'center' }}><Form.Check aria-label="option 1"
                                                            checked={rowObj?.isSelected}
                                                            value={rowObj?.isSelected}
                                                            onChange={() => getPermissionInfo(rowObj)}
                                                        /></td>
                                                    </tr>
                                                )
                                            })
                                            : <tr><td >Api error</td></tr>
                                            : <tr><td >Loading</td></tr>
                                    }
                                </tbody>
                            </table>
                        </div>
                        <div className="row mt-3 mb-2">
                            <div className="col-md-12">
                                <div className='d-flex justify-content-center gap-3 mt-3'>
                                    <Button className='close-btn' onClick={handleCancel}>
                                        <span><MdOutlineClose /> Cancel</span>
                                    </Button>
                                    <Button onClick={handleSubmit} className='submit-btn' disabled={creatroleApiIsloading || editroleApiIsloading}><span> {creatroleApiIsloading || editroleApiIsloading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </>
    )
}

export default RoleAdd