import { useEffect, useState } from 'react';
import styles from "./login.module.scss";
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../base/hooks/hooks';
import { checkLoginErrors, emptyLoginErrors, loginFieldsValidation, loginInfoType, loginInitialState } from './loginController';
import { doNotify, doValidateEmailOrName, doValidatePassword } from '../../utils/utils';
import { useLoginMutation } from '../../services/apiService/login/login';
import { useGetRolePermissionsQuery } from '../../services/apiService/roles/roles';
import { PATH } from '../../constants/path';
import { Form, Button, InputGroup, Spinner } from 'react-bootstrap';
import { BsEyeFill, BsEyeSlashFill } from 'react-icons/bs';
import logo from '../../assets/cg-logo-nobg.png';

function Login() {
  const [loginInfo, setLoginInfo] = useState<loginInfoType>(loginInitialState);
  const [showPassword, setshowPassword] = useState<boolean>(false);
  const dispatch = useAppDispatch();
  const [loginApi, { isLoading: loginApiIsLoading }] = useLoginMutation();
  const { data: permissionsData, isLoading: permissionsApiIsLoading, refetch } = useGetRolePermissionsQuery();

  const navigate = useCustomNavigate();

  const { nameErrorMessage, passwordErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer);

  const getLoginInfo = (event: any) => {
    const { name, value } = event.target;
    setLoginInfo({ ...loginInfo, [name]: value.trim() });
    loginFieldsValidation(event, dispatch);
  };
  const handlePermissionNavigation = (permissions: any[]) => {
    const firstSelectedPermission = permissions.find((permission: { isSelected: boolean }) => permission.isSelected);
    
    if (firstSelectedPermission) {
      switch (firstSelectedPermission.screenCode) {
        case 'dashboard':
          navigate(PATH.DASHBOARD);
          break;
        case 'acquisitionlist':
          navigate(PATH.ACQUISITION_LIST);
          break;
        case 'acquisitionform':
          navigate(PATH.ACQUISITION_FORM);
          break;
        case 'department':
          navigate(PATH.DEPARTMENT_LIST);
          break;
        case 'role':
          navigate(PATH.ROLES_LIST);
          break;
        case 'user':
          navigate(PATH.USERS_LIST);
          break;
        case 'age':
          navigate(PATH.AGE_LIST);
          break;
        case 'knowaboutus':
          navigate(PATH.KNOW_ABOUT_US_LIST);
          break;
        case 'occupation':
          navigate(PATH.OCCUPATION_LIST);
          break;
        case 'preferredunit':
          navigate(PATH.PREFERRED_UNITS_LIST);
          break;
        case 'preferredbudgetrange':
          navigate(PATH.PREFERRED_BUDGET_RANGE_LIST);
          break;
        case 'preferredsize':
          navigate(PATH.PREFERRED_SIZE_LIST);
          break;
        case 'purposeofpurchase':
          navigate(PATH.PURPOSE_OF_PURCHASE_LIST);
          break;
        case 'project':
          navigate(PATH.PROJECT_LIST);
          break;
        case 'report':
          navigate(PATH.REPORT_LIST);
          break;
        case 'fieldemployee':
          navigate(PATH.FIELD_EMPLOYEES_LIST);
          break;
        case 'reviewform':
          navigate(PATH.CUSTOMER_REVIEW_FORM_LIST);
          break;
        case 'reviewreport':
          navigate(PATH.CUSTOMER_REVIEW_REPORT);
          break;
        default:
          navigate(PATH.DASHBOARD);
      }
    } else {
      navigate(PATH.DASHBOARD);
    }
  };
  

  const loginHandler = async () => {
    if (!checkLoginErrors(loginInfo, dispatch)) {
      let loginData = {
        user: loginInfo.user,
        password: loginInfo.password
      };
      try {
        const res = await loginApi(loginData).unwrap();
        localStorage.setItem("cw-token", res?.data?.token);
  
        const permissionsRes = await refetch();
        const permissions = permissionsRes?.data?.data?.permissions || [];

        handlePermissionNavigation(permissions);
        
        // const firstSelectedPermission = permissions.find((permission: { isSelected: any; }) => permission.isSelected);
        // if (firstSelectedPermission) {
        //   switch (firstSelectedPermission.screenCode) {
        //     case 'dashboard':
        //       navigate(PATH.DASHBOARD);
        //       break;
        //     case 'acquisitionlist':
        //       navigate(PATH.ACQUISITION_LIST);
        //       break;
        //     case 'acquisitionform':
        //       navigate(PATH.ACQUISITION_FORM);
        //       break;
        //     default:
        //       navigate(PATH.DASHBOARD);
        //   }
        // }
        doNotify('success', 'Login successful', dispatch);
      } catch (err: any) {
        doNotify('error', err?.data?.error?.message || 'Failed to login', dispatch);
      }
      setLoginInfo(loginInitialState);
    }
  };
  

  useEffect(() => {
    const checkTokenAndFetchPermissions = async () => {
      if (localStorage.getItem('cw-token')) {
        try {
          const permissionsRes = await refetch();
          const permissions = permissionsRes?.data?.data?.permissions || [];
          
          handlePermissionNavigation(permissions);
        } catch (error) {
          console.error("Error fetching permissions:", error);
        }
      }
      
      return () => {
        emptyLoginErrors(dispatch);
        setLoginInfo(loginInitialState);
      };
    };
  
    checkTokenAndFetchPermissions();
  }, [refetch, dispatch]);
  
  const togglePassword = () => setshowPassword(!showPassword);

  return (
    <>
      <div className={styles.loginWrapper}>
        <div className="container">
          <div className='row align-items-center'>
            <div className='col-12 col-lg-6'>
              <div className={styles.titleContainer}>
                <a href='#' className={styles.logo}>
                  <img src={logo} alt="Logo" />
                </a>
                <h3>Welcome To CasaWalkin</h3>
                <p className={styles.subTitle}>Welcome to CasaWalkin Portal! Please sign in to access your account. Get ready for a life of growth and prosperity with Chennai’s largest real estate developer. Become a part of Casagrand and offer customers a wide choice of homes to buy from.</p>
              </div>
            </div>
            <div className='col-lg-6 col-12'>
              <div className={styles.loginContainer}>
                <h3>Casa Walkin Portal</h3>
                <p className={styles.subTitle}>Login Your Account</p>
                <Form className='login-form' name="horizontal_login">
                  <div className="col-md-12">
                    <Form.Group className="mb-3" controlId="user">
                      <Form.Label>Email or User Name*</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Enter Email or user name"
                        value={loginInfo.user}
                        name='user'
                        onChange={getLoginInfo}
                        onBlur={(event) => doValidateEmailOrName(event.target.value, dispatch)}
                      />
                      <p className='error-msg'>{nameErrorMessage}</p>
                    </Form.Group>
                  </div>
                  <div className="col-md-12">
                    <Form.Group className="mb-3" controlId="Password">
                      <Form.Label>Password*</Form.Label>
                      <InputGroup>
                        <Form.Control
                          type={showPassword ? "text" : "password"}
                          placeholder="Enter Password"
                          value={loginInfo.password}
                          name='password'
                          onChange={getLoginInfo}
                          onBlur={(event) => doValidatePassword(event.target.value, dispatch)}
                        />
                        {showPassword ? <BsEyeFill className='eye-icon-login' onClick={togglePassword} /> : <BsEyeSlashFill className='eye-icon-login' onClick={togglePassword} />}
                      </InputGroup>
                      <p className='error-msg'>{passwordErrorMessage}</p>
                    </Form.Group>
                  </div>
                  <Button disabled={loginApiIsLoading || permissionsApiIsLoading} onClick={loginHandler}>
                    {loginApiIsLoading || permissionsApiIsLoading ? <Spinner animation="border" size="sm" /> : 'Log in'}
                  </Button>
                </Form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
