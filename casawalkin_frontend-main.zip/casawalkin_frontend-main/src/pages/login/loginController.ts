import { setEmailErrorMessage, setNameErrorMessage, setPasswordErrorMessage } from "../../base/reducer/errorMessageReducer"
import messages from '../../constants/messageConstants'
import { doValidateEmail, doValidateEmailOrName, doValidatePassword, doValidatefullName } from "../../utils/utils"

export type loginInfoType = {
    user: string,
    password: string
}

export const loginInitialState: loginInfoType = {
    user: '',
    password: ''
}

export const loginFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'user':
            value !== '' ? dispatch(setNameErrorMessage('')) : dispatch(setNameErrorMessage(`${messages.emptyField} Email or User Name`))
            break
        case 'password':
            value !== '' ? dispatch(setPasswordErrorMessage('')) : dispatch(setPasswordErrorMessage(`${messages.emptyField} password`))
            break
    }
}

export const checkLoginErrors = (loginInfo: any, dispatch: any) => {
    doValidateEmailOrName((loginInfo.user), dispatch)
    doValidatePassword((loginInfo.password), dispatch)

    if (doValidateEmailOrName((loginInfo.user), dispatch) && doValidatePassword((loginInfo.password), dispatch)) {
        return false
    }
    return true
}

export const emptyLoginErrors = (dispatch: any) => {
    dispatch(setNameErrorMessage(''))
    dispatch(setPasswordErrorMessage(''))
}