import messages from '../../../constants/messageConstants'
import { setMinPreferredSizeErrorMessage, setMaxPreferredSizeErrorMessage, setLabelErrorMessage } from "../../../base/reducer/errorMessageReducer"
import { doValidateMinPreferredSize, doValidateMaxPreferredSize, doValidateLabel } from "../../../utils/utils"

export type preferredSizeInfoType = {
    minSize: string,
    maxSize: string,
    description: string
}

export const preferredSizeInitialState: preferredSizeInfoType = {

    minSize: '',
    maxSize: '',
    description: '',
}

export const preferredSizeFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'minSize':
            value !== '' ? dispatch(setMinPreferredSizeErrorMessage('')) : dispatch(setMinPreferredSizeErrorMessage(`${messages.emptyField} Min Size`))
            break
        case 'maxSize':
            value !== '' ? dispatch(setMaxPreferredSizeErrorMessage('')) : dispatch(setMaxPreferredSizeErrorMessage(`${messages.emptyField} Max Size`))
            break
        case 'description':
            value !== '' ? dispatch(setLabelErrorMessage('')) : dispatch(setLabelErrorMessage(`${messages.emptyField} Label`))
            break    
    }
}

export const checkpreferredSizesFieldsErrors = (preferredSizeInfo: preferredSizeInfoType, dispatch: any) => {
    doValidateMinPreferredSize((preferredSizeInfo.minSize), dispatch)
    doValidateMaxPreferredSize((preferredSizeInfo.maxSize), preferredSizeInfo.maxSize, dispatch)
    doValidateLabel((preferredSizeInfo.description), dispatch , true)

    if (doValidateMinPreferredSize((preferredSizeInfo.minSize), dispatch) &&
        doValidateMaxPreferredSize((preferredSizeInfo.maxSize), preferredSizeInfo.minSize, dispatch) &&
        doValidateLabel((preferredSizeInfo.description), dispatch, true)
    ) {
        return false
    }
    return true
}

export const emptypreferredSizeFieldsErrors = (dispatch: any) => {
    dispatch(setMinPreferredSizeErrorMessage(''))
    dispatch(setMaxPreferredSizeErrorMessage(''))
    dispatch(setLabelErrorMessage(''))

}