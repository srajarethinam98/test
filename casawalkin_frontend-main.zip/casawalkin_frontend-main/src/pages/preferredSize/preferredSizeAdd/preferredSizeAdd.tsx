import { useEffect, useState } from 'react'
import { preferredSizeInfoType, preferredSizeFieldsValidation, preferredSizeInitialState, checkpreferredSizesFieldsErrors, emptypreferredSizeFieldsErrors } from './preferredSizeController';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import { useCreatePreferredSizeMutation, useEditPreferredSizeMutation, useGetSinglePreferredSizeQuery } from '../../../services/apiService/preferredSize/preferredSize';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { doNotify, doValidateMaxPreferredSize, doValidateMinPreferredSize, doValidateLabel } from '../../../utils/utils';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function PreferredSizeAdd() {
    const [preferredSizeInfo, setpreferredSizeInfo] = useState<preferredSizeInfoType>(preferredSizeInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { minPreferredSizeErrorMessage, maxPreferredSizeErrorMessage, labelErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer)

    const [creatpreferredSizesApi, { isLoading: creatpreferredSizeApiIsloading }] = useCreatePreferredSizeMutation()
    const [editpreferredSizesApi, { isLoading: editpreferredSizeApiIsloading }] = useEditPreferredSizeMutation()
    const { data: getSinglepreferredSize, isSuccess: getSinglepreferredSizeApiIsSuccess, isError: getSinglepreferredSizeApiIsError, error: getSinglepreferredSizeApiError }: any = useGetSinglePreferredSizeQuery(id, { skip: !id })
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()

    const getpreferredSizeInfo = (event: any) => {
        const { name, value }: any = event.target
        setpreferredSizeInfo({ ...preferredSizeInfo, [name]: value })
        preferredSizeFieldsValidation(event, dispatch)
    }

    const handleSubmit = async () => {
        if (!checkpreferredSizesFieldsErrors(preferredSizeInfo, dispatch)) {
            let body: any = {
                minSize: preferredSizeInfo.minSize,
                maxSize: preferredSizeInfo.maxSize,
                description: preferredSizeInfo.description,
            }
            if (id) {
                await editpreferredSizesApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'preferredSize updated successfully', dispatch)
                    navigate(PATH.PREFERRED_SIZE_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode===401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update preferredSize', dispatch)
                })
            } else {
                await creatpreferredSizesApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'preferredSize created successfully', dispatch)
                    navigate(PATH.PREFERRED_SIZE_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode===401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create preferredSize', dispatch)
                })
            }
        }
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.PREFERRED_SIZE, navigate)
        }
        if (type==='edit-size') {
            !id && navigate(PATH.PREFERRED_SIZE_LIST)
            if (getSinglepreferredSizeApiIsError) {
                navigate(PATH.PREFERRED_SIZE_LIST)
                doNotify('error', getSinglepreferredSizeApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        }
        if (getSinglepreferredSizeApiIsSuccess) {
            let preferredSizeObj: any = getSinglepreferredSize?.data?.unitSize
            setpreferredSizeInfo({
                ...preferredSizeInfo,
                minSize: preferredSizeObj?.minSize,
                maxSize: preferredSizeObj?.maxSize,
                description: preferredSizeObj?.description
            })
        }
        return () => {
            emptypreferredSizeFieldsErrors(dispatch)
            setpreferredSizeInfo(preferredSizeInitialState)
        }
    }, [getSinglepreferredSize, id, permissionsList, getSinglepreferredSizeApiIsError])
    
    const handleCancel = () => {
        emptypreferredSizeFieldsErrors(dispatch)
        navigate(PATH.PREFERRED_SIZE_LIST)
        setpreferredSizeInfo(preferredSizeInitialState)
    }
    
    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel}>
                            Preferred Size List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type==='add-size' ? 'Add Preferred Size' : 'Edit Preferred Size'}</Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-4">
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="size">
                                        <Form.Label>Min Preferred Size*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Preferred Size" value={preferredSizeInfo?.minSize} name='minSize' onChange={getpreferredSizeInfo} onBlur={(event) => doValidateMinPreferredSize(event.target.value, dispatch)} />
                                        <p className='error-msg'>{minPreferredSizeErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="size">
                                        <Form.Label>Max Preferred Size*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Preferred Max Size" value={preferredSizeInfo?.maxSize} name='maxSize' onChange={getpreferredSizeInfo} onBlur={(event) => doValidateMaxPreferredSize(event.target.value, preferredSizeInfo.minSize, dispatch)} />
                                        <p className='error-msg'>{maxPreferredSizeErrorMessage}</p>
                                    </Form.Group>
                                </div><div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="description">
                                        <Form.Label>Label*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Label" value={preferredSizeInfo?.description} name='description' onChange={getpreferredSizeInfo}
                                        onBlur={() => doValidateLabel(preferredSizeInfo.description, dispatch, true)}
                                        />
                                        <p className='error-msg'>{labelErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            </div>
                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button onClick={handleSubmit} disabled={creatpreferredSizeApiIsloading || editpreferredSizeApiIsloading} className='submit-btn'><span> {creatpreferredSizeApiIsloading || editpreferredSizeApiIsloading ? <Spinner animation="border" size="sm" />: <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default PreferredSizeAdd