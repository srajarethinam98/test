import { useEffect } from 'react'
import { Button } from 'react-bootstrap'
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { PATH } from '../../../constants/path';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { useDeletePurposeOfPurchaseMutation, useGetPurposeOfPurchaseListQuery } from '../../../services/apiService/purposeOfPurchase/purposeOfPurchase';
import Loading from '../../miscellanious/tableLoader/index'
import NoData from '../../miscellanious/noData/index'
import { AiOutlinePlus,AiOutlineEdit ,AiOutlineDelete} from "react-icons/ai";

function PurposeOfPurchaseList() {
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const [deleteDepartmentApi] = useDeletePurposeOfPurchaseMutation()
    
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const { data: purposeListData, isLoading: purposeListApiIsLoading, isSuccess: purposeListApiIsSuccess } = useGetPurposeOfPurchaseListQuery()
    
    const deleteDepartment = async (id: any) => {
        await deleteDepartmentApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'Purpose deleted successfully', dispatch)
        }).catch((err: any) => {
            if (err?.data?.statusCode === 401) {
                dispatch(setUnAuthorized(true))
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete Purpose', dispatch)
        })
    }
    
    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.PURPOSE_OF_PURCHASE, navigate)
        }
    }, [permissionsList])

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Purpose Of Purchase List</h5>
                    <Button className='add-btn mx-3' onClick={() => navigate(PATH.PURPOSE_OF_PURCHASE_ADD)}><span><AiOutlinePlus /> Create</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">

                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ textAlign: 'left' }}>S.No</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Purpose Of Purchase</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Label</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        !purposeListApiIsLoading ? purposeListApiIsSuccess ?purposeListData?.data?.purposes?.length>0?
                                            purposeListData?.data?.purposes?.map((departmentObj: any, index: any) => {
                                                let id = departmentObj?._id
                                                return (
                                                    <tr key={index}>

                                                        <td>{index + 1}</td>
                                                        <td>{departmentObj?.purpose || '-'}</td>
                                                        <td>{departmentObj?.description || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/purpose-of-purchase/edit-purpose/?id=${id}`)

                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deleteDepartment(id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }):<NoData/> : <>Api error</> : <Loading/>
                                        }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default PurposeOfPurchaseList