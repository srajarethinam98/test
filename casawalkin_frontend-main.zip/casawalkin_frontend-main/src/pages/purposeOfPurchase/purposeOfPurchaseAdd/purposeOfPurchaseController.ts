import messages from '../../../constants/messageConstants'
import { setPurposeOfPurchaseErrorMessage, setLabelErrorMessage } from "../../../base/reducer/errorMessageReducer"
import { doValidateLabel, doValidatePurposeOfPurchase } from "../../../utils/utils"

export type purposeInfoType = {
    name: string,
    description: string,
}

export const purposeInitialState: purposeInfoType = {
    name: '',
    description: '',
}

export const purposeFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'name':
            value !== '' ? dispatch(setPurposeOfPurchaseErrorMessage('')) : dispatch(setPurposeOfPurchaseErrorMessage(`${messages.emptyField} purpose`))
            break
        
    }
}

export const checkPurposesFieldsErrors = (purposeInfo: purposeInfoType, dispatch: any) => {
    doValidatePurposeOfPurchase((purposeInfo.name), dispatch)
    doValidateLabel((purposeInfo.description), dispatch, false)

    
    if (doValidatePurposeOfPurchase((purposeInfo.name), dispatch) && doValidateLabel((purposeInfo.description), dispatch, false)
    ) {
        return false
    }
    return true
}

export const emptyPurposeFieldsErrors = (dispatch: any) => {
    dispatch(setPurposeOfPurchaseErrorMessage(''))
    dispatch(setLabelErrorMessage(''))
   
}