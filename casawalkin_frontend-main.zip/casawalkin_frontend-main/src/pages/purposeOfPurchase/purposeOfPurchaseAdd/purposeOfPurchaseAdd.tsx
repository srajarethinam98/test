import { useEffect, useState } from 'react'
import { purposeInfoType, purposeFieldsValidation, purposeInitialState, checkPurposesFieldsErrors, emptyPurposeFieldsErrors } from './purposeOfPurchaseController';
import { doNotify, doValidatePurposeOfPurchase, doValidateLabel } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import { useCreatePurposeOfPurchaseMutation, useEditPurposeOfPurchaseMutation, useGetSinglePurposeOfPurchaseQuery } from '../../../services/apiService/purposeOfPurchase/purposeOfPurchase';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function PurposeOfPurchaseAdd() {
    const [purposeInfo, setPurposeInfo] = useState<purposeInfoType>(purposeInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { purposeOfPurchaseErrorMessage, labelErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer)

    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const [creatpurposesApi, { isLoading: creatpurposeApiIsloading }] = useCreatePurposeOfPurchaseMutation()
    const [editpurposesApi, { isLoading: editpurposeApiIsloading }] = useEditPurposeOfPurchaseMutation()
    const { data: getSinglepurpose, isSuccess: getSinglepurposeApiIsSuccess, isError: getSinglepurposeApiIsError, error: getSinglepurposeApiError }: any = useGetSinglePurposeOfPurchaseQuery(id, { skip: !id })

    const getpurposeInfo = (event: any) => {
        const { name, value }: any = event.target
        setPurposeInfo({ ...purposeInfo, [name]: value })
        purposeFieldsValidation(event, dispatch)
    }

    const handleSubmit = async () => {
        if (!checkPurposesFieldsErrors(purposeInfo, dispatch)) {
            let body: any = {
                purpose: purposeInfo.name,
                description: purposeInfo.description,
            }
            if (id) {
                await editpurposesApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'purpose updated successfully', dispatch)
                    navigate(PATH.PURPOSE_OF_PURCHASE_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update purpose', dispatch)
                })
            } else {
                await creatpurposesApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'purpose created successfully', dispatch)
                    navigate(PATH.PURPOSE_OF_PURCHASE_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create purpose', dispatch)
                })
            }
        }
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.PURPOSE_OF_PURCHASE, navigate)
        }
        if (type === 'edit-purpose') {
            !id && navigate(PATH.PURPOSE_OF_PURCHASE_LIST)
            if (getSinglepurposeApiIsError) {
                navigate(PATH.PURPOSE_OF_PURCHASE_LIST)
                doNotify('error', getSinglepurposeApiError?.data?.error?.message|| 'Failed to get Acquisition', dispatch)
              }
        }
        if (getSinglepurposeApiIsSuccess) {
            let purposeObj: any = getSinglepurpose?.data?.purpose
            setPurposeInfo({
                ...purposeInfo,
                name: purposeObj?.purpose,
                description: purposeObj?.description
            })
        }
        return () => {
            emptyPurposeFieldsErrors(dispatch)
            setPurposeInfo(purposeInitialState)
        }
    }, [getSinglepurpose, id,permissionsList,getSinglepurposeApiIsError])
    
    const handleCancel = () => {
        emptyPurposeFieldsErrors(dispatch)
        navigate(PATH.PURPOSE_OF_PURCHASE_LIST)
        setPurposeInfo(purposeInitialState)
    }
    
    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                   <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item  onClick={handleCancel}>
                            Purpose Of Purchase List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type === 'add-purpose' ? 'Add purpose' : 'Edit purpose'}</Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-4">
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="purpose">
                                        <Form.Label>Purpose Of Purchase*</Form.Label>
                                        <Form.Control type="text" value={purposeInfo?.name} name='name' onChange={getpurposeInfo} onBlur={(event) => doValidatePurposeOfPurchase(event.target.value, dispatch)} placeholder="Enter Purpose Of Purchase" />
                                        <p className='error-msg'>{purposeOfPurchaseErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="description">
                                        <Form.Label>Label</Form.Label>
                                        <Form.Control type="text" value={purposeInfo?.description} name='description' onChange={getpurposeInfo} placeholder="Enter Label"
                                        onBlur={() => doValidateLabel(purposeInfo.description, dispatch, false)}
                                        />
                                        <p className='error-msg'>{labelErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            </div>
                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button onClick={handleSubmit} disabled={creatpurposeApiIsloading || editpurposeApiIsloading} className='submit-btn'><span>{creatpurposeApiIsloading || editpurposeApiIsloading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default PurposeOfPurchaseAdd