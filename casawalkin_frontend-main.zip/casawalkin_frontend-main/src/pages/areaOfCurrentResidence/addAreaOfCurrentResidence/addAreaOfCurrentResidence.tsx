import { useEffect, useState } from 'react';
import { AreaOfResidentInfoType, AreaOfResidentInitialState, checkAgeFieldsErrors, emptyAgeFieldsErrors } from './addAreaOfCurrentResidenceController';
import { doNotify, doValidateAreaOfCurrentResident, doValidateLabel } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import { useAddAreaOfResidenceMutation, useUpdateAreaOfResidenceMutation, useGetSingleAreaOfResidenceQuery } from '../../../services/apiService/areaOfResidence/areaOfResidence';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { MdOutlineClose, MdOutlineCheck } from "react-icons/md";
import React from 'react';


function AddAreaOfResident() {
    const [areaOfResidentInfoType, setAreaOfResidentInfoTypeInfo] = useState<AreaOfResidentInfoType>(AreaOfResidentInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { areaOfCurrentResidentErrorMessage, labelErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer)

    const [addAreaOfResidenceApi, { isLoading: addAreaOfResidenceApiIsLoading }] = useAddAreaOfResidenceMutation()
    const [updateAreaOfResidenceApi, { isLoading: updateAreaOfResidenceApiIsLoading }] = useUpdateAreaOfResidenceMutation()
    const { data: getSingleArea, isSuccess: getSingleAreaApiIsSuccess, isError: getSingleAreaApiIsError, error: getSingleAreaApiError, refetch }: any = useGetSingleAreaOfResidenceQuery(id ,{ skip: !id })
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()

    const areaOfResidenceInfo = (event: any) => {
        const { name, value }: any = event.target
        setAreaOfResidentInfoTypeInfo({ ...areaOfResidentInfoType, [name]: value })
    }
    
    const handleSubmit = async () => {
        if (!checkAgeFieldsErrors(areaOfResidentInfoType, dispatch)) {
            let body: any = {
                areaName: areaOfResidentInfoType.areaName,
                description: areaOfResidentInfoType.description,
            }
            if (id) {
                await updateAreaOfResidenceApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success',  payload?.data?.message || 'Area of Current Residence updated successfully', dispatch)
                    navigate(PATH.AREAOFRESIDENT_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update Area of Current Residence', dispatch)
                })
            } else {
                await addAreaOfResidenceApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Area of Current Residence created successfully', dispatch)
                    navigate(PATH.AREAOFRESIDENT_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create Area of Current Residence', dispatch)
                })
            }
        }
    }

    const handleCancel = () => {
        emptyAgeFieldsErrors(dispatch)
        navigate(PATH.AREAOFRESIDENT_LIST)
        setAreaOfResidentInfoTypeInfo(AreaOfResidentInitialState);
    }

    useEffect(() => {
        // if (permissionsListApiIsSuccess) {
        //     checkScreenAccess(permissionsList, SCREEN_CODES.AGE, navigate);
        // }
        if (type === 'edit-area-of-residence') {
            if (!id) {
                navigate(PATH.AREAOFRESIDENT_LIST);
            } else {
                if (getSingleAreaApiIsError) {
                    navigate(PATH.AREAOFRESIDENT_LIST);
                    doNotify('error', getSingleAreaApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch);
                }
            }
        } else if (type !== 'add-area') {
        }
        if (getSingleArea && id) {
            refetch();
            let areaObj: any = getSingleArea?.data?.residence;
            setAreaOfResidentInfoTypeInfo({
                ...areaOfResidentInfoType,
                areaName: areaObj?.areaName,
                description: areaObj?.description,
            });
        }
        return () => {
            emptyAgeFieldsErrors(dispatch);
            setAreaOfResidentInfoTypeInfo(AreaOfResidentInitialState);
        };
    }, [getSingleArea, id, permissionsList, getSingleAreaApiIsError, dispatch]);
    
    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel}>
                        Area of Current Residence List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active> {type === 'add-area' ? 'Add Area of Current Residence' : 'Edit Area of Current Residence'} </Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-4">

                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="areaName">
                                        <Form.Label>Area of Current Residence*</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="Enter Area of Residence"
                                            value={areaOfResidentInfoType.areaName}
                                            name="areaName"
                                            onChange={areaOfResidenceInfo}
                                            onBlur={(event) => doValidateAreaOfCurrentResident(event.target.value, dispatch)}
                                        />
                                        <p className='error-msg'>{areaOfCurrentResidentErrorMessage}</p>
                                    </Form.Group>
                                </div>

                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="Description">
                                        <Form.Label>Label</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Label" value={areaOfResidentInfoType?.description} name='description' onChange={areaOfResidenceInfo}
                                        onBlur={() => doValidateLabel(areaOfResidentInfoType?.description, dispatch, false)}
                                        />
                                        <p className='error-msg'>{labelErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            </div>

                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button onClick={handleSubmit} disabled={addAreaOfResidenceApiIsLoading || updateAreaOfResidenceApiIsLoading} className='submit-btn'><span> {addAreaOfResidenceApiIsLoading || updateAreaOfResidenceApiIsLoading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AddAreaOfResident;
