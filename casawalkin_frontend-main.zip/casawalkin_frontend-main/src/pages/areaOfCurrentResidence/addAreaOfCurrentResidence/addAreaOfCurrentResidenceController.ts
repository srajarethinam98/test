import messages from '../../../constants/messageConstants'
import {  setAreaOfCurrentResidentErrorMessage, setLabelErrorMessage } from "../../../base/reducer/errorMessageReducer"
import {  doValidateAreaOfCurrentResident, doValidateLabel } from "../../../utils/utils"

export type AreaOfResidentInfoType = {
    areaName: string,
    description: string,
}

export const AreaOfResidentInitialState = {
    areaName: '',
    description: '',
}

// export const ageFieldsValidation = (event: any, dispatch: any) => {
//     const { name, value } = event.target
//     switch (name) {
//         // case 'minAge':
//         //     value !== '' ? dispatch(setMinAgeErrorMessage('')) : dispatch(setMinAgeErrorMessage(`${messages.emptyField} Min Age`))
//         //     break
//         // case 'maxAge':
//         //     value !== '' ? dispatch(setMaxAgeErrorMessage('')) : dispatch(setMaxAgeErrorMessage(`${messages.emptyField} Max Age`))
//         //     break
//     }
// }

export const checkAgeFieldsErrors = (AreaOfResidentInfoType: AreaOfResidentInfoType, dispatch: any) => {
    doValidateAreaOfCurrentResident((AreaOfResidentInfoType.areaName), dispatch)
    doValidateLabel((AreaOfResidentInfoType.description), dispatch, false)

    if (doValidateAreaOfCurrentResident((AreaOfResidentInfoType.areaName), dispatch)
        && doValidateLabel((AreaOfResidentInfoType.description), dispatch, false)
    ) {
        return false
    }
    return true
}

export const emptyAgeFieldsErrors = (dispatch: any) => {
    dispatch(setAreaOfCurrentResidentErrorMessage(''))
    dispatch(setLabelErrorMessage(''))
}