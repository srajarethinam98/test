import { useEffect } from 'react';
import { Button } from 'react-bootstrap';
import { useDeleteAreaOfResidenceMutation, useListAreaOfResidenceQuery } from '../../../services/apiService/areaOfResidence/areaOfResidence';
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { PATH } from '../../../constants/path';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import NoData from '../../miscellanious/noData/index';
import Loading from '../../miscellanious/tableLoader/index';
import { AiOutlinePlus, AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai';

function ListAreaOfResident() {
    const dispatch = useAppDispatch();
    const navigate = useCustomNavigate();

    const [deleteAgeApi] = useDeleteAreaOfResidenceMutation();
    const { data: areaOfResidenceListData, isLoading: areaOfResidenceListApiIsLoading, isSuccess: areaOfResidenceListApiIsSuccess, error: areaOfResidenceListApiError } = useListAreaOfResidenceQuery(undefined); // Use the new hook
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery();

    const deleteage = async (id: any) => {
        await deleteAgeApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'Area of Current Residence deleted successfully', dispatch);
        }).catch((err: any) => {
            if (err?.data?.statusCode === 401) {
                dispatch(setUnAuthorized(true));
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete Area of Current Residence', dispatch);
        });
    };

    // useEffect(() => {
    //     if (permissionsListApiIsSuccess) {
    //         checkScreenAccess(permissionsList, SCREEN_CODES.AGE, navigate);
    //     }
    // }, [permissionsList]);

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Area of Current Residence List</h5>
                    <Button className='add-btn mx-3' onClick={() => navigate(PATH.AREAOFRESIDENT_ADD)}><span><AiOutlinePlus /> Create Area of Current Residence</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ textAlign: 'left' }}>S.No</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Area of Current Residence</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Label</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        !areaOfResidenceListApiIsLoading ? areaOfResidenceListApiIsSuccess ? areaOfResidenceListData?.data?.residence?.length > 0 ?
                                        areaOfResidenceListData?.data?.residence?.map((areaOfResidence: any, index: any) => {
                                                let id = areaOfResidence?._id;
                                                let areaName = areaOfResidence?.areaName;

                                                return (
                                                    <tr key={index}>
                                                        <td>{index + 1}</td>
                                                        <td>{areaName || '-'}</td>
                                                        <td>{areaOfResidence?.description || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/area-of-residence/edit-area-of-residence/?id=${id}`);
                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deleteage(id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                );
                                            }) : <><NoData /></> : <>Api error</> : <><Loading /></>
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default ListAreaOfResident;
