import { useEffect, useState } from 'react'
import { occupationInfoType, occupationFieldsValidation, occupationInitialState, checkOccupationsFieldsErrors, emptyOccupationFieldsErrors } from './occupationController';
import { doNotify, doValidateOccupationName, doValidateLabel } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { useCreateOccupationMutation, useEditOccupationMutation, useGetSingleOccupationQuery } from '../../../services/apiService/occupation/occupation';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function OccupationAdd() {
    const [occupationInfo, setOccupationInfo] = useState<occupationInfoType>(occupationInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { occupationErrorMessage, labelErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer)

    const [creatoccupationsApi, { isLoading: creatoccupationApiIsloading }] = useCreateOccupationMutation()
    const [editoccupationsApi, { isLoading: editoccupationApiIsloading }] = useEditOccupationMutation()
    const { data: getSingleoccupation, isSuccess: getSingleoccupationApiIsSuccess, isError: getSingleoccupationApiIsError, error: getSingleoccupationApiError }: any = useGetSingleOccupationQuery(id, { skip: !id })
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()

    const getoccupationInfo = (event: any) => {
        const { name, value }: any = event.target
        setOccupationInfo({ ...occupationInfo, [name]: value })
        occupationFieldsValidation(event, dispatch)
    }

    const handleSubmit = async () => {
        if (!checkOccupationsFieldsErrors(occupationInfo, dispatch)) {
            let body: any = {
                occupation: occupationInfo.name,
                description: occupationInfo.description,
            }
            if (id) {
                await editoccupationsApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Occupation updated successfully', dispatch)
                    navigate(PATH.OCCUPATION_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update Occupation', dispatch)
                })
            } else {
                await creatoccupationsApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Occupation created successfully', dispatch)
                    navigate(PATH.OCCUPATION_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create Occupation', dispatch)
                })
            }
        }
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.OCCUPATION, navigate)
        }
        if (type === 'edit-occupation') {
            !id && navigate(PATH.OCCUPATION_LIST)
            if (getSingleoccupationApiIsError) {
                navigate(PATH.OCCUPATION_LIST)
                doNotify('error', getSingleoccupationApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        }
        if (getSingleoccupationApiIsSuccess) {
            let occupationObj: any = getSingleoccupation?.data?.occupation
            setOccupationInfo({
                ...occupationInfo,
                name: occupationObj?.occupation,
                description: occupationObj?.description
            })
        }
        return () => {
            emptyOccupationFieldsErrors(dispatch)
            setOccupationInfo(occupationInitialState)
        }
    }, [getSingleoccupation, id, permissionsList, getSingleoccupationApiIsError])
    
    const handleCancel = () => {
        emptyOccupationFieldsErrors(dispatch)
        navigate(PATH.OCCUPATION_LIST)
        setOccupationInfo(occupationInitialState)
    }

    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-2'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel}>
                            Occupation List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type === 'add-occupation' ? 'Add occupation' : 'Edit occupation'}</Breadcrumb.Item>
                    </Breadcrumb>
                </div>

                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-4">
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="occupation">
                                        <Form.Label>Occupation*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Occupation" value={occupationInfo?.name || ''} name='name' onChange={getoccupationInfo} onBlur={(event) => doValidateOccupationName(event.target.value, dispatch)} />
                                        <p className='error-msg'>{occupationErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="description">
                                        <Form.Label>Label</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Label" value={occupationInfo?.description || ''} name='description' onChange={getoccupationInfo}
                                        onBlur={() => doValidateLabel(occupationInfo.description, dispatch, false)}
                                        />
                                        <p className='error-msg'>{labelErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            </div>

                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button onClick={handleSubmit} disabled={creatoccupationApiIsloading || editoccupationApiIsloading} className='submit-btn'><span> {creatoccupationApiIsloading || editoccupationApiIsloading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default OccupationAdd