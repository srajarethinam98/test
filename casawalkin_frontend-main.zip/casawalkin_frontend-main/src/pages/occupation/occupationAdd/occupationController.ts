import messages from '../../../constants/messageConstants'
import { setOccupationErrorMessage, setLabelErrorMessage } from "../../../base/reducer/errorMessageReducer"
import { doValidateOccupationName, doValidateLabel } from "../../../utils/utils"

export type occupationInfoType = {
    name: string,
    description: string,
}

export const occupationInitialState: occupationInfoType = {
    name: '',
    description: '',
}

export const occupationFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'name':
            value !== '' ? dispatch(setOccupationErrorMessage('')) : dispatch(setOccupationErrorMessage(`${messages.emptyField} Occupation`))
            break
        
    }
}

export const checkOccupationsFieldsErrors = (occupationInfo: occupationInfoType, dispatch: any) => {
    doValidateOccupationName((occupationInfo.name), dispatch)
    doValidateLabel((occupationInfo.description), dispatch, false)
    
    if (doValidateOccupationName((occupationInfo.name), dispatch) && doValidateLabel((occupationInfo.description), dispatch, false)
    ) {
        return false
    }
    return true
}

export const emptyOccupationFieldsErrors = (dispatch: any) => {
    dispatch(setOccupationErrorMessage(''))
    dispatch(setLabelErrorMessage(''))
   
}