import { useEffect } from 'react'
import { Button } from 'react-bootstrap'
import { useGetOccupationListQuery, useDeleteOccupationMutation } from '../../../services/apiService/occupation/occupation';
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { PATH } from '../../../constants/path';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import Loading from '../../miscellanious/tableLoader/index'
import NoData from '../../miscellanious/noData/index'
import { AiOutlinePlus,AiOutlineEdit ,AiOutlineDelete} from "react-icons/ai";

function OccupationList() {
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const [deleteOccupationApi] = useDeleteOccupationMutation()

    const { data: occupationListData, isLoading: occupationListApiIsLoading, isSuccess: occupationListApiIsSuccess } = useGetOccupationListQuery()

    const deleteoccupation = async (id: any) => {
        await deleteOccupationApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'Occupation deleted successfully', dispatch)
        }).catch((err: any) => {
            if (err?.data?.statusCode===401) {
                dispatch(setUnAuthorized(true))
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete Occupation', dispatch)
        })
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.OCCUPATION, navigate)
        }
    }, [permissionsList])

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Occupation List</h5>
                    <Button className='add-btn mx-3' onClick={() => navigate(PATH.OCCUPATION_ADD)}><span><AiOutlinePlus /> Create Occupation</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ textAlign: 'left' }}>S.No</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>occupation</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Label</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        !occupationListApiIsLoading ? occupationListApiIsSuccess ?occupationListData?.data?.occupations?.length>0?
                                            occupationListData?.data?.occupations?.map((occupationObj: any, index: any) => {
                                                let id = occupationObj?._id
                                                return (
                                                    <tr key={index}>

                                                        <td>{index + 1}</td>
                                                        <td>{occupationObj?.occupation || '-'}</td>
                                                        <td>{occupationObj?.description || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/occupation/edit-occupation/?id=${id}`)

                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deleteoccupation(id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }):<NoData/> : <>Api error</> : <Loading/>
                                        }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default OccupationList