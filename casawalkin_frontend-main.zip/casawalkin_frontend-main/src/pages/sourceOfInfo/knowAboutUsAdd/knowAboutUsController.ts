import messages from '../../../constants/messageConstants'
import { setknowAboutUsErrorMessage, setLabelErrorMessage } from "../../../base/reducer/errorMessageReducer"
import { doValidateKnowAboutUs, doValidateLabel } from "../../../utils/utils"

export type knowAboutUsInfoType = {
    name: string,
    description: string,
}

export const knowAboutUsInitialState: knowAboutUsInfoType = {
    name: '',
    description: '',
}

export const knowAboutUsFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'name':
            value !== '' ? dispatch(setknowAboutUsErrorMessage('')) : dispatch(setknowAboutUsErrorMessage(`${messages.emptyField} Source Of Info`))
            break
    }
}

export const checkKnowAboutUssFieldsErrors = (knowAboutUsInfo: knowAboutUsInfoType, dispatch: any) => {
    doValidateKnowAboutUs((knowAboutUsInfo.name), dispatch)
    doValidateLabel(knowAboutUsInfo.description, dispatch, false)
    if (doValidateKnowAboutUs((knowAboutUsInfo.name), dispatch) && doValidateLabel(knowAboutUsInfo.description, dispatch, false)) {
        return false
    }
    return true
}

export const emptyKnowAboutUsFieldsErrors = (dispatch: any) => {
    dispatch(setknowAboutUsErrorMessage(''))
    dispatch(setLabelErrorMessage(''))
   
}