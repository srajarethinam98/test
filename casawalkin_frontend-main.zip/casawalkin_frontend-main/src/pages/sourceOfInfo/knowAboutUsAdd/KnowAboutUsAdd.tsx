import { useEffect, useState } from 'react'
import { knowAboutUsInfoType, knowAboutUsFieldsValidation, knowAboutUsInitialState, checkKnowAboutUssFieldsErrors, emptyKnowAboutUsFieldsErrors } from './knowAboutUsController';
import { doNotify, doValidateKnowAboutUs, doValidateLabel } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Spinner } from 'react-bootstrap';
import { useCreateSourceOfinfoMutation, useEditSourceOfinfoMutation, useGetSingleSourceOfinfoQuery } from '../../../services/apiService/sourceOfInfo/sourceOfInfo';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function KnowAboutUsAdd() {
    const [knowAboutUsInfo, setknowAboutUsInfo] = useState<knowAboutUsInfoType>(knowAboutUsInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { knowAboutUsErrorMessage, labelErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer)

    const [creatknowAboutUssApi, { isLoading: creatknowAboutUsApiIsloading }] = useCreateSourceOfinfoMutation()
    const [editknowAboutUssApi, { isLoading: editknowAboutUsApiIsloading }] = useEditSourceOfinfoMutation()
    const { data: getSingleknowAboutUs, isSuccess: getSingleknowAboutUsApiIsSuccess, isError: getSingleknowAboutUsApiIsError, error: getSingleknowAboutUsApiError }: any = useGetSingleSourceOfinfoQuery(id, { skip: !id })

    const getknowAboutUsInfo = (event: any) => {
        const { name, value }: any = event.target
        setknowAboutUsInfo({ ...knowAboutUsInfo, [name]: value })
        knowAboutUsFieldsValidation(event, dispatch)
    }

    const handleSubmit = async () => {
        if (!checkKnowAboutUssFieldsErrors(knowAboutUsInfo, dispatch)) {
            let body: any = {
                source: knowAboutUsInfo.name,
                description: knowAboutUsInfo.description,
            }
            if (id) {
                await editknowAboutUssApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'knowAboutUs updated successfully', dispatch)
                    navigate(PATH.KNOW_ABOUT_US_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update knowAboutUs', dispatch)
                })
            } else {
                await creatknowAboutUssApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'knowAboutUs created successfully', dispatch)
                    navigate(PATH.KNOW_ABOUT_US_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create knowAboutUs', dispatch)
                })
            }
        }
    }

    useEffect(() => {
        if (type === 'edit-knowAboutUs') {
            !id && navigate(PATH.KNOW_ABOUT_US_LIST)
            if (getSingleknowAboutUsApiIsError) {
                navigate(PATH.KNOW_ABOUT_US_LIST)
                doNotify('error', getSingleknowAboutUsApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        }
        if (getSingleknowAboutUsApiIsSuccess) {
            let knowAboutUsObj: any = getSingleknowAboutUs?.data?.source
            setknowAboutUsInfo({
                ...knowAboutUsInfo,
                name: knowAboutUsObj?.source,
                description: knowAboutUsObj?.description
            })
        }
        return () => {
            emptyKnowAboutUsFieldsErrors(dispatch)
            setknowAboutUsInfo(knowAboutUsInitialState)
        }
    }, [getSingleknowAboutUs, id, getSingleknowAboutUsApiIsError])
    
    const handleCancel = () => {
        emptyKnowAboutUsFieldsErrors(dispatch)
        navigate(PATH.KNOW_ABOUT_US_LIST)
        setknowAboutUsInfo(knowAboutUsInitialState)
    }
    
    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-2'>
                    <h5 className='page-title'>{type === 'add-knowAboutUs' ? 'Add Source Of Info' : 'Edit Source Of Info'}</h5>
                    <Button className='add-btn mx-3' onClick={handleCancel}><span> Back</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-4">
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="knowaboutus">
                                        <Form.Label>Know About US*</Form.Label>
                                        <Form.Control type="text" placeholder="How You Know About US" value={knowAboutUsInfo?.name} name='name' onChange={getknowAboutUsInfo} onBlur={(event) => doValidateKnowAboutUs(event.target.value, dispatch)} />
                                        <p className='error-msg'>{knowAboutUsErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="Description">
                                        <Form.Label>Label</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Label" value={knowAboutUsInfo?.description} name='description' onChange={getknowAboutUsInfo}
                                        onBlur={() => doValidateLabel(knowAboutUsInfo.description, dispatch, false)}
                                        />
                                        <p className='error-msg'>{labelErrorMessage}</p>                                        
                                    </Form.Group>
                                </div>
                            </div>
                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button className='submit-btn' disabled={creatknowAboutUsApiIsloading || editknowAboutUsApiIsloading} onClick={handleSubmit}><span> {creatknowAboutUsApiIsloading || editknowAboutUsApiIsloading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default KnowAboutUsAdd