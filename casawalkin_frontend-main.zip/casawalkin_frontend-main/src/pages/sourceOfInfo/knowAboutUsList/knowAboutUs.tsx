import { Button } from 'react-bootstrap'
import { useGetSourceOfinfoListQuery, useDeleteSourceOfinfoMutation } from '../../../services/apiService/sourceOfInfo/sourceOfInfo';
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { PATH } from '../../../constants/path';
import Loading from '../../miscellanious/tableLoader/index'
import NoData from '../../miscellanious/noData/index'
import { AiOutlinePlus,AiOutlineEdit ,AiOutlineDelete} from "react-icons/ai";

function KnowAboutUs() {
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()

    const [deleteKnowAboutUsApi] = useDeleteSourceOfinfoMutation()
    const { data: knowAboutUsListData, isLoading: knowAboutUsListApiIsLoading, isSuccess: knowAboutUsListApiIsSuccess } = useGetSourceOfinfoListQuery()
    
    const deleteknowAboutUs = async (id: any) => {
        await deleteKnowAboutUsApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'Source Of Info deleted successfully', dispatch)
        }).catch((err: any) => {
            if (err?.data?.statusCode === 401) {
                dispatch(setUnAuthorized(true))
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete Source Of Info', dispatch)
        })
    }
    
    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Source Of Information List</h5>
                    <Button className='add-btn mx-3' onClick={() => navigate(PATH.KNOW_ABOUT_US_ADD)}><span><AiOutlinePlus /> Create Source Of Info</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">

                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ textAlign: 'left' }}>S.No</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Know About Us</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Label</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        !knowAboutUsListApiIsLoading ? knowAboutUsListApiIsSuccess ?knowAboutUsListData?.data?.sources?.length>0?
                                            knowAboutUsListData?.data?.sources?.map((knowAboutUsObj: any, index: any) => {
                                                let id = knowAboutUsObj?._id
                                                return (
                                                    <tr key={index}>

                                                        <td>{index + 1}</td>
                                                        <td>{knowAboutUsObj?.source || '-'}</td>
                                                        <td>{knowAboutUsObj?.description || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/knowAboutUs/edit-knowAboutUs/?id=${id}`)

                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deleteknowAboutUs(id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }):<NoData/> : <>Api error</> : <Loading/>
                                        }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default KnowAboutUs