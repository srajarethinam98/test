import { MdOutlineReport } from "react-icons/md";
import './nodata.scss'

function Index() {
  return (
      <tr><td colSpan={12}>
        <div className='no-data-found'>
          <figure>
          <MdOutlineReport />
          </figure>
          <label>No Data Found</label>
        </div>
      </td></tr>

  )
}

export default Index