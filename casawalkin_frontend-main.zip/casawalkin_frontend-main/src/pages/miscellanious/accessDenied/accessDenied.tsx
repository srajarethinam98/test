import styles from './accessDenied.module.scss'
import deniedimg from "../../../assets/denied.jpg";
import { useCustomNavigate } from '../../../base/hooks/hooks';
import { PATH } from '../../../constants/path';

function AccessDenied() {
    const navigate = useCustomNavigate()
    return (
        <>
            <div className="dashboard-wrapper">
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <div className={styles.accessdeniedWrapper}>
                            <figure>
                                <img loading="lazy" src={deniedimg}  alt="denied" />
                            </figure>
                            <h2>Access Denied</h2>
                            <h3>The page you're  trying to access has restricted access. Please contact CASA Walkin admin for assistance</h3>
                            <button onClick={() => navigate(PATH.DASHBOARD)}>Dashboard </button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AccessDenied