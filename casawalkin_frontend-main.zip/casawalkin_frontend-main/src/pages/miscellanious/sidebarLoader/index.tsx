import { Card, Placeholder } from "react-bootstrap"

const Sidebarloader = () => {
    return (
        <>
            <Card style={{ width: '18rem' }}>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={7} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={8} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={8} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={7} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={8} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={8} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={7} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={8} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={8} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={7} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={8} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={7} />
                </Placeholder>
                <Placeholder as={Card.Title} animation="glow">
                    <Placeholder size="sm" xs={8} />
                </Placeholder>
            </Card>
        </>
    )
}
export default Sidebarloader