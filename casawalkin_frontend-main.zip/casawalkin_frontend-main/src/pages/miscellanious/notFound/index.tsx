import styles from './notFound.module.scss'
import PagenotFound from "../../../assets/pagenotfound.png";
import { useCustomNavigate } from '../../../base/hooks/hooks';
import { PATH } from '../../../constants/path';

function Index() {
  const navigate=useCustomNavigate()
  return (
    <>
      <div className={styles.pageNotfoundWrapper}>
        <figure>
          <img loading="lazy" src={PagenotFound}/>
        </figure>
        <h2>oops</h2>
        <h3>Page Not Found</h3>
        <button  onClick={()=>navigate(PATH.DASHBOARD)}>Dashboard</button>
    </div>
    </>

  )
}

export default Index