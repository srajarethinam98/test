
import { Spinner } from 'react-bootstrap'
import './table-loader.scss'

function Index() {
  return (
    <>
      <tr><td colSpan={10000}>
        <div className='table-custom-content-loader'>
          <Spinner animation="border" variant="secondary" />
        </div>
      </td></tr>

    </>
  )
}

export default Index