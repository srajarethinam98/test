import React, { useEffect } from 'react'
import { useGetDashboardDetailsQuery } from '../../services/apiService/dashboard/dashboard';
import { useGetRolePermissionsQuery } from '../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../utils/commonUtils';
import { SCREEN_CODES } from '../../constants/screensConstants';
import { useCustomNavigate } from '../../base/hooks/hooks';
import Loading from '../miscellanious/loading/index'
import { AiOutlineAudit, AiOutlineUsergroupAdd, AiOutlineUser, AiOutlineSchedule } from "react-icons/ai";
import { CiCircleCheck } from "react-icons/ci";
import { LiaUserClockSolid } from "react-icons/lia";

function Index() {
  const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
  const { data: dashboardData, isLoading: dashboardApiIsLoading, isSuccess: dashboardApiIsSuccess } = useGetDashboardDetailsQuery()
  const navigate = useCustomNavigate()

  useEffect(() => {
    if (permissionsListApiIsSuccess) {
      checkScreenAccess(permissionsList, SCREEN_CODES.DASHBOARD, navigate)
    }
  }, [permissionsList])

  return (
    <>
      <div className="dashboard-wrapper">
        <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
          <h5 className='page-title'>Dashboard</h5>
        </div>
        <div className="container-fluid p-0">
          {!dashboardApiIsLoading ? dashboardApiIsSuccess ? <div className="row gy-3">
            <div className="col-md-4">
              <div className="card widget-rounded-circle">
                <div className="card-body">
                  <div className="row">
                    <div className="col-3">
                      <div className='avatar-lg rounded-circle bg-soft-primary border-primary border'>
                        <AiOutlineAudit className='dashboard-icon' />
                      </div>
                    </div>
                    <div className="col-9">
                      <div className="text-end">
                        <h3 className="text-dark mt-1">{dashboardData?.data?.data?.new || 0}</h3>
                        <p className="text-muted mb-1 ">Total New leads</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card widget-rounded-circle">
                <div className="card-body">
                  <div className="row">
                    <div className="col-3">
                      <div className='avatar-lg rounded-circle bg-soft-success border-success border'>
                        <CiCircleCheck className='dashboard-icon' />
                      </div>
                    </div>
                    <div className="col-9">
                      <div className="text-end">
                        <h3 className="text-dark mt-1">{dashboardData?.data?.data?.open || 0}</h3>
                        <p className="text-muted mb-1 ">Total open leads</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card widget-rounded-circle">
                <div className="card-body">
                  <div className="row">
                    <div className="col-3">
                      <div className='avatar-lg rounded-circle bg-soft-warning border-warning border'>
                        <AiOutlineUsergroupAdd className='dashboard-icon' />
                      </div>
                    </div>
                    <div className="col-9">
                      <div className="text-end">
                        <h3 className="text-dark mt-1">{dashboardData?.data?.data?.totalCustomersCount || 0}</h3>
                        <p className="text-muted mb-1 ">Total Customers</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card widget-rounded-circle">
                <div className="card-body">
                  <div className="row">
                    <div className="col-3">
                      <div className='avatar-lg rounded-circle bg-info-soft border'>
                        <AiOutlineUser className='dashboard-icon' />
                      </div>
                    </div>
                    <div className="col-9">
                      <div className="text-end">
                        <h3 className="text-dark mt-1">{dashboardData?.data?.data?.qualified || 0}</h3>
                        <p className="text-muted mb-1 ">Qualified Leads</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card widget-rounded-circle">
                <div className="card-body">
                  <div className="row">
                    <div className="col-3">
                      <div className='avatar-lg rounded-circle bg-soft-primary border-primary border'>
                        <AiOutlineSchedule className='dashboard-icon' />
                      </div>
                    </div>
                    <div className="col-9">
                      <div className="text-end">
                        <h3 className="text-dark mt-1">{dashboardData?.data?.data?.scheduled || 0}</h3>
                        <p className="text-muted mb-1 ">Site Visit Scheduled Leads</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card widget-rounded-circle">
                <div className="card-body">
                  <div className="row">
                    <div className="col-3">
                      <div className='avatar-lg rounded-circle bg-blue-soft border'>
                        <LiaUserClockSolid className='dashboard-icon' />
                      </div>
                    </div>
                    <div className="col-9">
                      <div className="text-end">
                        <h3 className="text-dark mt-1">{dashboardData?.data?.data?.happened || 0}</h3>
                        <p className="text-muted mb-1 ">Site Visit Happened Leads</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card widget-rounded-circle">
                <div className="card-body">
                  <div className="row">
                    <div className="col-3">
                      <div className='avatar-lg rounded-circle bg-warning-soft border'>
                        <AiOutlineUser className='dashboard-icon' />
                      </div>
                    </div>
                    <div className="col-9">
                      <div className="text-end">
                        <h3 className="text-dark mt-1">{dashboardData?.data?.data?.booked || 0}</h3>
                        <p className="text-muted mb-1 ">Total Booked Leads</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card widget-rounded-circle">
                <div className="card-body">
                  <div className="row">
                    <div className="col-3">
                      <div className='avatar-lg rounded-circle bg-warning-soft border'>
                        <AiOutlineUser className='dashboard-icon' />
                      </div>
                    </div>
                    <div className="col-9">
                      <div className="text-end">
                        <h3 className="text-dark mt-1">{dashboardData?.data?.data?.unqualified || 0}</h3>
                        <p className="text-muted mb-1 ">Total Lost Leads</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div> : 'Api Error' : <Loading />}
        </div>
      </div>
    </>
  )
}

export default Index