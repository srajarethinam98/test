import { useEffect } from 'react';
import { useAppDispatch, useAppSelector } from '../../../base/hooks/hooks';
import { setMessageInfo, setMessageNotify, setMessageType } from '../../../base/reducer/alertReducer'
import Toast from 'react-bootstrap/Toast';

function CustomAlert() {
    const { messageNotify ,messageInfo,messageType} = useAppSelector((state: any) => state.alertReducer)
    const dispatch = useAppDispatch()

    const errorModelClose = () => {
        setTimeout(() => {
        dispatch(setMessageNotify(false))
        dispatch(setMessageInfo(""))
        dispatch(setMessageType(""))
        }, 3000);
    }

    useEffect(() => {
        if (messageNotify ) {
            errorModelClose()
        }
    }, [messageNotify])
   
    return (
        <Toast className={messageType==='success'?`bg-success-light`:messageType==='error'?'bg-danger-light':messageType==='warning'?'bg-warning-light':''}
         style={{
            position: 'absolute',
            top: 10,
            right: 10,
            zIndex: 9999 
        }}>
            <Toast.Header>
            </Toast.Header>
            <Toast.Body >{messageInfo}</Toast.Body>
        </Toast>
    )


}
export default CustomAlert
