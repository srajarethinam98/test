import messages from '../../../constants/messageConstants'
import {  setMaxAgeErrorMessage, setMinAgeErrorMessage, setLabelErrorMessage } from "../../../base/reducer/errorMessageReducer"
import {  doValidateLabel, doValidateMaxAge, doValidateMinAge } from "../../../utils/utils"

export type ageInfoType = {
    minAge: string,
    maxAge: string,
    description: string,
}

export const ageInitialState: ageInfoType = {
    minAge: '',
    maxAge: '',
    description: '',
}

export const ageFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'minAge':
            value !== '' ? dispatch(setMinAgeErrorMessage('')) : dispatch(setMinAgeErrorMessage(`${messages.emptyField} Min Age`))
            break
        case 'maxAge':
            value !== '' ? dispatch(setMaxAgeErrorMessage('')) : dispatch(setMaxAgeErrorMessage(`${messages.emptyField} Max Age`))
            break
    }
}

export const checkAgeFieldsErrors = (ageInfo: ageInfoType, dispatch: any) => {
    doValidateMinAge((ageInfo.minAge), dispatch)
    doValidateMaxAge((ageInfo.maxAge), ageInfo.minAge, dispatch)
    doValidateLabel((ageInfo.description), dispatch, false)

    if (doValidateMinAge((ageInfo.minAge), dispatch) &&
        doValidateMaxAge((ageInfo.maxAge), ageInfo.minAge, dispatch) &&
        doValidateLabel((ageInfo.description), dispatch, false)
    ) {
        return false
    }
    return true
}

export const emptyAgeFieldsErrors = (dispatch: any) => {
    dispatch(setMinAgeErrorMessage(''))
    dispatch(setMaxAgeErrorMessage(''))
    dispatch(setLabelErrorMessage(''))
}