import { useEffect, useState } from 'react'
import { ageInfoType, ageFieldsValidation, ageInitialState, checkAgeFieldsErrors, emptyAgeFieldsErrors } from './ageController';
import { doNotify, doValidateMinAge, doValidateMaxAge, doValidateLabel } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import { useCreateAgeMutation, useEditAgeMutation, useGetSingleAgeQuery } from '../../../services/apiService/ages/ageService';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function AgeAdd() {
    const [ageInfo, setageInfo] = useState<ageInfoType>(ageInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { minAgeErrorMessage, maxAgeErrorMessage, labelErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer)

    const [creatagesApi, { isLoading: creatageApiIsloading }] = useCreateAgeMutation()
    const [editagesApi, { isLoading: editageApiIsloading }] = useEditAgeMutation()
    const { data: getSingleage, isSuccess: getSingleageApiIsSuccess, isError: getSingleageApiIsError, error: getSingleageApiError }: any = useGetSingleAgeQuery(id, { skip: !id })
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()

    const getageInfo = (event: any) => {
        const { name, value }: any = event.target
        setageInfo({ ...ageInfo, [name]: value })
        ageFieldsValidation(event, dispatch)
    }

    const handleSubmit = async () => {
        if (!checkAgeFieldsErrors(ageInfo, dispatch)) {
            let body: any = {
                minAge: ageInfo.minAge,
                maxAge: ageInfo.maxAge,
                description: ageInfo.description,
            }
            if (id) {
                await editagesApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Age updated successfully', dispatch)
                    navigate(PATH.AGE_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update Age', dispatch)
                })
            } else {
                await creatagesApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Age created successfully', dispatch)
                    navigate(PATH.AGE_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create Age', dispatch)
                })
            }
        }
    }

    const handleCancel = () => {
        emptyAgeFieldsErrors(dispatch)
        navigate(PATH.AGE_LIST)
        setageInfo(ageInitialState)
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.AGE, navigate)
        }
        if (type === 'edit-age') {
            !id && navigate(PATH.AGE_LIST)
            if (getSingleageApiIsError) {
                navigate(PATH.AGE_LIST)
                doNotify('error', getSingleageApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        } else if (type !== 'add-age') {
        }
        if (getSingleageApiIsSuccess) {
            let ageObj: any = getSingleage?.data?.ageRange
            setageInfo({
                ...ageInfo,
                minAge: ageObj?.minAge,
                maxAge: ageObj?.maxAge,
                description: ageObj?.description
            })
        }
        return () => {
            emptyAgeFieldsErrors(dispatch)
            setageInfo(ageInitialState)
        }
    }, [getSingleage, id, permissionsList, getSingleageApiIsError])

    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel}>
                            Age List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active> {type === 'add-age' ? 'Add age' : 'Edit age'} </Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-4">

                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="minAge">
                                        <Form.Label>Min Age*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Min Age" value={ageInfo?.minAge} name='minAge' onChange={getageInfo} onBlur={(event) => doValidateMinAge(event.target.value, dispatch)} />
                                        <p className='error-msg'>{minAgeErrorMessage}</p>
                                    </Form.Group>
                                </div>

                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="maxAge">
                                        <Form.Label>Max Age*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Max Age" value={ageInfo?.maxAge} name='maxAge' onChange={getageInfo} onBlur={(event) => doValidateMaxAge(event.target.value, ageInfo?.minAge, dispatch)} />
                                        <p className='error-msg'>{maxAgeErrorMessage}</p>
                                    </Form.Group>
                                </div>

                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="Description">
                                        <Form.Label>Label</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Label" value={ageInfo?.description} name='description' onChange={getageInfo}
                                        onBlur={() => doValidateLabel(ageInfo.description, dispatch, false)}
                                        />
                                        <p className='error-msg'>{labelErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            </div>

                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button onClick={handleSubmit} disabled={creatageApiIsloading || editageApiIsloading} className='submit-btn'><span> {creatageApiIsloading || editageApiIsloading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AgeAdd