import { useEffect } from 'react'
import { Button } from 'react-bootstrap'
import { useGetAgeListQuery, useDeleteAgeMutation } from '../../../services/apiService/ages/ageService';
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { PATH } from '../../../constants/path';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import NoData from '../../miscellanious/noData/index'
import Loading from '../../miscellanious/tableLoader/index'
import { AiOutlinePlus,AiOutlineEdit ,AiOutlineDelete} from "react-icons/ai";


function AgeList() {
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()

    const [deleteAgeApi] = useDeleteAgeMutation()
    const { data: ageListData, isLoading: ageListApiIsLoading, isSuccess: ageListApiIsSuccess,error:ageListApiError } = useGetAgeListQuery()
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const deleteage = async (id: any) => {
        await deleteAgeApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'age deleted successfully', dispatch)
        }).catch((err: any) => {
            if (err?.data?.statusCode===401) {
                dispatch(setUnAuthorized(true))
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete age', dispatch)
        })
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.AGE, navigate)
        }
    }, [permissionsList])

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Age List</h5>
                    <Button className='add-btn mx-3' onClick={() => navigate(PATH.AGE_ADD)}><span><AiOutlinePlus /> Create Age Range</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">

                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ textAlign: 'left' }}>S.No</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Age Range</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Label</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    {
                                        !ageListApiIsLoading ? ageListApiIsSuccess ?ageListData?.data?.ageRanges?.length>0?
                                            ageListData?.data?.ageRanges?.map((ageObj: any, index: any) => {
                                                let id = ageObj?._id
                                                let ageRange = `${ageObj?.minAge} - ${ageObj?.maxAge}`

                                                return (
                                                    <tr key={index}>

                                                        <td>{index + 1}</td>
                                                        <td>{ageRange || '-'}</td>
                                                        <td>{ageObj?.description || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/age/edit-age/?id=${id}`)

                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deleteage(id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }) :<><NoData /></>: <>Api error</> : <><Loading /></>
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AgeList