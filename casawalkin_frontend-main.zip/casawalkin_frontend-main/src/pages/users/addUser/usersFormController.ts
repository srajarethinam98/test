import { setEmailErrorMessage, setNameErrorMessage, setProjectErrorMessage, setUserMobileErrorMessage, setPasswordErrorMessage, setLastNameErrorMessage, setFirstNameErrorMessage, setUserRoleErrorMessage, setEditPasswordErrorMessage } from "../../../base/reducer/errorMessageReducer"
import messages from '../../../constants/messageConstants'
import { convertToSelectOptions } from "../../../utils/commonUtils"
import { doValidateEmail, doValidatefullName, doValidateProject, doValidateFirstName, doValidateLatName, doValidateUserMobileNumber, doValidatePassword, doValidateUserRole, doValidateEditPassword } from "../../../utils/utils"

export type userInfoType = {
    userName: string
    firstName: string,
    lastName: string,
    employeeCode: string,
    email: string,
    password: string,
    mobile: any,
    department: any,
    project: any,
    userRole: any,
    isAdminRole: boolean,
    adminRole:boolean
}

export const userInitialState: userInfoType = {
    userName: '',
    firstName: '',
    lastName: '',
    employeeCode: '',
    email: '',
    password: '',
    mobile: '',
    department: '',
    project: '',
    userRole: '',
    isAdminRole: false,
    adminRole:false
}

export const getAquisitionFormOptionsInfo = (dropdowndata: any) => {
    return {
        userRoles: convertToSelectOptions(dropdowndata.roles || []),
        projects: convertToSelectOptions(dropdowndata.projects || []),
        departments: convertToSelectOptions(dropdowndata.departments || []),
        salesRoles: convertToSelectOptions(dropdowndata.svctl || []),
    }
}

export const userFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'userName':
            value !== '' ? dispatch(setNameErrorMessage('')) : dispatch(setNameErrorMessage(`${messages.emptyField} Name`))
            break
        case 'firstName':
            value !== '' ? dispatch(setFirstNameErrorMessage('')) : dispatch(setFirstNameErrorMessage(`${messages.emptyField} First Name`))
            break
        case 'lastName':
            value !== '' ? dispatch(setLastNameErrorMessage('')) : dispatch(setLastNameErrorMessage(`${messages.emptyField} Last Name`))
            break
        case 'email':
            value !== '' ? dispatch(setEmailErrorMessage('')) : dispatch(setEmailErrorMessage(`${messages.emptyField} Email`))
            break
        case 'password':
            value !== '' ? dispatch(setPasswordErrorMessage('')) : dispatch(setPasswordErrorMessage(`${messages.emptyField} Password`))
            break
        case 'mobile':
            dispatch(setUserMobileErrorMessage(''))
            break
        case 'project':
            value !== '' ? dispatch(setProjectErrorMessage('')) : dispatch(setProjectErrorMessage(`${messages.select} Project`))
            break
        case 'userRole':
            value !== '' ? dispatch(setUserRoleErrorMessage('')) : dispatch(setUserRoleErrorMessage(`${messages.select} User Role`))
            break
    }
}

const checkProjectError = (userInfo: userInfoType, dispatch: any) => {
    if (!userInfo?.isAdminRole) {
        return (doValidateProject((userInfo.project?.value), dispatch))
    } else {
        return true
    }
}
export const checkUsersFieldsErrors = (userInfo: userInfoType, dispatch: any, type: string) => {
    doValidatefullName((userInfo.userName), dispatch)
    doValidateFirstName((userInfo.firstName), dispatch)
    doValidateLatName((userInfo.lastName), dispatch)
    doValidateUserMobileNumber((userInfo.mobile), dispatch)
    doValidateEditPassword((userInfo.password), dispatch)
    !userInfo?.isAdminRole && doValidateProject((userInfo.project?.value), dispatch)
    type === 'add' && doValidatePassword((userInfo.password), dispatch)
    doValidateEmail((userInfo.email), dispatch)
    doValidateUserRole((userInfo.userRole?.value), dispatch)
    if (doValidatefullName((userInfo.userName), dispatch) &&
        doValidateFirstName((userInfo.firstName), dispatch) &&
        doValidateLatName((userInfo.lastName), dispatch) &&
        doValidateUserMobileNumber((userInfo.mobile), dispatch) &&
        doValidateEmail((userInfo.email), dispatch) &&
        checkProjectError(userInfo, dispatch)&&
        doValidateUserRole((userInfo.userRole?.value), dispatch) &&
        doValidateEditPassword((userInfo.password), dispatch)
    ) {
    if (type === 'add') {
        if (doValidatePassword((userInfo.password), dispatch)) {
            return false
        }
        return true
    }
    return false
}
return true
}

export const emptyUserFieldsErrors = (dispatch: any) => {
    dispatch(setProjectErrorMessage(''))
    dispatch(setNameErrorMessage(''));
    dispatch(setPasswordErrorMessage(''))
    dispatch(setUserMobileErrorMessage(''));
    dispatch(setUserRoleErrorMessage(''));
    dispatch(setEmailErrorMessage(''))
    dispatch(setFirstNameErrorMessage(''));
    dispatch(setLastNameErrorMessage(''))
    dispatch(setEditPasswordErrorMessage(''))
}