import { useEffect, useState } from 'react'
import { userInfoType, userFieldsValidation, userInitialState, checkUsersFieldsErrors, emptyUserFieldsErrors, getAquisitionFormOptionsInfo } from './usersFormController';
import { doNotify, doValidateEmail, doValidateFirstName, doValidateLatName, doValidatePassword, doValidateProject, doValidateUserMobileNumber, doValidateUserRole, doValidatefullName,doValidateEditPassword, doValidateEmpId } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setProjectErrorMessage, setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner, InputGroup } from 'react-bootstrap';
import Select from 'react-select'
import { useCreateUserMutation, useEditUserMutation, useGetSingleUserQuery, useGetUserDropdownsDetailsQuery } from '../../../services/apiService/users/users';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { getOptionObject } from '../../../utils/commonUtils';
import { BsEyeFill, BsEyeSlashFill } from 'react-icons/bs';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function AddUser() {
    const [userInfo, setuserInfo] = useState<userInfoType>(userInitialState)
    const [showPassword, setshowPassword] = useState<boolean>(false)
    const { emailErrorMessage, nameErrorMessage, firstNameErrorMessage, lastNameErrorMessage, userMobileErrorMessage, projectErrorMessage, userRoleErrorMessage, passwordErrorMessage,editPasswordErrorMessage, empIdErrorMessage }: any = useAppSelector((state) => state.ErrorMessageReducer)
    const [creatUsersApi, { isLoading: creatUserApiIsloading }] = useCreateUserMutation()
    const [editUsersApi, { isLoading: editUserApiIsloading }] = useEditUserMutation()
    const { data: usersDropdownsApiResponse, isSuccess: UsersDropdownsApiIsSuccess } = useGetUserDropdownsDetailsQuery()
    const [dropDownData, setDownData] = useState<any>({})
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();
    const { data: getSingleCustomer, isSuccess: getSingleCustomerApiIsSuccess, error: getSingleCustomerApiError }: any = useGetSingleUserQuery(id, { skip: !id })

    const togglePassword = () => setshowPassword(!showPassword)

    const getIsAdminRole = (value: string) => {
        let roles = usersDropdownsApiResponse?.data?.data?.roles || []
        let roleObj = roles?.find((dataObj: any) => dataObj?.value === value)
        return roleObj.adminRole;
    }

    const getuserInfo = (event: any) => {
        const { name, value }: any = event.target
        if (name === 'userName' || name === 'firstName' || name === 'lastName' || name === 'employeeCode') {
            setuserInfo({ ...userInfo, [name]: value })
        }
        else {
            setuserInfo({ ...userInfo, [name]: value.trim() })
        }
        userFieldsValidation(event, dispatch)
    }

    const handleSelectChange = (selectedOption: any, name: string) => {
        if (name === 'userRole') {
            let isAdmin = getIsAdminRole(selectedOption.value)
            if (isAdmin) {
                setuserInfo({ ...userInfo, [name]: selectedOption, isAdminRole: isAdmin, project: null })
                dispatch(setProjectErrorMessage(''))
            } else {
                setuserInfo({ ...userInfo, [name]: selectedOption, isAdminRole: isAdmin })
            }
        } else {
            setuserInfo({ ...userInfo, [name]: selectedOption, })

        }
        userFieldsValidation({ target: { name: name, value: selectedOption.value } }, dispatch)
    };

    const handleSubmit = async () => {
        if (!checkUsersFieldsErrors(userInfo, dispatch, id ? 'edit' : 'add')) {
            let userData: any = {
                userName: userInfo.userName,
                firstName: userInfo.firstName,
                lastName: userInfo.lastName,
                employeeCode: userInfo.employeeCode,
                email: userInfo.email,
                phoneNumber: userInfo.mobile || '',
                department: userInfo.department?.value || null,
                project: userInfo.project?.value || null,
                role: userInfo.userRole?.value || null,
                isAdmin: userInfo.isAdminRole,
                password: userInfo.password || ''
            }

            if (id) {

                await editUsersApi({ id, userData }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'User updated successfully', dispatch)
                    navigate(PATH.USERS_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update User', dispatch)
                })
            } else {
                userData = {
                    ...userData,
                    password: userInfo.password
                }
                await creatUsersApi(userData).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'User created successfully', dispatch)
                    navigate(PATH.USERS_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create User', dispatch)
                })
            }
        }
    }

    useEffect(() => {
        if (type === 'add-user') {
            // setShow(true)
        } else if (type === 'edit-user') {
            !id && navigate(PATH.USERS_LIST)
            if (getSingleCustomerApiError) {
                navigate(PATH.USERS_LIST)
                doNotify('error', getSingleCustomerApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        }
        if (getSingleCustomerApiIsSuccess) {
            let userObj = getSingleCustomer?.data?.user
            let dropdowns = usersDropdownsApiResponse?.data?.data
            setuserInfo({
                ...userInfo,
                userName: userObj?.userName,
                firstName: userObj?.firstName,
                lastName: userObj?.lastName,
                employeeCode: userObj?.employeeCode,
                email: userObj?.email,
                mobile: userObj?.phoneNumber,
                department: getOptionObject(dropdowns?.departments, userObj?.department?._id),
                project: getOptionObject(dropdowns?.projects, userObj?.project?.name),
                userRole: getOptionObject(dropdowns?.roles, userObj?.role?._id),
                isAdminRole: userObj?.isAdmin,
                adminRole: userObj?.role?.adminRole
            })
        }
        return () => {
            emptyUserFieldsErrors(dispatch)
            setuserInfo(userInitialState)
        }
    }, [getSingleCustomer, id, usersDropdownsApiResponse, getSingleCustomerApiError])

    const handleCancel = () => {
        emptyUserFieldsErrors(dispatch)
        navigate(PATH.USERS_LIST)
        setuserInfo(userInitialState)
    }

    useEffect(() => {
        if (UsersDropdownsApiIsSuccess) {
            const data = usersDropdownsApiResponse?.data?.data
            setDownData(getAquisitionFormOptionsInfo(data))
        }
    }, [usersDropdownsApiResponse])

    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel}>
                            User List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type === 'add-user' ? 'Add User' : 'Edit User'} </Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-3">
                                <div className="col-md-4">
                                    <Form.Group className="mb-3" controlId="userName">
                                        <Form.Label>User Name*</Form.Label>
                                        <Form.Control autoComplete="off" type="text" value={userInfo?.userName} name='userName' onChange={getuserInfo} onBlur={(event) => doValidatefullName(event.target.value, dispatch)} placeholder="Enter User Name" />
                                        <p className='error-msg'>{nameErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-4">
                                    <Form.Group className="mb-3" controlId="firstName">
                                        <Form.Label>First Name*</Form.Label>
                                        <Form.Control type="text" value={userInfo?.firstName} name='firstName' onChange={getuserInfo} onBlur={(event) => doValidateFirstName(event.target.value, dispatch)} placeholder="Enter First Name" />
                                        <p className='error-msg'>{firstNameErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-4">
                                    <Form.Group className="mb-3" controlId="lastName">
                                        <Form.Label>Last Name*</Form.Label>
                                        <Form.Control type="text" value={userInfo?.lastName} name='lastName' onChange={getuserInfo} onBlur={(event) => doValidateLatName(event.target.value, dispatch)} placeholder="Enter Last Name" />
                                        <p className='error-msg'>{lastNameErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-4">
                                    <Form.Group className="mb-3" controlId="employeeCode">
                                        <Form.Label>Employee Code</Form.Label>
                                        <Form.Control type="text" value={userInfo?.employeeCode} name='employeeCode' onChange={getuserInfo}onBlur={(event) => doValidateEmpId(event.target.value, dispatch)} placeholder="Enter EMP Code" />
                                        <p className='error-msg'>{empIdErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-4">
                                    <Form.Group className="mb-3" controlId="email">
                                        <Form.Label>Email ID*</Form.Label>
                                        <Form.Control type="text" disabled={id ? true : false} value={userInfo?.email} name='email' onChange={getuserInfo} onBlur={(event) => doValidateEmail(event.target.value, dispatch)} placeholder="Enter Email ID" />
                                        <p className='error-msg'>{emailErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-4">
                                    <Form.Group className="mb-3" controlId="password">
                                        <Form.Label>{id ? 'New Password' : 'Password*'}</Form.Label>
                                        <InputGroup>
                                            <Form.Control type={showPassword?"text":"password"} value={userInfo?.password} name='password' onChange={getuserInfo}
                                            onBlur={(event) => id ? doValidateEditPassword(event.target.value, dispatch) : doValidatePassword(event.target.value, dispatch)}placeholder="Enter Your Password" />
                                            {showPassword ? <BsEyeFill className='eye-icon-User' onClick={togglePassword} /> : <BsEyeSlashFill className='eye-icon-User' onClick={togglePassword} />}
                                        </InputGroup>
                                        <p className='error-msg'>{id ? editPasswordErrorMessage : passwordErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-4">
                                    <Form.Group className="mb-3" controlId="phoneNumber">
                                        <Form.Label>Phone Number</Form.Label>
                                        <Form.Control value={userInfo?.mobile} name='mobile' type="text" onChange={getuserInfo} onBlur={(event) => doValidateUserMobileNumber(event.target.value, dispatch)} placeholder="Enter Phone Number" />
                                        <p className='error-msg'>{userMobileErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-4">
                                    <label className='form-label'>Select Department</label>
                                    <Select
                                        className='common-input'
                                        value={userInfo?.department}
                                        onChange={(option: any) => handleSelectChange(option, 'department')}
                                        options={dropDownData?.departments}
                                        placeholder="Select Department"
                                        isSearchable
                                    />
                                </div>
                                <div className="col-md-4">
                                    <label className='form-label'>Select Role*</label>
                                    <Select
                                        className='common-input'
                                        value={userInfo?.userRole}
                                        onChange={(option: any) => handleSelectChange(option, 'userRole')}
                                        options={dropDownData?.userRoles}
                                        placeholder="Select Role"
                                        onBlur={(event: any) => doValidateUserRole(userInfo.userRole, dispatch)}
                                        isSearchable
                                    />
                                    <p className='error-msg'>{userRoleErrorMessage}</p>
                                </div>
                                {id && !userInfo?.isAdminRole && <div className="col-md-4">
                                    <label className='form-label'>Select Project*</label>
                                    <Select
                                        className='common-input'
                                        value={userInfo?.project}
                                        onChange={(option: any) => handleSelectChange(option, 'project')}
                                        options={dropDownData?.projects}
                                        placeholder="Select Project"
                                        onBlur={(event: any) => doValidateProject(userInfo.project, dispatch)}
                                        isSearchable
                                    />
                                    <p className='error-msg'>{projectErrorMessage}</p>

                                </div>}
                                {!id && !userInfo?.isAdminRole && <div className="col-md-4">
                                    <label className='form-label'>Select Project*</label>
                                    <Select
                                        className='common-input'
                                        value={userInfo?.project}
                                        onChange={(option: any) => handleSelectChange(option, 'project')}
                                        options={dropDownData?.projects}
                                        placeholder="Select Project"
                                        onBlur={(event: any) => doValidateProject(userInfo.project, dispatch)}
                                        isSearchable
                                    />
                                    <p className='error-msg'>{projectErrorMessage}</p>

                                </div>}
                            </div>
                            <div className="row mt-4">
                                <div className="col-md-12">
                                    <div className="d-flex justify-content-center gap-3 mt-3">
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button className='submit-btn' disabled={editUserApiIsloading || creatUserApiIsloading} onClick={handleSubmit}>
                                            <span>{editUserApiIsloading || creatUserApiIsloading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span>
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AddUser