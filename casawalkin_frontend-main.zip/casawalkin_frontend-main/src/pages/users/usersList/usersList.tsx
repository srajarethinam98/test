import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { PATH } from '../../../constants/path';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { useDeleteUserMutation, useGetUserListQuery } from '../../../services/apiService/users/users';
import { Badge, Button, Form,Spinner } from 'react-bootstrap';
import ResponsivePagination from 'react-responsive-pagination';
import Loading from '../../miscellanious/tableLoader/index'
import NoData from '../../miscellanious/noData/index'
import { useMemo, useState } from 'react';
import { searchParamsType,searchParamsInitialData } from '../../../constants/dropdowns';
import { BiSearch } from "react-icons/bi";
import { AiOutlinePlus,AiOutlineDelete,AiOutlineEdit } from "react-icons/ai";

function UserCreationForm() {
  const dispatch = useAppDispatch()
  const navigate = useCustomNavigate()
  const [apiParams, setApiParams] = useState<searchParamsType>(searchParamsInitialData)

  const { data: usersListData, isFetching:usersListApiIsFetching, isSuccess: usersListApiIsSuccess } = useGetUserListQuery(apiParams)
  const [deletUsersApi] = useDeleteUserMutation()
 
  const deleteCustomer = async (id: any) => {
    await deletUsersApi(id).unwrap().then((payload: any) => {
      doNotify('success', payload?.data?.message || 'User deleted successfully', dispatch)
    }).catch((err: any) => {
      if (err?.data?.statusCode === 401) {
        dispatch(setUnAuthorized(true))
      }
      doNotify('error', err?.data?.error?.message || 'Failed to delete User', dispatch)
    })
  }

  const doFormArrayOfObject = (apiValue: any) => {
    if (usersListApiIsSuccess) {
      return apiValue?.data?.users?.map((userObj: any) => {
        return {
          id: userObj._id,
          userName: userObj?.userName,
          firstName: userObj?.firstName,
          lastName: userObj?.lastName,
          employeeCode: userObj?.employeeCode,
          email: userObj?.email,
          phoneNumber: userObj?.phoneNumber,
          project: userObj?.project?.name,
          department: userObj?.department?.name,
          role: userObj?.role?.title
        }
      })
    }
    return []
  }

  const usersTableList = useMemo(() => doFormArrayOfObject(usersListData), [usersListData])

  return (
    <>
      <div className="dashboard-wrapper">
        <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
          <div className='d-flex align-items-center gap-3'>
          <h5 className='page-title'>Users List <Badge bg="success">{!usersListApiIsFetching?usersListData?.data?.totalCount || 0:<Spinner size="sm" />}</Badge></h5>
          <div className="col-md-6 search-input">
            <Form.Group controlId="userName">
              <Form.Control type="text" name='name'
                onChange={(event) => setApiParams({ ...apiParams, searchString: event.target.value,currentPage:1 })}
                placeholder="Search User.."
              />
            </Form.Group>
            <BiSearch className='search-icon' />
          </div>
          </div>
          <Button className='add-btn mx-3' onClick={() => navigate(PATH.ADD_USER)} ><span><AiOutlinePlus /> Add User</span></Button>
        </div>
        <div className="dashboard-card">
          <div className="dashboard-card-body">
            <div className="table-responsive">
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col" style={{ width: '80px' }}>S.No</th>
                    <th scope="col">User Name</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Employee Code</th>
                    <th scope="col">Email ID</th>
                    <th scope="col">Phone Number</th>
                    <th scope="col">Department</th>
                    <th scope="col">Project</th>
                    <th scope="col">Role</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    !usersListApiIsFetching ? usersListApiIsSuccess ? usersListData?.data?.users?.length > 0 ?
                    usersTableList?.map((userObj: any, index: any) => {
                        let id = userObj?._id
                        return (
                          <tr key={index}>
                            <td>{index + 1+(apiParams.currentPage-1)*usersListData?.data?.limit}</td>
                            <td>{userObj?.userName || '-'}</td>
                            <td>{userObj?.firstName || '-'}</td>
                            <td>{userObj?.lastName || '-'}</td>
                            <td>{userObj?.employeeCode || '-'}</td>
                            <td>{userObj?.email || '-'}</td>
                            <td>{userObj?.phoneNumber || '-'}</td>
                            <td>{userObj?.department || '-'}</td>
                            <td>{userObj?.project || '-'}</td>
                            <td>{userObj?.role || '-'}</td>
                            <td>
                              <div className='action-col d-flex gap-2'>
                                <a className='edit' title='Edit' onClick={() => {
                                  navigate(`/user/edit-user/?id=${userObj?.id}`)

                                }}><AiOutlineEdit /></a>
                                <a className='delete' title='Delete' onClick={() => deleteCustomer(userObj?.id)}><AiOutlineDelete /></a>
                              </div>
                            </td>
                          </tr>
                        )
                      }) : <NoData /> : <>Api error</> : <Loading />
                  }
                </tbody>
              </table>
            </div>
            <div className='export-data-footer'>
              <ResponsivePagination
                current={apiParams.currentPage}
                total={usersListData?.data?.totalPages || 1}
                maxWidth={7}
                onPageChange={(page: any) => setApiParams({ ...apiParams, currentPage: page })}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default UserCreationForm