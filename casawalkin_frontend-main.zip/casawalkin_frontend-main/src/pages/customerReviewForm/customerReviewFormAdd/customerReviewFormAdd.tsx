import React, { useState, useEffect } from 'react';
import { PATH } from '../../../constants/path';
import { useAppDispatch, useCustomNavigate, useAppSelector } from '../../../base/hooks/hooks';
import { doValidateQuestion, doValidateOption, doNotify, doValidateRating, doValidateQuestionType } from '../../../utils/utils';
import { Breadcrumb, Button, Form, Spinner } from 'react-bootstrap';
import { MdOutlineCheck, MdOutlineClose } from 'react-icons/md';
import { IoAddSharp } from 'react-icons/io5';
import { HiOutlineMinus } from 'react-icons/hi';
import { useParams, useLocation } from 'react-router-dom';
import {
    reviewFormInitialState,
    reviewFormFieldsValidation,
    checkReviewFormFieldsErrors,
    emptyReviewFormFieldsErrors,
    formatReviewRequestBody
} from './CustomerReviewFormAddController';
import { useGetSpecificReviewModelQuery, useCreateReviewModelMutation, useUpdateReviewModelMutation } from '../../../services/apiService/customerReview/customerReview';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';

function CustomerReviewFormAdd() {
    const { type }: any = useParams();
    const { questionErrorMessage, ratingErrorMessage, questionTypeErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer);
    const dispatch = useAppDispatch();
    const navigate = useCustomNavigate();
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id');

    const [reviewForm, setReviewForm] = useState({
        ...reviewFormInitialState,
        options: ['', ''],
        maxRating: '',
        answerTypeCode : '',
        multipleSelectionEnabled: false // Added state for checkbox
    });
    const [optionErrors, setOptionErrors] = useState<string[]>(['', '']);

    const { data: specificReviewModel, isSuccess: getSpecificReviewModelSuccess, isError: getSpecificReviewModelError } = useGetSpecificReviewModelQuery(id, { skip: !id });
    const [createReviewModel, { isLoading: createReviewModelLoading }] = useCreateReviewModelMutation();
    const [updateReviewModel, { isLoading: updateReviewModelLoading }] = useUpdateReviewModelMutation();

    useEffect(() => {
        if (getSpecificReviewModelSuccess) {
            const reviewModelData = specificReviewModel?.data?.data;
            setReviewForm({
                ...reviewForm,
                question: reviewModelData.question,
                questionType: reviewModelData.answerType,
                options: reviewModelData.answerOptions.map((option: { value: any; }) => option.value),
                maxRating: reviewModelData.maxRating || '',
                manditory: reviewModelData?.manditory,
                active: reviewModelData?.active,
                answerTypeCode: reviewModelData?.answerTypeCode,
                multipleSelectionEnabled: reviewModelData.answerTypeCode === '105'
            });
        }

        if (getSpecificReviewModelError) {
            doNotify('error', 'Failed to get review model', dispatch);
        }
    }, [getSpecificReviewModelSuccess, getSpecificReviewModelError, specificReviewModel, dispatch]);

    const handleCancel = () => {
        emptyReviewFormFieldsErrors(dispatch);
        navigate(PATH.CUSTOMER_REVIEW_FORM_LIST);
    };

    const handleQuestionTypeChange = (event: any) => {
        const newQuestionType = event.target.value;
        setReviewForm({
            ...reviewForm,
            questionType: newQuestionType,
            options: newQuestionType === 'Single Selection' || newQuestionType === 'Multiple Selection' ? ['', ''] : [],
            maxRating: newQuestionType === 'Rating' ? '' : reviewForm.maxRating,
            // answerTypeCode: newQuestionType === 'Multiple Selection With Others' ? '105' : reviewForm.answerTypeCode // Set answerTypeCode to 105 for Multiple Selection
        });
        setOptionErrors(newQuestionType === 'Single Selection' || newQuestionType === 'Multiple Selection' ? ['', ''] : []);
    };

    const handleAddOption = () => {
        setReviewForm({
            ...reviewForm,
            options: [...reviewForm.options, '']
        });
        setOptionErrors([...optionErrors, '']);
    };

    const handleRemoveOption = (index: any) => {
        if (index > 1) {
            const newOptions = [...reviewForm.options];
            newOptions.splice(index, 1);
            setReviewForm({
                ...reviewForm,
                options: newOptions
            });
            const newOptionErrors = [...optionErrors];
            newOptionErrors.splice(index, 1);
            setOptionErrors(newOptionErrors);
        }
    };

    const handleOptionChange = (event: any, index: number) => {
        const { value } = event.target;
        const newOptions = [...reviewForm.options];
        newOptions[index] = value;
        setReviewForm({
            ...reviewForm,
            options: newOptions
        });
    };

    const handleOptionBlur = (event: any, index: number) => {
        const { value } = event.target;
        if (index < 2) {
            doValidateOption(value, index, dispatch, optionErrors, setOptionErrors);
        }
    };

    const handleInputChange = (event: any) => {
        const { name, value } = event.target;
        setReviewForm({
            ...reviewForm,
            [name]: value
        });
        reviewFormFieldsValidation(event, dispatch);
    };

    const handleMultipleSelectionWithOthers = (event: any) => {
        const isChecked = event.target.checked;
        setReviewForm({
            ...reviewForm,
            // questionType: isChecked ? 'Multiple Selection With Others' : 'Multiple Selection',
            multipleSelectionEnabled: isChecked,
            answerTypeCode: isChecked ? '105' : '103', // Set answerTypeCode to 105 when checkbox is checked, otherwise set to 101
        });
    };

    const handleSubmit = async (event: any) => {
        event.preventDefault();
        if (checkReviewFormFieldsErrors(reviewForm, dispatch, optionErrors, setOptionErrors)) {
            let formatbodyData: any = formatReviewRequestBody(reviewForm)
            if (id) {
                await updateReviewModel({ id, formatbodyData }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Review updated successfully', dispatch)
                    navigate(PATH.CUSTOMER_REVIEW_FORM_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update Review', dispatch)
                })
            }
            else {
                try {
                    const response = await createReviewModel(formatbodyData).unwrap();
                    doNotify('success', response?.message || 'Customer Review Question successfully created', dispatch);
                    emptyReviewFormFieldsErrors(dispatch);
                    navigate(PATH.CUSTOMER_REVIEW_FORM_LIST);
                } catch (err: any) {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    const errorMessage = err?.data?.error?.message || 'Failed to create Customer Review Question';
                    doNotify('error', errorMessage, dispatch);
                }
            }
        }
    };

    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item>Customer Review Modal</Breadcrumb.Item>
                        <Breadcrumb.Item active> {type === 'edit-review-form' ? 'Edit Customer Review Form' : 'Add Customer Review Form'} </Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off" onSubmit={handleSubmit}>
                            <div className="row gy-4">
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="question">
                                        <Form.Label>Question</Form.Label>
                                        <Form.Control
                                            as='textarea'
                                            rows={2}
                                            placeholder="Enter Question"
                                            name="question"
                                            value={reviewForm.question}
                                            onChange={handleInputChange}
                                            onBlur={(event) => doValidateQuestion(event.target.value, dispatch)}
                                        />
                                        <p className='error-msg'>{questionErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="questionType">
                                        <Form.Label>Answer Type</Form.Label>
                                        <Form.Select
                                            value={reviewForm.questionType}
                                            onChange={handleQuestionTypeChange}
                                            onBlur={(event) => {
                                                doValidateQuestionType(event.target.value, dispatch);
                                            }}
                                        >
                                            <option value="" disabled>Select Answer Type</option>
                                            <option value="Text Field">Text Field</option>
                                            <option value="Single Selection">Single Selection</option>
                                            <option value="Multiple Selection">Multiple Selection</option>
                                            <option value="Multiple Selection With Others" hidden>Multiple Selection</option>
                                            <option value="Rating">Rating</option>
                                        </Form.Select>
                                        <p className='error-msg'>{questionTypeErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                {(reviewForm.questionType === 'Multiple Selection' || reviewForm.questionType ==='Multiple Selection With Others') && (
                                    <div className="col-md-6">
                                        <Form.Group className="mb-3" controlId="multipleSelection">
                                            <Form.Check
                                                type="checkbox"
                                                label="Enable Others Option"
                                                checked={reviewForm.multipleSelectionEnabled}
                                                onChange={handleMultipleSelectionWithOthers}
                                            />
                                        </Form.Group>
                                    </div>
                                )}
                                {(reviewForm.questionType === 'Single Selection' || reviewForm.questionType === 'Multiple Selection' || reviewForm.questionType === 'Multiple Selection With Others') && (
                                    <div className="row customer-review-add-row">
                                        {reviewForm.options.map((option, index) => (
                                            option !== "Others" && (
                                                <div key={index} className="col-md-6">
                                                    <div className="row w-100">
                                                        <div className="col-md-10">
                                                            <Form.Group className="mb-3" controlId={`option-${index}`}>
                                                                <Form.Label>Option {index + 1}</Form.Label>
                                                                <Form.Control
                                                                    type="text"
                                                                    placeholder={`Enter Option ${index + 1}`}
                                                                    value={option}
                                                                    onChange={(event) => handleOptionChange(event, index)}
                                                                    onBlur={(event) => handleOptionBlur(event, index)}
                                                                />
                                                                <p className='error-msg'>{optionErrors[index]}</p>
                                                            </Form.Group>
                                                        </div>
                                                        <div className="col-md-2 d-flex align-items-center">
                                                            <div className='action-col d-flex gap-2 mt-2'>
                                                                {index > 1 && (
                                                                    <a className='edit' title='Remove' onClick={() => handleRemoveOption(index)}>
                                                                        <HiOutlineMinus />
                                                                    </a>
                                                                )}
                                                                {index === reviewForm.options.length - 1 && (
                                                                    <a className='delete' title='Add' onClick={handleAddOption}>
                                                                        <IoAddSharp />
                                                                    </a>
                                                                )}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            )
                                        ))}
                                    </div>
                                )}
                                {reviewForm.questionType === 'Rating' && (
                                    <div className="col-md-6">
                                        <Form.Group className="mb-3" controlId="rating">
                                            <Form.Label>Rating</Form.Label>
                                            <Form.Select
                                                value={reviewForm.maxRating || ''}
                                                onChange={(e) => {
                                                    setReviewForm({
                                                        ...reviewForm,
                                                        maxRating: e.target.value,
                                                    });
                                                }}
                                                onBlur={(e) => {
                                                    const fieldValue = e.target.value;
                                                    doValidateRating(fieldValue, dispatch);
                                                }}
                                            >
                                                <option value="" disabled>Select Rating</option>
                                                <option value={5}>5 Star Rating</option>
                                                <option value={10}>10 Star Rating</option>
                                            </Form.Select>
                                            <p className='error-msg'>{ratingErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                )}
                            </div>
                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button className='submit-btn' type="submit" disabled={createReviewModelLoading}>
                                            <span>
                                                {createReviewModelLoading ? <Spinner animation="border" size="sm" /> : <MdOutlineCheck />} Submit
                                            </span>
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    );
}

export default CustomerReviewFormAdd;
