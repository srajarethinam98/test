import messages from '../../../constants/messageConstants';
import {
    setQuestionErrorMessage,
    setOptionErrors,
    setQuestionTypeErrorMessage,
    setRatingErrorMessage,
} from '../../../base/reducer/errorMessageReducer';
import {
    doValidateQuestion,
    doValidateOption,
    doValidateQuestionType,
    doValidateRating,
} from '../../../utils/utils';

export type ReviewFormType = {
    manditory: boolean;
    question: string;
    questionType: string;
    options: string[];
    maxRating: string;
    active: boolean;
    answerTypeCode: string;
    multipleSelectionEnabled: boolean;
};

export const reviewFormInitialState: ReviewFormType = {
    question: '',
    questionType: '',
    options: [''],
    maxRating: '0',
    manditory: true,
    active: true,
    answerTypeCode: '',
    multipleSelectionEnabled: false,
};

export const reviewFormFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target;
    if (name === 'question') {
        dispatch(setQuestionErrorMessage(value ? '' : `${messages.emptyField} Question`));
    }
};

export const formatReviewRequestBody = (reviewForm: ReviewFormType) => {
    const getAnswerOptions = () =>
        reviewForm.options
            .filter((option) => option.trim() !== '')
            .map((option, index) => ({
                key: `Option ${index + 1}`,
                value: option,
            }));

    switch (reviewForm.questionType) {
        case 'Text Field':
            return {
                question: reviewForm.question,
                answerTypeCode: '101',
                answerOptions: [],
                maxRating: null,
                manditory: reviewForm.manditory,
                active: reviewForm.active,
                description: null,
            };
        case 'Single Selection':
            return {
                question: reviewForm.question,
                answerTypeCode: '102',
                answerOptions: getAnswerOptions(),
                maxRating: null,
                manditory: reviewForm.manditory,
                active: reviewForm.active,
                description: null,
            };
        case 'Multiple Selection':
        case 'Multiple Selection With Others':
            let answerOptions = getAnswerOptions();
            
            if (reviewForm.multipleSelectionEnabled) {
                if (!answerOptions.some((option: { value: string; }) => option.value === 'Others')) {
                    answerOptions.push({ key: `Option ${answerOptions.length + 1}`, value: 'Others' });
                }
            } else {
                answerOptions = answerOptions.filter(option => option.value !== 'Others');
            }
            
            return {
                question: reviewForm.question,
                answerTypeCode: reviewForm.multipleSelectionEnabled ? '105' : '103',
                answerOptions,
                maxRating: null,
                manditory: reviewForm.manditory,
                active: reviewForm.active,
                description: null,
            };
        case 'Rating':
            return {
                question: reviewForm.question,
                answerTypeCode: '104',
                answerOptions: [],
                maxRating: reviewForm.maxRating,
                manditory: reviewForm.manditory,
                active: reviewForm.active,
                description: null,
            };
        default:
            // return {
            //     question: reviewForm.question,
            //     answerTypeCode: '101', // Default to TextField
            //     answerOptions: [],
            //     maxRating: null,
            //     manditory: reviewForm.manditory,
            //     active: reviewForm.active,
            //     description: null,
            // };
    }
};

export const checkReviewFormFieldsErrors = (
    reviewForm: ReviewFormType,
    dispatch: any,
    optionErrors: string[],
    setOptionErrors: (errors: string[]) => void,
) => {
    const questionValid = doValidateQuestion(reviewForm.question, dispatch);
    const questionTypeValid = doValidateQuestionType(reviewForm.questionType, dispatch);
    const ratingValid = doValidateRating(reviewForm.maxRating, dispatch);

    let allOptionsValid = true;
    const newOptionErrors = [...optionErrors];

    if (['Single Selection', 'Multiple Selection'].includes(reviewForm.questionType)) {
        reviewForm.options.forEach((option, index) => {
            if (index < 2) {
                const isValid = doValidateOption(option, index, dispatch, optionErrors, setOptionErrors);
                newOptionErrors[index] = isValid ? '' : `Kindly enter your Option ${index + 1}`;
                allOptionsValid = allOptionsValid && (isValid ?? false);  // Coerce to boolean
            }
        });
    }

    setOptionErrors(newOptionErrors);

    return reviewForm.questionType === 'Rating'
        ? questionValid && questionTypeValid && ratingValid
        : questionValid && allOptionsValid && questionTypeValid;
};

export const emptyReviewFormFieldsErrors = (dispatch: any) => {
    dispatch(setQuestionErrorMessage(''));
    dispatch(setOptionErrors(''));
    dispatch(setQuestionTypeErrorMessage(''));
    dispatch(setRatingErrorMessage(''));
};
