import React, { useState, useEffect } from 'react';
import { useCustomNavigate } from '../../../base/hooks/hooks';
import { PATH } from '../../../constants/path';
import { Button, Form, Modal, Spinner } from 'react-bootstrap';
import { AiOutlineDelete, AiOutlineEdit, AiOutlinePlus } from 'react-icons/ai';
import { MdDragHandle } from 'react-icons/md';
import { useGetReviewModelListQuery, useUpdateReviewModelMutation, useUpdateReviewOrderMutation } from '../../../services/apiService/customerReview/customerReview';
import { doNotify } from '../../../utils/utils';
import { useDispatch } from 'react-redux';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars } from '@fortawesome/free-solid-svg-icons';

interface RowData {
    options: any;
    multipleSelectionEnabled: any;
    drag: JSX.Element;
    id: string;
    question: string;
    answerTypeCode: string;
    answerOptions: { key: string; value: string; _id: string }[];
    answerType: string
    maxRating: number | null;
    description: string;
    status: '';
    action: '';
    active: boolean;
    mandatory: boolean;
}

// const answerTypeMap = {
//     "101": "Text Field",
//     "102": "Single Selection",
//     "103": "Multiple Selection",
//     "104": "Rating",
//     "105": "Multiple Selection"
// } as const;

// type AnswerTypeCode = keyof typeof answerTypeMap;

function CustomerReviewFormList() {
    const navigate = useCustomNavigate();
    const dispatch = useDispatch();

    const [rows, setRows] = useState<RowData[]>([]);
    const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
    const [hoverIndex, setHoverIndex] = useState<number | null>(null);
    const [showModal, setShowModal] = useState(false);
    const [updateData, setUpdateData] = useState<RowData | null>(null);
    const [originalRow, setOriginalRow] = useState<RowData | null>(null);
    const [isRearrangeEnabled, setIsRearrangeEnabled] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const { data: reviewModelListData, isLoading: reviewModelListApiIsLoading, isSuccess: reviewModelListApiIsSuccess, error: reviewModelListApiError, refetch } = useGetReviewModelListQuery();
    const [updateReviewModel] = useUpdateReviewModelMutation();
    const [updateReviewOrder] = useUpdateReviewOrderMutation();

    useEffect(() => {
        if (reviewModelListApiIsSuccess) {
            setRows(reviewModelListData.data.data.map((item: any) => ({
                drag: isRearrangeEnabled ? <span className="drag-icon"><MdDragHandle /></span> : <></>,
                id: item._id,
                question: item.question,
                answerTypeCode: item.answerTypeCode,
                answerOptions: item.answerOptions,
                answerType: item.answerType,
                maxRating: item.maxRating,
                description: item.description,
                status: '',
                action: '',
                active: item.active,
                mandatory: item.manditory,
            })));
        }
    }, [reviewModelListApiIsSuccess, reviewModelListData, isRearrangeEnabled]);

    const handleDragStart = (e: React.DragEvent<HTMLTableRowElement>, index: number) => {
        setDraggedIndex(index);
        e.dataTransfer.effectAllowed = 'move';
    };

    const handleDragOver = (e: React.DragEvent<HTMLTableRowElement>, index: number) => {
        e.preventDefault();
        setHoverIndex(index);
    };

    const handleDrop = (index: number) => {
        if (draggedIndex === null) return;

        const draggedRow = rows[draggedIndex];
        const updatedRows = [...rows];
        updatedRows.splice(draggedIndex, 1); // Remove dragged row
        updatedRows.splice(index, 0, draggedRow); // Insert dragged row at new position

        setRows(updatedRows);
        setDraggedIndex(null); // Reset dragged index
        setHoverIndex(null); // Reset hover index
    };

    const handleDragEnd = () => {
        setDraggedIndex(null); // Reset dragged index
        setHoverIndex(null); // Reset hover index
    };

    const handleToggle = (index: number, field: 'active' | 'mandatory') => {
        setOriginalRow({ ...rows[index] });

        const updatedRows = [...rows];
        updatedRows[index][field] = !updatedRows[index][field];
        setRows(updatedRows);

        setUpdateData({
            ...updatedRows[index],
            [field]: updatedRows[index][field],
        });

        setShowModal(true);
    };

    const handleConfirmUpdate = async () => {
        if (updateData) {
            const getAnswerOptions = () =>
                updateData.answerOptions
                    .filter((option: any) => option.value.trim() !== '')
                    .map((option: any, index: number) => ({
                        key: `Option ${index + 1}`,
                        value: option.value,
                    }));
    
            let body;
            let answerOptions = [];
    
            switch (updateData.answerTypeCode) {
                case '101':
                    body = {
                        question: updateData.question,
                        answerTypeCode: updateData.answerTypeCode,
                        answerOptions: [],
                        maxRating: null,
                        manditory: updateData.mandatory,
                        active: updateData.active,
                        description: updateData.description || null
                    };
                    break;
                case '102': // Single Selection
                case '103': // Multiple Selection
                    answerOptions = updateData.answerOptions.map((option, index) => ({
                        key: `Option ${index + 1}`,
                        value: option.value
                    }));
                    body = {
                        question: updateData.question,
                        answerTypeCode: updateData.answerTypeCode,
                        answerOptions,
                        maxRating: null,
                        manditory: updateData.mandatory,
                        active: updateData.active,
                        description: updateData.description || null
                    };
                    break;
                case '104': // Rating
                    body = {
                        question: updateData.question,
                        answerTypeCode: updateData.answerTypeCode,
                        answerOptions: [],  // No options for Rating
                        maxRating: updateData.maxRating,
                        manditory: updateData.mandatory,
                        active: updateData.active,
                        description: updateData.description || null
                    };
                    break;
                case '105':
                    answerOptions = getAnswerOptions();
                    if (updateData.multipleSelectionEnabled) {
                        if (!answerOptions.some((option: { value: string; }) => option.value === 'Others')) {
                            answerOptions.push({ key: `Option ${answerOptions.length + 1}`, value: 'Others' });
                        }
                    }
                    body = {
                        question: updateData.question,
                        answerTypeCode: '105',
                        answerOptions,
                        maxRating: null,
                        manditory: updateData.mandatory,
                        active: updateData.active,
                        description: null,
                    };
                    break;
                default:
                    break;
            }
    
            if (body) {
                try {
                    const payload = await updateReviewModel({
                        id: updateData.id,
                        formatbodyData: body
                    }).unwrap();
                    doNotify('success', payload?.data?.message || 'Customer Review Question successfully updated', dispatch);
                    refetch();
                } catch (err: any) {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Update failed', dispatch);
                }
            }
        }
        setShowModal(false);
    };

    const handleCloseModal = () => {
        // Revert changes if modal is cancelled
        if (originalRow && updateData) {
            const updatedRows = rows.map(row => row.id === originalRow.id ? originalRow : row);
            setRows(updatedRows);
        }

        setShowModal(false);
        setUpdateData(null);
        refetch();
    };

    const handleRearrangeToggle = () => {
        setIsRearrangeEnabled(!isRearrangeEnabled);
    };

    const handleSubmitOrder = async () => {
        setIsLoading(true); // Show loader
        const updatedOrder = rows
            .filter(row => row.active)
            .map((row, index) => ({
                orderNo: index + 1,
                id: row.id,
            }));

        try {
            const payload: any = await updateReviewOrder({
                order: updatedOrder
            }).unwrap();
            doNotify('success', payload?.data?.message || 'Customer Review Order successfully updated', dispatch);
            setIsRearrangeEnabled(false);
            await refetch(); // Ensure refetch is awaited
            setRows(reviewModelListData.data.data.map((item: any) => ({
                drag: isRearrangeEnabled ? <span className="drag-icon"><MdDragHandle /></span> : <></>,
                id: item._id,
                question: item.question,
                answerTypeCode: item.answerTypeCode,
                answerOptions: item.answerOptions,
                answerType: item.answerType,
                maxRating: item.maxRating,
                description: item.description,
                status: '',
                action: '',
                active: item.active,
                mandatory: item.manditory,
            })));
        } catch (err: any) {
            if (err?.data?.statusCode === 401) {
                dispatch(setUnAuthorized(true));
            }
            doNotify('error', err?.data?.error?.message || 'Failed to update Customer Review Order', dispatch);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Customer Review Modal</h5>
                    <div className='d-flex flex-wrap justify-content-end gap-2'>
                        <Button className='rearrange-btn mx-3' onClick={handleRearrangeToggle}>{isRearrangeEnabled ? 'Disable ReArrange' : 'ReArrange'}</Button>
                        {isRearrangeEnabled && <Button className='submit-btn mx-3' onClick={handleSubmitOrder}>Submit Order</Button>}
                        <Button className='add-btn mx-3' onClick={() => navigate(PATH.CUSTOMER_REVIEW_FORM_ADD)}><span><AiOutlinePlus /> Add Customer Review Qust</span></Button>
                    </div>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        {isLoading ? (
                            <div className="text-center">
                                <Spinner animation="border" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </Spinner>
                            </div>
                        ) : reviewModelListApiIsLoading ? (
                            <div className="text-center">
                                <Spinner animation="border" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </Spinner>
                            </div>
                        ) : reviewModelListApiError ? (
                            <div className="text-center text-danger">
                                Error loading data. Please try again later.
                            </div>
                        ) : (
                            <div className="table-responsive">
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th style={{ width: '40px' }}></th>
                                            <th style={{ textAlign: 'left' }}>S.No</th>
                                            <th style={{ textAlign: 'left' }}>Questions</th>
                                            <th style={{ textAlign: 'left' }}>Answer Type</th>
                                            <th style={{ textAlign: 'left' }}>Active</th>
                                            <th style={{ textAlign: 'left' }}>Mandatory</th>
                                            <th style={{ textAlign: 'left' }}>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {rows.map((row, index) => (
                                            <tr
                                                key={row.id}
                                                draggable={isRearrangeEnabled}
                                                onDragStart={(e) => handleDragStart(e, index)}
                                                onDragOver={(e) => handleDragOver(e, index)}
                                                onDrop={() => handleDrop(index)}
                                                onDragEnd={handleDragEnd}
                                                style={{
                                                    backgroundColor:
                                                        draggedIndex === index
                                                            ? 'lightgray'
                                                            : hoverIndex === index
                                                                ? 'lightblue'
                                                                : 'white',
                                                    border: hoverIndex === index ? '3px dashed grey' : '0px solid black',
                                                    cursor: isRearrangeEnabled ? 'move' : 'default',
                                                }}
                                            >
                                                <td>
                                                    {isRearrangeEnabled && <FontAwesomeIcon icon={faBars} />}
                                                </td>
                                                <td>{index + 1}</td>
                                                <td>{row.question}</td>
                                                <td>{row.answerType}</td>
                                                <td className='checkbox'>
                                                    <Form>
                                                        <Form.Check
                                                            type="switch"
                                                            id="active-switch"
                                                            checked={row.active}
                                                            onChange={() => handleToggle(index, 'active')}
                                                        />
                                                    </Form>
                                                </td>
                                                <td className='checkbox'>
                                                    <Form>
                                                        <Form.Check
                                                            type="switch"
                                                            id="mandatory-switch"
                                                            checked={row.mandatory}
                                                            onChange={() => handleToggle(index, 'mandatory')}
                                                        />
                                                    </Form>
                                                </td>
                                                <td>
                                                    <div className='action-col d-flex gap-2'>
                                                        <a
                                                            className='edit'
                                                            title='Edit'
                                                            onClick={() => {
                                                                navigate(`/customer-review-form/edit-review-form/?id=${row.id}`);
                                                            }}
                                                        ><AiOutlineEdit /></a>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            <Modal show={showModal} onHide={handleCloseModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Update</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to update this item?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseModal}>
                        Cancel
                    </Button>
                    <Button variant="primary" onClick={handleConfirmUpdate}>
                        Confirm
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

export default CustomerReviewFormList;
