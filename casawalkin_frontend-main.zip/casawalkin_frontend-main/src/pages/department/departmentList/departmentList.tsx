import { useEffect } from 'react'
import { Button } from 'react-bootstrap'
import { useGetDepartmentListQuery, useDeleteDepartmentMutation } from '../../../services/apiService/department/department';
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { PATH } from '../../../constants/path';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import Loading from '../../miscellanious/tableLoader/index'
import NoData from '../../miscellanious/noData/index'
import { AiOutlinePlus,AiOutlineEdit ,AiOutlineDelete} from "react-icons/ai";

function Department() {
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const [deleteDepartmentApi, { isLoading: deleteDepartmentApiIsloading }] = useDeleteDepartmentMutation()

    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const { data: departmentListData, isLoading: DepartmentListApiIsLoading, isSuccess: DepartmentListApiIsSuccess } = useGetDepartmentListQuery()

    const deleteDepartment = async (id: any) => {
        await deleteDepartmentApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'Department deleted successfully', dispatch)
        }).catch((err: any) => {
            if (err?.data?.statusCode === 401) {
                dispatch(setUnAuthorized(true))
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete Department', dispatch)
        })
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.DEPARTMENT, navigate)
        }
    }, [permissionsList])

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Department List</h5>
                    <Button className='add-btn mx-3' onClick={() => navigate(PATH.DEPARTMENT_ADD)}><span><AiOutlinePlus /> Add Department</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">

                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ textAlign: 'left' }}>S.No</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Department</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Description</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        !DepartmentListApiIsLoading ? DepartmentListApiIsSuccess ? departmentListData?.data?.departments?.length > 0 ?
                                            departmentListData?.data?.departments?.map((departmentObj: any, index: any) => {
                                                let id = departmentObj?._id
                                                return (
                                                    <tr key={index}>
                                                        <td>{index + 1}</td>
                                                        <td>{departmentObj?.name || '-'}</td>
                                                        <td>{departmentObj?.description || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/department/edit-department/?id=${id}`)
                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deleteDepartment(id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }) : <NoData /> : <>Api error</> : <Loading />
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Department