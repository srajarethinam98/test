import messages from '../../../constants/messageConstants'
import { setDepartmentNameErrorMessage, setDescriptionErrorMessage } from "../../../base/reducer/errorMessageReducer"
import { doValidateDepartmentName, doValidateDescription } from "../../../utils/utils"

export type departmentInfoType = {
    name: string,
    description: string,
}

export const departmentInitialState: departmentInfoType = {
    name: '',
    description: '',
}

export const departmentFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'name':
            value !== '' ? dispatch(setDepartmentNameErrorMessage('')) : dispatch(setDepartmentNameErrorMessage(`${messages.emptyField} Departemnt Name`))
            break
    }
}

export const checkDepartmentsFieldsErrors = (departmentInfo: departmentInfoType, dispatch: any) => {
    doValidateDepartmentName((departmentInfo.name), dispatch)
    doValidateDescription((departmentInfo.description), dispatch)
    
    if (doValidateDepartmentName((departmentInfo.name), dispatch) && doValidateDescription((departmentInfo.description), dispatch)
    ) {
        return false
    }
    return true
}

export const emptyDepartmentFieldsErrors = (dispatch: any) => {
    dispatch(setDepartmentNameErrorMessage(''))
    dispatch(setDescriptionErrorMessage(''))
}