import { useEffect, useState } from 'react'
import { departmentInfoType, departmentFieldsValidation, departmentInitialState, checkDepartmentsFieldsErrors, emptyDepartmentFieldsErrors } from './departmentFormController';
import { doNotify, doValidateDepartmentName, doValidateDescription } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import { useCreateDepartmentMutation, useEditDepartmentMutation, useGetSingleDepartmentQuery } from '../../../services/apiService/department/department';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { MdOutlineClose, MdOutlineCheck } from "react-icons/md";

function Department() {
    const [departmentInfo, setDepartmentInfo] = useState<departmentInfoType>(departmentInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { departmentNameErrorMessage,descriptionErrorMessage }: any = useAppSelector((state) => state.ErrorMessageReducer)
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()

    const [creatdepartmentsApi, { isLoading: creatdepartmentApiIsloading }] = useCreateDepartmentMutation()
    const [editdepartmentsApi, { isLoading: editdepartmentApiIsloading }] = useEditDepartmentMutation()
    const { data: getSingleDepartment, isSuccess: getSingleDepartmentApiIsSuccess, isError: getSingleDepartmentApiIsError, error: getSingleDepartmentApiError }: any = useGetSingleDepartmentQuery(id, { skip: !id })

    const getDepartmentInfo = (event: any) => {
        const { name, value }: any = event.target
        setDepartmentInfo({ ...departmentInfo, [name]: value })
        departmentFieldsValidation(event, dispatch)
    }

    const handleSubmit = async () => {
        if (!checkDepartmentsFieldsErrors(departmentInfo, dispatch)) {
            let body: any = {
                name: departmentInfo.name,
                description: departmentInfo.description,
            }
            if (id) {
                await editdepartmentsApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Department updated successfully', dispatch)
                    navigate(PATH.DEPARTMENT_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update Department', dispatch)
                })
            } else {
                await creatdepartmentsApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Department created successfully', dispatch)
                    navigate(PATH.DEPARTMENT_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create department', dispatch)
                })
            }
        }
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.DEPARTMENT, navigate)
        }
        if (type === 'edit-department') {
            !id && navigate(PATH.DEPARTMENT_LIST)
            if (getSingleDepartmentApiIsError) {
                navigate(PATH.DEPARTMENT_LIST)
                doNotify('error', getSingleDepartmentApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        }
        if (getSingleDepartmentApiIsSuccess) {
            let departmentObj: any = getSingleDepartment?.data?.department
            setDepartmentInfo({
                ...departmentInfo,
                name: departmentObj?.name,
                description: departmentObj?.description
            })
        }
        return () => {
            emptyDepartmentFieldsErrors(dispatch)
            setDepartmentInfo(departmentInitialState)
        }
    }, [getSingleDepartment, id, permissionsList, getSingleDepartmentApiIsError])

    const handleCancel = () => {
        emptyDepartmentFieldsErrors(dispatch)
        navigate(PATH.DEPARTMENT_LIST)
        setDepartmentInfo(departmentInitialState)
    }

    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel}>
                            Department List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type === 'add-department' ? 'Add department' : 'Edit department'}</Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-3">
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="departmentName">
                                        <Form.Label>Department Name*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter department Name" value={departmentInfo?.name} name='name' onChange={getDepartmentInfo} onBlur={(event) => doValidateDepartmentName(event.target.value, dispatch)} />
                                        <p className='error-msg'>{departmentNameErrorMessage}</p>

                                    </Form.Group>
                                </div><div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="departmentName">
                                        <Form.Label>Description</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Description" value={departmentInfo?.description} name='description' onChange={getDepartmentInfo}
                                        onBlur={(event) => doValidateDescription(event.target.value, dispatch)} />
                                        <p className='error-msg'>{descriptionErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            </div>
                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button onClick={handleSubmit} className='submit-btn' disabled={creatdepartmentApiIsloading || editdepartmentApiIsloading}><span> {creatdepartmentApiIsloading || editdepartmentApiIsloading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Department