import { useEffect, useState } from 'react'
import { employeeInfoType, employeeFieldsValidation, employeeInitialState, checkEmployeesFieldsErrors, emptyEmployeeFieldsErrors, getEmployeesFormOptionsInfo, getSalesDropDownOptionsInfo, checkIsTl, checkIsFls } from './fieldEmployeeController';
import { doNotify, doValidateEmail, doValidateFirstName, doValidateLatName, doValidateProject, doValidateSalesRole, doValidateSvc, doValidateTl, doValidateUserMobileNumber, doValidateUserRole, doValidatefullName } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setSvcErrorMessage, setTlErrorMessage, setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import Select from 'react-select'
import { useGetUserDropdownsDetailsQuery } from '../../../services/apiService/users/users';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { checkScreenAccess, getOptionObject } from '../../../utils/commonUtils';
import { useGetUserSalesDropdownsDetailsQuery } from '../../../services/apiService/acquisitionForm/acquisitionForm';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { salesRoles } from '../../../constants/dropdowns';
import { useCreateFieldEmployeeMutation, useEditFieldEmployeeMutation, useGetFieldEmployeesListQuery, useGetSingleFieldEmployeeQuery } from '../../../services/apiService/fieldEmployees/fieldEmployees';
import { MdOutlineClose, MdOutlineCheck } from "react-icons/md";

function FieldEmployees() {
    const [employeeInfo, setEmployeeInfo] = useState<employeeInfoType>(employeeInitialState)
    const { emailErrorMessage, firstNameErrorMessage, lastNameErrorMessage, userMobileErrorMessage, projectErrorMessage, svcErrorMessage, salesRoleErrorMessage, tlErrorMessage }: any = useAppSelector((state) => state.ErrorMessageReducer)
    const [creatUsersApi, { isLoading: creatUserApiIsloading }] = useCreateFieldEmployeeMutation()
    const [editUsersApi, { isLoading: editUserApiIsloading }] = useEditFieldEmployeeMutation()
    const { data: usersDropdownsApiResponse, isSuccess: UsersDropdownsApiIsSuccess } = useGetUserDropdownsDetailsQuery()
    const [dropDownData, setDownData] = useState<any>({})
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const { data: getSingleCustomer, isSuccess: getSingleCustomerApiIsSuccess, isError: getSingleCustomerApiIsError, error: getSingleCustomerApiError }: any = useGetSingleFieldEmployeeQuery(id, { skip: !id })
    const { data: salesDropdownsApiResponse, isSuccess: salesDropdownsApiIsSuccess } = useGetUserSalesDropdownsDetailsQuery()

    const getemployeeInfo = (event: any) => {
        const { name, value }: any = event.target
        if (name === 'firstName' || name === 'lastName') {
            setEmployeeInfo({ ...employeeInfo, [name]: value })
        }
        else {
            setEmployeeInfo({ ...employeeInfo, [name]: value.trim() })
        }
        employeeFieldsValidation(event, dispatch)
    }

    const handleSelectChange = (selectedOption: any, name: string) => {
        if (name === 'salesRole') {
            if (selectedOption?.value === 'svc') {
                setEmployeeInfo({ ...employeeInfo, [name]: selectedOption, svc: null })
                dispatch(setSvcErrorMessage(''))
            } else if (selectedOption?.value === 'svctl') {
                dispatch(setTlErrorMessage('')); dispatch(setSvcErrorMessage(''))
                setEmployeeInfo({ ...employeeInfo, [name]: selectedOption, svc: null, tl: null })
            } else if (selectedOption?.value === 'flstl') {
                setEmployeeInfo({ ...employeeInfo, [name]: selectedOption, svc: null, tl: null })
                dispatch(setTlErrorMessage('')); dispatch(setSvcErrorMessage(''))
            } else {
                setEmployeeInfo({ ...employeeInfo, [name]: selectedOption, svc: null, tl: null })
                dispatch(setTlErrorMessage('')); dispatch(setSvcErrorMessage(''))
            }
        }
        setEmployeeInfo({ ...employeeInfo, [name]: selectedOption, })
        employeeFieldsValidation({ target: { name: name, value: selectedOption.value } }, dispatch)
    };

    const handleSubmit = async () => {
        if (!checkEmployeesFieldsErrors(employeeInfo, dispatch, id ? 'edit' : 'add')) {
            let userData: any = {
                firstName: employeeInfo.firstName,
                lastName: employeeInfo.lastName,
                employeeCode: employeeInfo.employeeCode,
                email: employeeInfo.email,
                phoneNumber: employeeInfo.mobile || '',
                department: employeeInfo?.department?.value || null,
                project: employeeInfo.project?.value || null,
                salesRole: employeeInfo.salesRole?.value || null,
                tl: checkIsTl(employeeInfo) ? employeeInfo?.tl?.value : '',
                svc: checkIsFls(employeeInfo) ? employeeInfo?.svc?.value : ''
            }

            if (id) {
                await editUsersApi({ id, userData }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Employee updated successfully', dispatch)
                    navigate(PATH.FIELD_EMPLOYEES_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update Employee', dispatch)
                })
            } else {
                await creatUsersApi(userData).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Employee created successfully', dispatch)
                    navigate(PATH.FIELD_EMPLOYEES_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create Employee', dispatch)
                })
            }
        }
    }

    useEffect(() => {
        if (type === 'add-user') {
            // setShow(true)
        } else if (type === 'edit-employee') {
            !id && navigate(PATH.FIELD_EMPLOYEES_LIST)
            if (getSingleCustomerApiIsError) {
                navigate(PATH.FIELD_EMPLOYEES_LIST)
                doNotify('error', getSingleCustomerApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        }
        if (getSingleCustomerApiIsSuccess && UsersDropdownsApiIsSuccess && salesDropdownsApiIsSuccess) {
            let userObj = getSingleCustomer?.data?.user
            setEmployeeInfo({
                ...employeeInfo,
                firstName: userObj?.firstName,
                lastName: userObj?.lastName,
                employeeCode: userObj?.employeeCode,
                email: userObj?.email,
                mobile: userObj?.phoneNumber,
                department: getOptionObject(dropDownData?.departments, userObj?.department?._id),
                project: getOptionObject(dropDownData?.projects, userObj?.project?.name),
                salesRole: getOptionObject(salesRoles, userObj?.salesRole),
                tl: userObj?.salesRole === 'fls' ? getOptionObject(dropDownData?.flsTl, userObj?.salesTeam?.flstl?.value) : userObj?.salesRole === 'svc' ? getOptionObject(dropDownData?.svcTl, userObj?.salesTeam?.svctl?.value) : null,
                svc: userObj?.salesRole === 'fls' ? getOptionObject(dropDownData?.svc, userObj?.salesTeam?.svc?.value) : null
            })
        }
        return () => {
            emptyEmployeeFieldsErrors(dispatch);
            setEmployeeInfo(employeeInitialState)
        }
    }, [getSingleCustomer, id, dropDownData, getSingleCustomerApiIsError])

    const handleCancel = () => {
        emptyEmployeeFieldsErrors(dispatch)
        navigate(PATH.FIELD_EMPLOYEES_LIST)
        setEmployeeInfo(employeeInitialState)
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.FIELD_EMPLOYEES, navigate)
        }
        if (UsersDropdownsApiIsSuccess && salesDropdownsApiIsSuccess) {
            const basicDropdowns = usersDropdownsApiResponse?.data?.data
            const salesDropdowns = salesDropdownsApiResponse?.data?.data

            setDownData({ ...getEmployeesFormOptionsInfo(basicDropdowns), ...getSalesDropDownOptionsInfo(salesDropdowns) })
        }
    }, [usersDropdownsApiResponse, salesDropdownsApiResponse, permissionsList])

    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel}>
                            Field Employees List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type === 'add-employee' ? 'Add Field Employees' : 'Edit Field Employees'}</Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-3">
                                <div className="col-md-4">
                                    <Form.Group className="mb-3" controlId="email">
                                        <Form.Label>Email ID*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Email ID" 
                                         value={employeeInfo?.email} name='email' onChange={getemployeeInfo} onBlur={(event) => doValidateEmail(event.target.value, dispatch)} />
                                        <p className='error-msg'>{emailErrorMessage}</p>
                                    </Form.Group>
                                </div>

                                <><div className="col-md-4">
                                    <Form.Group className="mb-3" controlId="phoneNumber">
                                        <Form.Label>Phone Number</Form.Label>
                                        <Form.Control name='mobile' placeholder="Enter Phone Number" value={employeeInfo?.mobile} onChange={getemployeeInfo} onBlur={(event) => doValidateUserMobileNumber(event.target.value, dispatch)} />
                                    </Form.Group>
                                </div>


                                    <div className="col-md-4">
                                        <Form.Group className="mb-3" controlId="firstName">
                                            <Form.Label>First Name*</Form.Label>
                                            <Form.Control type="text" placeholder="Enter First Name" value={employeeInfo?.firstName} name='firstName' onChange={getemployeeInfo} onBlur={(event) => doValidateFirstName(event.target.value, dispatch)} />
                                        </Form.Group>
                                    </div>

                                    <div className="col-md-4">
                                        <Form.Group className="mb-3" controlId="lastName">
                                            <Form.Label>Last Name*</Form.Label>
                                            <Form.Control type="text" placeholder="Enter Last Name" value={employeeInfo?.lastName} name='lastName' onChange={getemployeeInfo} onBlur={(event) => doValidateLatName(event.target.value, dispatch)} />
                                        </Form.Group>
                                    </div>
                                    <div className="col-md-4">
                                        <label className='form-label'>Select Project*</label>
                                        <Select
                                            className='common-input'
                                            value={employeeInfo?.project}
                                            onChange={(option: any) => handleSelectChange(option, 'project')}
                                            options={dropDownData?.projects}
                                            placeholder="Select Project"
                                            onBlur={(event: any) => doValidateProject(employeeInfo.project?.value, dispatch)}
                                            isSearchable
                                        />
                                        {/* <p className='error-msg'>{projectErrorMessage}</p> */}
                                    </div>

                                    <div className="col-md-4">
                                        <label className='form-label'>Select Sales Role*</label>
                                        <Select
                                            className='common-input'
                                            value={employeeInfo?.salesRole}
                                            onChange={(option: any) => handleSelectChange(option, 'salesRole')}
                                            options={salesRoles}
                                            onBlur={(event: any) => doValidateSalesRole(employeeInfo.salesRole?.value, dispatch)}
                                            placeholder="Select Sales Role"
                                            isSearchable
                                        />
                                        <p className='error-msg'>{salesRoleErrorMessage}</p>
                                    </div>

                                    {checkIsTl(employeeInfo) ? <div className="col-md-4">
                                        <label className='form-label'>{employeeInfo?.salesRole?.value == 'fls' ? 'FLS TL*' : 'SVC TL*'}</label>
                                        <Select
                                            className='common-input'
                                            value={employeeInfo?.tl}
                                            onChange={(option: any) => handleSelectChange(option, 'tl')}
                                            options={employeeInfo?.salesRole?.value == 'fls' ? dropDownData?.flsTl : dropDownData?.svcTl}
                                            placeholder="Select TL"
                                            onBlur={(event: any) => doValidateTl(employeeInfo.tl?.value, dispatch)}
                                            isSearchable
                                        />
                                        <p className='error-msg'>{tlErrorMessage}</p>
                                    </div> : null}

                                    {checkIsFls(employeeInfo) && <div className="col-md-4">
                                        <label className='form-label'>SVC*</label>
                                        <Select
                                            className='common-input'
                                            value={employeeInfo?.svc}
                                            onChange={(option: any) => handleSelectChange(option, 'svc')}
                                            options={dropDownData?.svc}
                                            onBlur={(event: any) => doValidateSvc(employeeInfo.svc?.value, dispatch)}
                                            placeholder="Select Sales Role"
                                            isSearchable
                                        />
                                        <p className='error-msg'>{svcErrorMessage}</p>
                                    </div>}
                                </>
                            </div>

                            {/* <div className="row mt-4">
                                <div className="col-md-12">
                                    <div className="d-flex justify-content-center gap-3 mt-3">
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button className='submit-btn' disabled={creatUserApiIsloading || editUserApiIsloading} onClick={handleSubmit}>
                                            <span>{creatUserApiIsloading || editUserApiIsloading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span>
                                        </Button>
                                    </div>
                                </div>
                            </div> */}

                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default FieldEmployees