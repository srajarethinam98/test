import { setEmailErrorMessage, setProjectErrorMessage, setUserMobileErrorMessage, setPasswordErrorMessage, setLastNameErrorMessage, setFirstNameErrorMessage, setSalesRoleErrorMessage, setTlErrorMessage, setSvcErrorMessage } from "../../../base/reducer/errorMessageReducer"
import messages from '../../../constants/messageConstants'
import { convertToSelectOptions } from "../../../utils/commonUtils"
import { doValidateEmail, doValidateEmployeeEmail } from "../../../utils/utils"

export type employeeInfoType = {
    firstName: string,
    lastName: string,
    employeeCode: string,
    email: string,
    mobile: any,
    department: any,
    project: any,
    salesRole: any,
    tl: any,
    svc: any,
}

export const employeeInitialState: employeeInfoType = {
    firstName: '',
    lastName: '',
    employeeCode: '',
    email: '',
    mobile: '',
    department: '',
    project: '',
    salesRole: '',
    tl: null,
    svc: null,
}

export const getEmployeesFormOptionsInfo = (dropdowndata: any) => {
    return {
        projects: convertToSelectOptions(dropdowndata.projects || []),
        departments: convertToSelectOptions(dropdowndata.departments || []),
    }
}

export const getSalesDropDownOptionsInfo = (dropdowndata: any) => {
    return {
        fls: convertToSelectOptions(dropdowndata.fls || []),
        flsTl: convertToSelectOptions(dropdowndata.flstl || []),
        svc: convertToSelectOptions(dropdowndata.svc || []),
        svcTl: convertToSelectOptions(dropdowndata.svctl || []),
    }
}

export const employeeFieldsValidation = (event: any, dispatch: any) => {

    const { name, value } = event.target
    switch (name) {
        case 'firstName':
            value !== '' ? dispatch(setFirstNameErrorMessage('')) : dispatch(setFirstNameErrorMessage(`${messages.emptyField} Name`))
            break
        case 'lastName':
            value !== '' ? dispatch(setLastNameErrorMessage('')) : dispatch(setLastNameErrorMessage(`${messages.emptyField} Last Name`))
            break
        case 'email':
            value !== '' ? dispatch(setEmailErrorMessage('')) : dispatch(setEmailErrorMessage(`${messages.emptyField} Email`))
            break
        case 'password':
            value !== '' ? dispatch(setPasswordErrorMessage('')) : dispatch(setPasswordErrorMessage(`${messages.emptyField} Alternate Mobile Number`))
            break
        case 'mobile':
            dispatch(setUserMobileErrorMessage(''))
            break
        case 'project':
            value !== '' ? dispatch(setProjectErrorMessage('')) : dispatch(setProjectErrorMessage(`${messages.select} Project`))
            break
        case 'salesRole':
            value !== '' ? dispatch(setSalesRoleErrorMessage('')) : dispatch(setSalesRoleErrorMessage(`${messages.select} Sales Role`))
            break
        case 'svc':
            value !== '' ? dispatch(setSvcErrorMessage('')) : dispatch(setSvcErrorMessage(`${messages.select} SVC`))
            break
        case 'tl':
            value !== '' ? dispatch(setTlErrorMessage('')) : dispatch(setTlErrorMessage(`${messages.select} TL`))
            break
    }
}

export const checkIsTl = (employeeInfo: any) => {
    return employeeInfo?.salesRole?.value === 'fls' || employeeInfo?.salesRole?.value === 'svc'
}

export const checkIsFls = (employeeInfo: any) => {
    return employeeInfo?.salesRole?.value === 'fls'
}

export const checkEmployeesFieldsErrors = (employeeInfo: employeeInfoType, dispatch: any, type: string) => {
    // doValidateFirstName((employeeInfo.firstName), dispatch)
    // doValidateLatName((employeeInfo.lastName), dispatch)
    // doValidateUserMobileNumber((employeeInfo.mobile), dispatch)
    // doValidateProject((employeeInfo.project?.value), dispatch)
    // doValidateEmployeeEmail((employeeInfo.email), dispatch)
    doValidateEmail((employeeInfo.email), dispatch)

    // doValidateSalesRole((employeeInfo.salesRole?.value), dispatch)
    // checkIsFls(employeeInfo) && doValidateSvc((employeeInfo.svc?.value), dispatch)
    // checkIsTl(employeeInfo) && doValidateTl((employeeInfo.tl?.value), dispatch)

    if (
        // doValidateFirstName((employeeInfo.firstName), dispatch) &&
        // doValidateLatName((employeeInfo.lastName), dispatch) &&
        // doValidateUserMobileNumber((employeeInfo.mobile), dispatch) &&
        // doValidateProject((employeeInfo.project?.value), dispatch) &&
        doValidateEmail((employeeInfo.email), dispatch)
        // &&
        // doValidateSalesRole((employeeInfo.salesRole?.value), dispatch)
    ) {
        // if (checkIsFls(employeeInfo)) {
        //     if (doValidateSvc((employeeInfo.svc?.value), dispatch) &&
        //         doValidateTl((employeeInfo.tl?.value), dispatch)) {
        //         return false
        //     }
        //     return true
        // } else if (checkIsTl(employeeInfo)) {
        //     if (doValidateTl((employeeInfo.tl?.value), dispatch)) {
        //         return false
        //     }
        //     return true
        // }
        return false
    }
    return true
}

export const emptyEmployeeFieldsErrors = (dispatch: any) => {
    dispatch(setProjectErrorMessage(''))
    dispatch(setTlErrorMessage(''));
    dispatch(setSvcErrorMessage(''))
    dispatch(setUserMobileErrorMessage(''));
    dispatch(setSalesRoleErrorMessage(''));
    dispatch(setEmailErrorMessage(''))
    dispatch(setFirstNameErrorMessage(''));
    dispatch(setLastNameErrorMessage(''))
}