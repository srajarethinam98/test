import { useEffect, useMemo, useState } from 'react'
import { useCustomNavigate } from '../../../base/hooks/hooks';
import { Badge, Button, Form, Modal, Spinner } from 'react-bootstrap';
import { useGetFieldEmployeesListQuery } from '../../../services/apiService/fieldEmployees/fieldEmployees';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import Loading from '../../miscellanious/tableLoader/index'
import ResponsivePagination from 'react-responsive-pagination';
import NoData from '../../miscellanious/noData/index'
import { searchParamsInitialData, searchParamsType } from '../../../constants/dropdowns';
import { BiSearch } from "react-icons/bi";
import { IoIosEye } from "react-icons/io";


function FieldEmployeesList() {
  const navigate = useCustomNavigate()
  const [show, setShow] = useState(false);
  const [employeeData, setEmployeeData] = useState<any>(false);

  const [apiParams, setApiParams] = useState<searchParamsType>(searchParamsInitialData)

  const { data: employeeListData, isFetching: employeeListApiIsFetching, isSuccess: employeeListApiIsSuccess, refetch: refetchEmployeeListApi }: any = useGetFieldEmployeesListQuery(apiParams)
  const { data: permissionsList, isSuccess: permissionsListApiIsSuccess }: any = useGetRolePermissionsQuery()

  const handleClose = () => {
    setShow(false)
    setEmployeeData(null)
  }

  const handleShow = (id: string) => {
    if (employeeListData?.data?.employees.length > 0) {
      let employeeData = employeeListData?.data?.employees?.find((employeeObj: any) => employeeObj._id === id)
      setEmployeeData(employeeData)
    }
    setShow(true)
  }

  const doFormArrayOfObject = (apiValue: any) => {
    if (employeeListApiIsSuccess) {
      return apiValue?.data?.employees?.map((employeeObj: any) => {
        return {
          id: employeeObj._id,
          name: employeeObj?.name,
          email: employeeObj?.email,
          phoneNumber: employeeObj?.mobile,
          currentResidentArea: employeeObj?.currentResidentArea,
          salesRole: employeeObj?.profileName
        }
      })
    }
    return []
  }
  const employeeTableList = useMemo(() => doFormArrayOfObject(employeeListData), [employeeListData])

  useEffect(() => {
    if (permissionsListApiIsSuccess) {
      checkScreenAccess(permissionsList, SCREEN_CODES.FIELD_EMPLOYEES, navigate)
    }
  }, [permissionsList])

  return (
    <>
      <div className="dashboard-wrapper">
        <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
          <div className='d-flex align-items-center gap-3'>
            <h5 className='page-title'>Field Employees List <Badge bg="success">{!employeeListApiIsFetching ? employeeListData?.data?.totalCount || 0 : <Spinner size="sm" className='title-badge-spinner' />}</Badge></h5>
            <div className="col-md-6 search-input">
              <Form.Group controlId="userName">
                <Form.Control type="text" name='name'
                  onChange={(event) => setApiParams({ ...apiParams, currentPage: 1, searchString: event.target.value })}
                  placeholder="Search Employee.."
                />
              </Form.Group>
              <BiSearch className='search-icon' />
            </div>
          </div>
        </div>
        <div className="dashboard-card">
          <div className="dashboard-card-body">

            <div className="table-responsive">
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col" style={{ textAlign: 'left' }}>S.No</th>
                    <th scope="col" style={{ textAlign: 'left' }}>Name</th>
                    <th scope="col" style={{ textAlign: 'left' }}>Email ID</th>
                    <th scope="col" style={{ textAlign: 'left' }}>Mobile Number</th>
                    <th scope="col" style={{ textAlign: 'left' }}>Sales Role</th>
                    <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    !employeeListApiIsFetching ? employeeListApiIsSuccess ? employeeListData?.data?.employees?.length > 0 ?
                      employeeTableList?.map((userObj: any, index: any) => {
                        return (
                          <tr key={index}>
                            <td>{index + 1 + (apiParams.currentPage - 1) * employeeListData?.data?.limit}</td>
                            <td>{userObj?.name || '-'}</td>
                            <td>{userObj?.email || '-'}</td>
                            <td>{userObj?.phoneNumber || '-'}</td>
                            <td>{userObj?.salesRole || '-'}</td>
                            <td>
                              <div className='action-col d-flex gap-2'>
                                <a className='edit' title='View' onClick={() => {
                                  handleShow(userObj?.id)
                                }}><IoIosEye /></a>
                              </div>
                            </td>
                          </tr>
                        )
                      }) : <NoData /> : <>Api error</> : <Loading />
                  }
                </tbody>
              </table>
            </div>
            <div className='export-data-footer'>
              <ResponsivePagination
                current={apiParams.currentPage}
                total={employeeListData?.data?.totalPages || 1}
                maxWidth={7}
                onPageChange={(page: any) => setApiParams({ ...apiParams, currentPage: page })}
              />
            </div>
          </div>
        </div>
      </div>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
        style={{ maxWidth: '584px', margin: '0 auto', marginLeft: 'auto',
        marginRight: 'auto',
        left: 0,
        right: 0}}
        size='lg'
      >
        <Modal.Header closeButton>
          <Modal.Title>Employee Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {show && employeeData && <div className='row gy-2 mt-1 field-emp-modal'>
            
              {employeeData?.name && <div className="col-md-6"><label>Name<p>{employeeData?.name}</p></label></div>}
              {employeeData?.email && <div className="col-md-6"><label>Email<p>{employeeData?.email}</p></label></div>}
              {employeeData?.mobile && <div className="col-md-6"><label>Mobile<p>{employeeData?.mobile}</p></label></div>}
              {employeeData?.profileName && <div className="col-md-6"><label>Sales Role<p>{employeeData?.profileName}</p></label></div>}
              {employeeData?.fls?.email && <div className="col-md-6"><label>FLS Email<p>{employeeData?.fls?.email}</p></label></div>}
              {employeeData?.flsTl?.email && <div className="col-md-6"><label>FLSTL Email<p>{employeeData?.flsTl?.email}</p></label></div>}
              {employeeData?.svc?.email && <div className="col-md-6"><label>SVC Email<p>{employeeData?.svc?.email}</p></label></div>}
              {employeeData?.svcTl?.email && <div className="col-md-6"><label>SVCTL Email<p>{employeeData?.svcTl?.email}</p></label></div>}
          </div>
          }
        </Modal.Body>
        <Modal.Footer>
          <Button className='close-btn' onClick={handleClose}>Close</Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default FieldEmployeesList