import moment from "moment"

export type serachReportParams = {
    startDate: string,
    endDate: string,
    selectedStartDate: any,
    selectedEndDate: any,
    status: any,
    project: any,
    search: boolean
}

export const initialParams:serachReportParams={
    startDate: '',
    endDate: '',
    selectedStartDate: moment(),
    selectedEndDate: moment(),
    status: null,
    project: null,
    search: false
}
