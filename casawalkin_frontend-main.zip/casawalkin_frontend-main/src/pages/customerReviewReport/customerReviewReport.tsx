import { useState, useEffect, useMemo } from 'react';
import { Badge, Button, Form, Spinner } from 'react-bootstrap';
import Select from 'react-select';
import { useGetRolePermissionsQuery } from '../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../utils/commonUtils';
import { SCREEN_CODES } from '../../constants/screensConstants';
import { useAppDispatch, useCustomNavigate } from '../../base/hooks/hooks';
import 'bootstrap-daterangepicker/daterangepicker.css';
import ResponsivePagination from 'react-responsive-pagination';
import DateRangePicker from 'react-bootstrap-daterangepicker';
import { useGetProjectListQuery } from '../../services/apiService/projects/project';
import { useGetReviewReportListQuery } from '../../services/apiService/report/report';
import { BsCalendarDate } from "react-icons/bs";
import { HiOutlineDocumentDownload } from "react-icons/hi";
import NoData from '../miscellanious/noData/index';
import Loading from '../miscellanious/tableLoader/index';
import { downloadReviewReportFile } from '../../services/apiService/reportDownload/report';
import { doNotify } from '../../utils/utils';
import { initialParams, serachReportParams } from './customerReviewReportController';

function ReportList() {
    const [currentPage, setCurrentPage] = useState(1);
    const [searchParams, setSearchParams] = useState<serachReportParams>(initialParams);
    const dispatch = useAppDispatch();
    const { data: projectListData } = useGetProjectListQuery();
    const { data: reportListData, isFetching: reportListApiIsFetching, isSuccess: reportListApiIsSuccess } = useGetReviewReportListQuery({ startDate: searchParams?.startDate, endDate: searchParams?.endDate, status: searchParams?.status?.value, project: searchParams?.project?.value, page: currentPage }, { skip: !searchParams?.search });
    const navigate = useCustomNavigate();
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery();
    const [reportBackupList, setReportBackupList] = useState<any>([]);

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.CUSTOMER_REVIEW_REPORT, navigate);
        }
    }, [permissionsList]);

    const pageChange = (value: any) => {
        setCurrentPage(value);
        setSearchParams({ ...searchParams, search: true });
    };

    const handleDateRangePickerEvent = (event: any, picker: any) => {
        setSearchParams({
            ...searchParams, startDate: picker.startDate.format('YYYY-MM-DD'),
            endDate: picker.endDate.format('YYYY-MM-DD'),
            selectedStartDate: picker.startDate,
            selectedEndDate: picker.endDate,
            search: false
        });
    };

    const convertToSelectOptions = (data: any) => {
        return data?.map(
            (data: any) => ({
                value: data._id,
                label: data.name,
            })
        );
    };

    const getSelectInfo = (selectedOption: any, name: string) => {
        setSearchParams({ ...searchParams, [name]: selectedOption, search: false });
    };
    function formatDate(dateString: string | number | Date) {
        const date = new Date(dateString);
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-based
        const year = date.getFullYear();
        let hours = date.getHours();
        const minutes = date.getMinutes().toString().padStart(2, '0');
        const seconds = date.getSeconds().toString().padStart(2, '0');
        const ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        const formattedTime = `${hours}:${minutes}:${seconds} ${ampm}`;
        return `${day}/${month}/${year}, ${formattedTime}`;
    }


    const doFormArrayOfObject = (apiValue: any) => {
        let arr: any = [];
        if (reportListApiIsSuccess) {
            arr = apiValue?.data?.data?.reviews?.map((reviewObj: any) => {
                return {
                    id: reviewObj._id,
                    sfLeadId: reviewObj.customer.uniqueLeadId,
                    leadSFid: reviewObj.customer.leadId,
                    name: reviewObj.name,
                    phone: reviewObj.phone,
                    email: reviewObj.email,
                    project: reviewObj.customer?.project?.name,
                    createdAt: formatDate(reviewObj.createdAt),
                };
            });
            setReportBackupList(arr);
            return arr;
        }
        return arr;
    };

    const projectsList = useMemo(() => convertToSelectOptions(projectListData?.data?.projects), [projectListData]);
    const reportList = useMemo(() => doFormArrayOfObject(reportListData), [reportListData]);

    const exportData = async () => {
        if (reportListData && searchParams.startDate) {
            const params = {
                startDate: searchParams?.startDate, endDate: searchParams?.endDate,
                // status: searchParams?.status?.value || '',
                project: searchParams?.project?.value || ''
            };
            await downloadReviewReportFile(params, dispatch);
        } else {
            doNotify('warning', 'Please select Date range', dispatch);
        }
    };

    const searchHandler = () => {
        if (searchParams.startDate) {
            setCurrentPage(1);
            setSearchParams({ ...searchParams, search: true });
        } else {
            doNotify('warning', 'Please select Date range', dispatch);
        }
    };

    const resetFilters = () => {
        setSearchParams(initialParams);
        setCurrentPage(1);
        setReportBackupList([]);
    };

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <div className="row align-items-center w-100">
                        <div className="col-md-auto">
                            <h5 className='page-title'>Review Report<Badge bg="success">{!reportListApiIsFetching ? reportBackupList.length > 0 ? reportListData?.data?.data?.totalCount || 0 : 0 : <Spinner size="sm" />}</Badge></h5>
                        </div>
                        <div className="col-md-10">
                            <div className="row gy-3 justify-content-end">
                                <div className="col-md-3 col-sm-12">
                                    <Form.Group>
                                        <Select
                                            className='common-input'
                                            placeholder="Select Project"
                                            options={projectsList}
                                            value={searchParams?.project || null}
                                            onChange={(value) => getSelectInfo(value, 'project')}
                                        />
                                    </Form.Group>
                                </div>
                                <div className="col-md-3 col-sm-12">
                                    <Form.Group className='datepicker-form'>
                                        <DateRangePicker
                                            initialSettings={{ startDate: searchParams.selectedStartDate, endDate: searchParams.selectedEndDate }}
                                            onApply={handleDateRangePickerEvent}
                                        >
                                            <button>{searchParams?.startDate ? `${searchParams?.startDate}  -  ${searchParams?.endDate}` : 'Choose Date Range'}</button>
                                        </DateRangePicker>
                                        <BsCalendarDate className='calendar-icon' />
                                    </Form.Group>
                                </div>
                                <div className="col-md-2 col-sm-12 d-flex justify-content-center">
                                    <Button className='add-btn w-100' onClick={() => searchHandler()} >Search</Button>
                                </div>
                                <div className="col-md-1 col-sm-12 d-flex">
                                    <Button className='btn btn-warning' onClick={() => resetFilters()}  ><span>Reset</span></Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <div className="table-responsive export-table">
                            <table className="table nowrap">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ width: '80px' }}>S.No</th>
                                        <th scope="col">SFLead Id</th>
                                        <th scope="col">LeadSF Id</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Phone Number</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Project</th>
                                        <th scope="col">Created At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {!reportListApiIsFetching ?
                                        searchParams?.startDate
                                            ?
                                            reportList?.length > 0 ?
                                            reportBackupList?.map((reviewObj: any, index: any) => {
                                                    return (
                                                        <tr key={index}>
                                                            <td>{index + 1}</td>
                                                            <td>{reviewObj?.sfLeadId || '-'}</td>
                                                            <td>{reviewObj?.leadSFid || '-'}</td>
                                                            <td>{reviewObj?.name || '-'}</td>
                                                            <td>{reviewObj?.phone || '-'}</td>
                                                            <td>{reviewObj?.email || '-'}</td>
                                                            <td>{reviewObj?.project || '-'}</td>
                                                            <td>{reviewObj?.createdAt}</td>
                                                        </tr>
                                                    )
                                                })
                                                : <NoData />
                                            : <NoData />
                                        : <Loading />
                                    }
                                </tbody>
                            </table>
                        </div>
                        <div className='export-data-footer'>
                            {searchParams?.startDate ? <ResponsivePagination
                                current={currentPage}
                                maxWidth={7}
                                total={reportListData?.data?.totalPages}
                                onPageChange={pageChange}
                            /> : null}
                            <button onClick={exportData} disabled={!reportListData && !searchParams?.startDate} className='btn btn-success'><HiOutlineDocumentDownload /> Export</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ReportList;
