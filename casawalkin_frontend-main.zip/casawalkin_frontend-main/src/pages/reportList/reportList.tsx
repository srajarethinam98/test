import { useState, useEffect, useMemo } from 'react'
import { Badge, Button, Form, Spinner } from 'react-bootstrap'
import Select from 'react-select'
import { useGetRolePermissionsQuery } from '../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../utils/commonUtils';
import { SCREEN_CODES } from '../../constants/screensConstants';
import { useAppDispatch, useCustomNavigate } from '../../base/hooks/hooks';
import 'bootstrap-daterangepicker/daterangepicker.css';
import ResponsivePagination from 'react-responsive-pagination';
import DateRangePicker from 'react-bootstrap-daterangepicker';
import { useGetProjectListQuery } from '../../services/apiService/projects/project';
import { useGetReportListQuery } from '../../services/apiService/report/report';
import { BsCalendarDate } from "react-icons/bs";
import { HiOutlineDocumentDownload } from "react-icons/hi";
import { leadStatusList } from '../../constants/dropdowns';
import NoData from '../miscellanious/noData/index'
import Loading from '../miscellanious/tableLoader/index'
import { downloadFile } from '../../services/apiService/reportDownload/report';
import { doNotify } from '../../utils/utils';
import { initialParams, serachReportParams } from './reportController';

function ReportList() {
    const [currentPage, setCurrentPage] = useState(1);
    const [searchParams, setSearchParams] = useState<serachReportParams>(initialParams)
    const dispatch = useAppDispatch()
    const { data: projectListData } = useGetProjectListQuery()
    const { data: reportListData, isFetching: reportListApiIsFetching, isSuccess: reportListApiIsSuccess } = useGetReportListQuery({ startDate: searchParams?.startDate, endDate: searchParams?.endDate, status: searchParams?.status?.value, project: searchParams?.project?.value, page: currentPage }, { skip: !searchParams?.search })
    const navigate = useCustomNavigate()
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const [reportBackupList, setReportBackupList] = useState<any>([])
    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.REPORT, navigate)
        }
    }, [permissionsList])

    const pageChange = (value: any) => {
        setCurrentPage(value)
        setSearchParams({ ...searchParams, search: true })
    }

    const handleDateRangePickerEvent = (event: any, picker: any) => {
        setSearchParams({
            ...searchParams, startDate: picker.startDate.format('YYYY-MM-DD'),
            endDate: picker.endDate.format('YYYY-MM-DD'),
            selectedStartDate: picker.startDate,
            selectedEndDate: picker.endDate,
            search: false
        })
    }

    const convertToSelectOptions = (data: any) => {
        return data?.map(
            (data: any) => ({
                value: data._id,
                label: data.name,
            })
        );
    }
    const getSelectInfo = (selectedOption: any, name: string) => {
        setSearchParams({ ...searchParams, [name]: selectedOption, search: false })
    }

    const doFormArrayOfObject = (apiValue: any) => {
        let arr: any = []
        if (reportListApiIsSuccess) {
            arr = apiValue?.data?.data?.map((reportObj: any) => {
                let budget = reportObj?.preferredBudgetRange?.minBudget ? `${reportObj?.preferredBudgetRange?.minBudget} - ${reportObj?.preferredBudgetRange?.maxBudget}` : null
                let fullName = `${reportObj?.firstName || ''} ${reportObj?.lastName || ''}`
                let ageRange = reportObj?.ageRange?.minAge ? `${reportObj?.ageRange?.minAge} - ${reportObj?.ageRange?.maxAge}` || '-' : null
                let size = reportObj?.preferredSize?.minSize && reportObj?.preferredSize?.maxSize ? `${reportObj?.preferredSize?.minSize} - ${reportObj?.preferredSize?.maxSize || null}` : null || '-'
                return {
                    id: reportObj._id,
                    leadId: reportObj?.leadId,
                    fullName: fullName,
                    phoneNumber: reportObj?.phoneNumber,
                    email: reportObj?.email,
                    currentResidentArea: reportObj?.currentResidentArea,
                    projectName: reportObj?.project?.name,
                    budget: budget,
                    occupation: reportObj?.occupation?.occupation,
                    purpose: reportObj?.purposeOfPurchase?.purpose,
                    ageRange: ageRange,
                    alternateNumber: reportObj?.alternateNumber,
                    assignedTo: reportObj?.assignedTo,
                    size: size,
                    unit: reportObj?.preferredUnit?.varient,
                    source: reportObj?.sourceOfInformation?.source,
                    status: reportObj?.status,
                    createAt: reportObj?.createdAt,
                    uniqueLeadId : reportObj?.uniqueLeadId
                }
            })
            setReportBackupList(arr)

            return arr
        }
        return arr
    }
    const projectsList = useMemo(() => convertToSelectOptions(projectListData?.data?.projects), [projectListData])
    const reportList = useMemo(() => doFormArrayOfObject(reportListData), [reportListData])

    const exportData = async () => {
        if (reportListData && searchParams.startDate) {
            const params={
                startDate: searchParams?.startDate, endDate: searchParams?.endDate,
                status: searchParams?.status?.value || '',
                project: searchParams?.project?.value || ''
             }
            await downloadFile(params,dispatch)
        } else {
            doNotify('warning', 'Please select Date range', dispatch)
        }
    }

    const searchHandler = () => {
        if (searchParams.startDate) {
            setCurrentPage(1)
            setSearchParams({ ...searchParams, search: true })
        } else {
            doNotify('warning', 'Please select Date range', dispatch)
        }
    }

    const resetFilters = () => {
        setSearchParams(initialParams)
        setCurrentPage(1)
        setReportBackupList([])
    }
    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <div className="row align-items-center w-100">
                        <div className="col-md-auto">
                            <h5 className='page-title'>Report<Badge bg="success">{!reportListApiIsFetching ?reportBackupList.length>0? reportListData?.data?.totalCount || 0:0 : <Spinner size="sm" />}</Badge></h5>
                        </div>
                        <div className="col-md-11">
                            <div className="row gy-3 justify-content-between">
                                <div className="col-md-3 col-sm-12">
                                    <Form.Group>
                                        <Select
                                            className='common-input'
                                            placeholder="Select Project"
                                            options={projectsList}
                                            value={searchParams?.project || null}
                                            onChange={(value) => getSelectInfo(value, 'project')}
                                        />
                                    </Form.Group>
                                </div>
                                <div className="col-md-3 col-sm-12">
                                    <Form.Group className='datepicker-form'>
                                        <DateRangePicker
                                            initialSettings={{ startDate: searchParams.selectedStartDate, endDate: searchParams.selectedEndDate }}
                                            onApply={handleDateRangePickerEvent}
                                        >
                                            <button>{searchParams?.startDate ? `${searchParams?.startDate}  -  ${searchParams?.endDate}` : 'Choose Date Range'}</button>
                                        </DateRangePicker>
                                        <BsCalendarDate className='calendar-icon' />
                                    </Form.Group>
                                </div>
                                <div className="col-md-3 col-sm-12">
                                    <Form.Group>
                                        <Select
                                            className='common-input'
                                            placeholder="Select Status"
                                            value={searchParams?.status || null}
                                            options={leadStatusList}
                                            onChange={(value) => getSelectInfo(value, 'status')}
                                        />

                                    </Form.Group>
                                </div>
                                <div className="col-md-2 col-sm-12 d-flex justify-content-center">
                                    <Button className='add-btn w-100' onClick={() => searchHandler()} >Search</Button>
                                </div>
                                <div className="col-md-1 col-sm-12 d-flex">
                                    <Button className='btn btn-warning' onClick={() => resetFilters()}  ><span>Reset</span></Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">

                        <div className="table-responsive export-table">
                            <table className="table nowrap">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ width: '80px' }}>S.No</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Lead ID</th>
                                        <th scope="col">Phone Number</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Address</th>
                                        <th scope="col">Project Name</th>
                                        <th scope="col">Budget</th>
                                        <th scope="col">Occupation</th>
                                        <th scope="col">Purpose</th>
                                        <th scope="col">Age</th>
                                        <th scope="col">Sec Phone Number</th>
                                        <th scope="col">Assigned To</th>
                                        <th scope="col">Size</th>
                                        <th scope="col">Unit</th>
                                        <th scope="col">How did i know</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Created At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {!reportListApiIsFetching ?
                                        searchParams?.startDate
                                            ?
                                            reportList?.length > 0 ?
                                            reportBackupList?.map((reportObj: any, index: any) => {
                                                    return (
                                                        <tr key={index}>
                                                            <td>{index + 1}</td>
                                                            <td>{reportObj?.fullName || '-'}</td>
                                                            <td>{reportObj?.uniqueLeadId || '-'}</td>
                                                            <td>{reportObj?.phoneNumber || '-'}</td>
                                                            <td>{reportObj?.email || '-'}</td>
                                                            <td>{reportObj?.currentResidentArea || '-'}</td>
                                                            <td>{reportObj?.projectName || '-'}</td>
                                                            <td>{reportObj?.budget || '-'}</td>
                                                            <td>{reportObj?.occupation || '-'}</td>
                                                            <td>{reportObj?.purpose || '-'}</td>
                                                            <td>{reportObj?.ageRange}</td>
                                                            <td>{reportObj?.alternateNumber || '-'}</td>
                                                            <td>{reportObj?.assignedTo || '-'}</td>
                                                            <td>{reportObj?.size}</td>
                                                            <td>{reportObj?.unit}</td>
                                                            <td>{reportObj?.source}</td>
                                                            <td>{reportObj?.status}</td>
                                                            <td>{reportObj?.createAt}</td>
                                                        </tr>
                                                    )
                                                })
                                                : <NoData />
                                            : <NoData />
                                        : <Loading />
                                    }

                                </tbody>
                            </table>
                        </div>

                        <div className='export-data-footer'>
                            {searchParams?.startDate ? <ResponsivePagination
                                current={currentPage}
                                maxWidth={7}
                                total={reportListData?.data?.totalPages}
                                onPageChange={pageChange}

                            /> : null}
                            <button onClick={exportData} disabled={!reportListData && !searchParams?.startDate} className='btn btn-success'><HiOutlineDocumentDownload /> Export</button>
                        </div>
                    </div>
                </div>
            </div >
        </>
    )
}

export default ReportList