import {useEffect} from 'react'
import { Button } from 'react-bootstrap'
import { useGetPreferredUnitListQuery, useDeletePreferredUnitMutation } from '../../../services/apiService/preferredUnit/preferredUnit';
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { PATH } from '../../../constants/path';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import Loading from '../../miscellanious/tableLoader/index'
import NoData from '../../miscellanious/noData/index'
import { AiOutlinePlus,AiOutlineEdit ,AiOutlineDelete} from "react-icons/ai";

function PreferredUnitsList() {
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const [deleteUnitApi] = useDeletePreferredUnitMutation()

    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const { data: unitListData, isLoading: unitListApiIsLoading, isSuccess: unitListApiIsSuccess } = useGetPreferredUnitListQuery()
    const deleteUnit = async (id: any) => {
        await deleteUnitApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message|| 'Unit deleted successfully', dispatch)
        }).catch((err: any) => {
            if (err?.data?.statusCode===401) {
                dispatch(setUnAuthorized(true))
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete Unit', dispatch)
        })
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.PREFERRED_UNIT, navigate)
        }
    }, [permissionsList])
    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Preferred Units List</h5>
                    <Button className='add-btn mx-3' onClick={() => navigate(PATH.PREFERRED_UNITS_ADD)}><span><AiOutlinePlus /> Create Unit</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">

                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>SNo</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Preferred Units</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Label</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        !unitListApiIsLoading ? unitListApiIsSuccess ?unitListData?.data?.units?.length>0?
                                            unitListData?.data?.units?.map((unitObj: any, index: any) => {
                                                let id = unitObj?._id
                                                return (
                                                    <tr key={index}>

                                                        <td>{index + 1}</td>
                                                        <td>{unitObj?.varient || '-'}</td>
                                                        <td>{unitObj?.description || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/preferred-units/edit-unit/?id=${id}`)

                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deleteUnit(id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }):<NoData/> : <>Api error</> : <Loading/>
                                        }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default PreferredUnitsList