import React, { useEffect, useState } from 'react'
import { unitInfoType, unitFieldsValidation, unitInitialState, checkUnitsFieldsErrors, emptyUnitFieldsErrors } from './preferedUnitController';
import { doNotify, doValidatepreferredUnit, doValidateLabel } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { useCreateAcquisitionMutation } from '../../../services/apiService/acquisitionForm/acquisitionForm';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import Select from 'react-select'
import { useCreatePreferredUnitMutation, useEditPreferredUnitMutation, useGetSinglePreferredUnitQuery } from '../../../services/apiService/preferredUnit/preferredUnit';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function PreferredUnitsAdd() {
    const [unitInfo, setUnitInfo] = useState<unitInfoType>(unitInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const { preferredUnitErrorMessage, labelErrorMessage }: any = useAppSelector((state) => state.ErrorMessageReducer)

    const [creatunitsApi, { isLoading: creatunitApiIsloading }] = useCreatePreferredUnitMutation()
    const [editunitsApi, { isLoading: editunitApiIsloading }] = useEditPreferredUnitMutation()
    const { data: getSingleunit, isSuccess: getSingleunitApiIsSuccess, isError: getSingleunitApiIsError, error: getSingleunitApiError }: any = useGetSinglePreferredUnitQuery(id, { skip: !id })

    const getunitInfo = (event: any) => {
        const { name, value }: any = event.target
        setUnitInfo({ ...unitInfo, [name]: value })//.trim()
        unitFieldsValidation(event, dispatch)
    }
    const handleSubmit = async () => {
        if (!checkUnitsFieldsErrors(unitInfo, dispatch)) {
            let body: any = {
                varient: unitInfo.name,
                description: unitInfo.description,
            }
            if (id) {
                await editunitsApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message|| 'unit updated successfully', dispatch)
                    navigate(PATH.PREFERRED_UNITS_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode===401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update unit', dispatch)
                })
            } else {
                await creatunitsApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'unit created successfully', dispatch)
                    navigate(PATH.PREFERRED_UNITS_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode===401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create unit', dispatch)
                })
            }
        }
    }
    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.PREFERRED_UNIT, navigate)
        }
        if (type==='edit-unit') {
            !id && navigate(PATH.PREFERRED_UNITS_LIST)
            if (getSingleunitApiIsError) {
                navigate(PATH.PREFERRED_UNITS_LIST)
                doNotify('error', getSingleunitApiError?.data?.error?.message|| 'Failed to get Acquisition', dispatch)
              }
        }
        if (getSingleunitApiIsSuccess) {
            let unitObj: any = getSingleunit?.data?.unit
            setUnitInfo({
                ...unitInfo,
                name: unitObj?.varient,
                description: unitObj?.description
            })
        }
        return () => {
            emptyUnitFieldsErrors(dispatch)
            setUnitInfo(unitInitialState)
        }
    }, [getSingleunit, id,permissionsList,getSingleunitApiIsError])
    const handleCancel = () => {
        emptyUnitFieldsErrors(dispatch)
        navigate(PATH.PREFERRED_UNITS_LIST)
        setUnitInfo(unitInitialState)
    }
   
  return (
    <>
    <div className='dashboard-wrapper'>
        <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
          <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item  onClick={handleCancel}>
                        Preferred Units List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type==='add-unit' ? 'Add Unit' : 'Edit Unit'}</Breadcrumb.Item>
                    </Breadcrumb>
        </div>
        <div className="dashboard-card">
            <div className="dashboard-card-body">
                <Form autoComplete="off">
                    <div className="row gy-4">
                        <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="units">
                                <Form.Label>Preferred Units*</Form.Label>
                                <Form.Control type="text" placeholder="Enter Preferred Units"  value={unitInfo?.name} name='name' onChange={getunitInfo} onBlur={(event) => doValidatepreferredUnit(event.target.value, dispatch)} />
                                <p className='error-msg'>{preferredUnitErrorMessage}</p>
                            </Form.Group>
                        </div>
                        <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="description">
                                <Form.Label>Label</Form.Label>
                                <Form.Control type="text" placeholder="Enter Label"  value={unitInfo?.description} name='description' onChange={getunitInfo}
                                onBlur={() => doValidateLabel(unitInfo.description, dispatch, false)}
                                />
                                <p className='error-msg'>{labelErrorMessage}</p>                              
                            </Form.Group>
                        </div>
                    </div>
                    <div className="row mt-3 mb-2">
                        <div className="col-md-12">
                            <div className='d-flex justify-content-center gap-3 mt-3'>
                                <Button className='close-btn' onClick={handleCancel}>
                                    <span><MdOutlineClose /> Cancel</span>
                                </Button>
                                <Button onClick={handleSubmit} disabled={creatunitApiIsloading||editunitApiIsloading}  className='submit-btn'><span> {creatunitApiIsloading||editunitApiIsloading?<Spinner animation="border" size="sm" />:<><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                            </div>
                        </div>
                    </div>
                </Form>
            </div>
        </div>
    </div>
</>
  )
}

export default PreferredUnitsAdd