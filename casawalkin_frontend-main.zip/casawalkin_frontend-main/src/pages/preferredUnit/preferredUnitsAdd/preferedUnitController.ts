import messages from '../../../constants/messageConstants'
import { setPreferredUnitErrorMessage, setLabelErrorMessage } from "../../../base/reducer/errorMessageReducer"
import { doValidatepreferredUnit, doValidateLabel } from "../../../utils/utils"

export type unitInfoType = {
    name: string,
    description: string,
}

export const unitInitialState: unitInfoType = {
    name: '',
    description: '',
}


export const unitFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'name':
            value !== '' ? dispatch(setPreferredUnitErrorMessage('')) : dispatch(setPreferredUnitErrorMessage(`${messages.emptyField} Unit`))
            break
        
    }
}

export const checkUnitsFieldsErrors = (unitInfo: unitInfoType, dispatch: any) => {
    doValidatepreferredUnit((unitInfo.name), dispatch)
    doValidateLabel((unitInfo.description), dispatch, false)
    
    if (doValidatepreferredUnit((unitInfo.name), dispatch) && doValidateLabel((unitInfo.description), dispatch, false)
    ) {
        return false
    }
    return true
}

export const emptyUnitFieldsErrors = (dispatch: any) => {
    dispatch(setPreferredUnitErrorMessage(''))
    dispatch(setLabelErrorMessage(''))
}