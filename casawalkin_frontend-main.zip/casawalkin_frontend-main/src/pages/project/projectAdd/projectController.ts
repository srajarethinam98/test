import messages from '../../../constants/messageConstants'
import { setProjectErrorMessage, setLabelErrorMessage, setZoneErrorMessage } from "../../../base/reducer/errorMessageReducer"
import { doValidateProject, doValidateLabel, doValidateZone } from "../../../utils/utils"

export type projectInfoType = {
    project: any,
    description: string,
    zone: any
}

export const projectInitialState: projectInfoType = {
    project: '',
    description: '',
    zone: null
}


export const projectFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'project':
            value !== '' ? dispatch(setProjectErrorMessage('')) : dispatch(setProjectErrorMessage(`${messages.emptyField} Project`))
            break
        
    }
}

export const checkProjectsFieldsErrors = (projectInfo: projectInfoType, dispatch: any) => {
    doValidateProject((projectInfo.project), dispatch)
    doValidateLabel((projectInfo.description), dispatch, false)
    doValidateZone((projectInfo?.zone), dispatch)

    
    if (doValidateProject((projectInfo.project), dispatch) && 
        doValidateLabel((projectInfo.description), dispatch, false) &&
        doValidateZone((projectInfo?.zone), dispatch)

    ) {
        return false
    }
    return true
}

export const emptyProjectFieldsErrors = (dispatch: any) => {
    dispatch(setProjectErrorMessage(''))
    dispatch(setLabelErrorMessage(''))
    dispatch(setZoneErrorMessage(''))
   
}