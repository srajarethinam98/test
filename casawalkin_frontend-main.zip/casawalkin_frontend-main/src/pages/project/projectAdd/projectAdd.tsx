import { useEffect, useState } from 'react'
import { projectInfoType, projectFieldsValidation, projectInitialState, checkProjectsFieldsErrors, emptyProjectFieldsErrors } from './projectController';
import { doNotify, doValidateProject, doValidateLabel, doValidateZone } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import Select from 'react-select'
import { useCreateProjectMutation, useEditProjectMutation, useGetSingleProjectQuery, useGetSFProjectListQuery } from '../../../services/apiService/projects/project';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { getOptionObject } from '../../../utils/commonUtils';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function ProjectAdd() {
    const [projectInfo, setProjectInfo] = useState<projectInfoType>(projectInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();
    const [dropDownData, setDownData] = useState<any>([])

    const { projectErrorMessage, labelErrorMessage, zoneErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer)

    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const [creatprojectsApi, { isLoading: creatprojectApiIsloading }] = useCreateProjectMutation()
    const [editprojectsApi, { isLoading: editprojectApiIsloading }] = useEditProjectMutation()
    const { data: getSingleproject, isSuccess: getSingleprojectApiIsSuccess, isError: getSingleprojectApiIsError, error: getSingleprojectApiError }: any = useGetSingleProjectQuery(id, { skip: !id })
    const { data: salesProjectsApiResponse, isLoading: salesProjectsApiIsloading, isSuccess: salesProjectsApiIsSuccess } = useGetSFProjectListQuery()

    const getprojectInfo = (event: any) => {
        const { name, value }: any = event.target
        setProjectInfo({ ...projectInfo, [name]: value })//.trim()
        projectFieldsValidation(event, dispatch)
    }

    const handleSelectChange = (selectedOption: any, name: string) => {
        setProjectInfo({ ...projectInfo, [name]: selectedOption })//.trim()
        projectFieldsValidation({ target: { name: name, value: selectedOption.value } }, dispatch)
    };

    const handleSubmit = async () => {
        if (!checkProjectsFieldsErrors(projectInfo, dispatch)) {
            let body: any = {
                name: projectInfo.project?.value,
                description: projectInfo?.description,
                zone: projectInfo?.zone || null
            }
            if (id) {
                await editprojectsApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Project updated successfully', dispatch)
                    navigate(PATH.PROJECT_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode===401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update Project', dispatch)
                })
            } else {
                await creatprojectsApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Project created successfully', dispatch)
                    navigate(PATH.PROJECT_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode===401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to create Project', dispatch)
                })
            }
        }
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.PROJECT, navigate)
        }
        if (type==='edit-project') {
            !id && navigate(PATH.PROJECT_LIST)
            if (getSingleprojectApiIsError) {
                navigate(PATH.PROJECT_LIST)
                doNotify('error', getSingleprojectApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        }
        if (salesProjectsApiIsSuccess) {
            const data = salesProjectsApiResponse?.data?.projects
            setDownData(data)
        }
        if (getSingleprojectApiIsSuccess) {
            let projectObj: any = getSingleproject?.data?.project
            const dropdowndetails = salesProjectsApiResponse?.data?.projects
            setProjectInfo({
                ...projectInfo,
                project: getOptionObject(dropdowndetails, projectObj?.name),// projectObj?.name,
                description: projectObj?.description,
                zone: projectObj.zone
            })
        }
        return () => {
            emptyProjectFieldsErrors(dispatch)
            setProjectInfo(projectInitialState)
        }
    }, [getSingleproject, id, salesProjectsApiResponse, getSingleprojectApiIsError])

    const handleCancel = () => {
        emptyProjectFieldsErrors(dispatch)
        navigate(PATH.PROJECT_LIST)
        setProjectInfo(projectInitialState)
    }
    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel} >
                            Project List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type==='edit-project' ? 'Edit Project' : 'Add Project'}</Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-4">
                                <div className="col-md-6">
                                    <label className='select-label'>Select Project</label>
                                    <Select
                                        className='common-input'
                                        value={projectInfo?.project}
                                        onChange={(option: any) => handleSelectChange(option, 'project')}
                                        options={dropDownData}
                                        placeholder="Select Project"
                                        onBlur={(event: any) => doValidateProject(projectInfo.project, dispatch)}
                                        isSearchable
                                    />
                                    <p className='error-msg'>{projectErrorMessage}</p>

                                </div>
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="description">
                                        <Form.Label>Label</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Label" name='description' value={projectInfo.description} onChange={getprojectInfo}
                                        onBlur={() => doValidateLabel(projectInfo.description, dispatch, false)}
                                        />
                                        <p className='error-msg'>{labelErrorMessage}</p>
                                    </Form.Group>
                                </div>
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="zone">
                                        <Form.Label>Zone</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Zone" name='zone' value={projectInfo?.zone} onChange={getprojectInfo}
                                        onBlur={() => doValidateZone(projectInfo.zone, dispatch)}
                                        />
                                        <p className='error-msg'>{zoneErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            </div>
                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button className='submit-btn' disabled={editprojectApiIsloading || creatprojectApiIsloading} onClick={handleSubmit}><span>{editprojectApiIsloading || creatprojectApiIsloading ?<Spinner animation="border" size="sm" />: <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ProjectAdd