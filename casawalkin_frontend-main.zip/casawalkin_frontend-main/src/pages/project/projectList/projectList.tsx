import { useEffect } from 'react'
import { Button } from 'react-bootstrap'
import { useGetProjectListQuery, useDeleteProjectMutation } from '../../../services/apiService/projects/project';
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { PATH } from '../../../constants/path';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import Loading from '../../miscellanious/tableLoader/index'
import NoData from '../../miscellanious/noData/index'
import { AiOutlinePlus,AiOutlineEdit ,AiOutlineDelete} from "react-icons/ai";

function ProjectList() {
    const navigate = useCustomNavigate()
    const [deleteProjectApi] = useDeleteProjectMutation()
    const dispatch = useAppDispatch()
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const { data: ProjectListData, isLoading: ProjectListApiIsLoading, isSuccess: ProjectListApiIsSuccess } = useGetProjectListQuery()
    
    const deleteProject = async (id: any) => {
        await deleteProjectApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'Project deleted successfully', dispatch)
        }).catch((err: any) => {
            if (err?.data?.statusCode === 401) {
                dispatch(setUnAuthorized(true))
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete Project', dispatch)
        })
    }
    
    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.PROJECT, navigate)
        }
    }, [permissionsList])

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Project List</h5>
                    <Button className='add-btn mx-3' onClick={() => navigate(PATH.PROJECT_ADD)}><span><AiOutlinePlus /> Create Project</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">

                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ textAlign: 'left' }}>S No</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Project Name</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Label</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Zone</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        !ProjectListApiIsLoading ? ProjectListApiIsSuccess ? ProjectListData?.data?.projects?.length > 0 ?
                                            ProjectListData?.data?.projects?.map((projectObj: any, index: any) => {
                                                let id = projectObj?._id
                                                return (
                                                    <tr key={index}>
                                                        <td>{index + 1}</td>
                                                        <td>{projectObj?.name || '-'}</td>
                                                        <td>{projectObj?.description || '-'}</td>
                                                        <td>{projectObj?.zone || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/project/edit-project/?id=${id}`)
                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deleteProject(id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }) : <NoData /> : <>Api error</> : <Loading />
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ProjectList