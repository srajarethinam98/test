import {  doValidateProject, doValidateMobileNumber, doValidateFirstName, doValidateLatName, doValidateAlternateMobileNumber, doValidateAreaOfCurrentResident, doValidateLeadOwner } from "../../../utils/utils"
import { AcquisitionInfoType } from "../acquisitionForm/acquisitionFormController"

export const checkAcquisitionFirstStepErrors = (AcquisitionInfo: AcquisitionInfoType, dispatch: any) => {
    doValidateProject((AcquisitionInfo.project?.value), dispatch)
    doValidateFirstName((AcquisitionInfo.firstName), dispatch)
    doValidateLatName((AcquisitionInfo.lastName), dispatch)
    doValidateMobileNumber((AcquisitionInfo.mobile), dispatch, AcquisitionInfo.countryCode)
    doValidateAlternateMobileNumber((AcquisitionInfo.alternateMobile), dispatch, AcquisitionInfo.alternateCountryCode)
    doValidateAreaOfCurrentResident((AcquisitionInfo.areaOfCurrentResident), dispatch)
    if (AcquisitionInfo.enableLeadOwner) {
        doValidateLeadOwner(AcquisitionInfo.ownerEmail, dispatch);
    }

    if (doValidateProject((AcquisitionInfo.project?.value), dispatch) &&
        doValidateFirstName((AcquisitionInfo.firstName), dispatch) &&
        doValidateLatName((AcquisitionInfo.lastName), dispatch) &&
        doValidateMobileNumber((AcquisitionInfo.mobile), dispatch, AcquisitionInfo.countryCode) &&
        doValidateAlternateMobileNumber((AcquisitionInfo.alternateMobile), dispatch, AcquisitionInfo.alternateCountryCode) &&
        doValidateAreaOfCurrentResident((AcquisitionInfo.areaOfCurrentResident), dispatch) &&
        (!AcquisitionInfo.enableLeadOwner || doValidateLeadOwner(AcquisitionInfo.ownerEmail, dispatch))
    ) {
        return false
    }
    return true
}
