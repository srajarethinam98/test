import { useState, useEffect } from 'react';
import './acquisitionFormMain.scss';
import logo from '../../../assets/cg-logo-nobg.png'
import { checkAcquisitionFirstStepErrors } from './aquisitionMainController';
import { useAppDispatch, useAppSelector } from '../../../base/hooks/hooks';
import { doNotify, doValidateAlternateMobileNumber, doValidateAreaOfCurrentResident, doValidateEmail, doValidateFirstName, doValidateHowDidYouKnowAboutUs, doValidateLatName, doValidateMobileNumber, doValidatePreferredBudgetRange, doValidatePreferredUnits, doValidateProject, doValidateSocialMedia, doValidateEmpName, doValidateEmpId, doValidateRefProject, doValidateContactNumber, doValidateUnitNo, doValidateDepartmentName, doValidatePurposeOfVisit, doValidateLeadOwner } from '../../../utils/utils';
import { useCreateAcquisitionMutation, useGetAquisitionDropdownsDetailsQuery, useSendOtpMutation, useValidateOtpMutation, useAssignFieldDropdownListQuery } from '../../../services/apiService/acquisitionForm/acquisitionForm';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import messages from '../../../constants/messageConstants'
import { getAquisitionFormOptionsInfo } from '../../../utils/commonUtils';
import { Button, Form, Spinner } from 'react-bootstrap';
import Select, { SingleValue } from 'react-select'
import { AcquisitionInfoType, acquisitionFieldsValidation, acquisitionInitialState, checkAcquisitionErrors, emptyAcquisitionErrors, formatAcquisitionRequestBody, checkAcquisitionError } from '../acquisitionForm/acquisitionFormController';
import { countryCodes } from '../../common/country';
import { PATH } from '../../../constants/path';
import { useNavigate } from 'react-router-dom';

function AcquisitionFormMain() {
    const navigate = useNavigate()
    const [acquisitionInfo, setAcquisitionInfo] = useState<AcquisitionInfoType>(acquisitionInitialState)
    const [enableLeadOwner, setEnableLeadOwner] = useState(false);
    const dispatch = useAppDispatch()
    const [step, setStep] = useState(1);
    const [dropDownsData, setDropDownsData] = useState<any>({})
    const [isOtpSent, setIsOtpSent] = useState(false);
    const [otp, setOtp] = useState('');
    const [otpValidated, setOtpValidated] = useState(false);
    const [isMobileValid, setIsMobileValid] = useState(false);
    const [isFormSubmitted, setIsFormSubmitted] = useState(false);
    const [customerType, setCustomerType] =  useState<SingleValue<any>>(null);
    const [bookedCustomer, setBookedCustomer] = useState(false);


    const { emailErrorMessage, lastNameErrorMessage, firstNameErrorMessage, areaOfCurrentResidentErrorMessage, mobileErrorMessage, projectErrorMessage, alternateMobileErrorMessage, preferredUnitsErrorMessage, preferredBudgetRangeErrorMessage, howDidYouKnowAboutUsErrorMessage, socialMediaErrorMessage, empNameErrorMessage, empIdErrorMessage, refProjectErrorMessage, contactErrorMessage, unitNoErrorMessage, departmentNameErrorMessage, purposeOfVisitErrorMessage, leadOwnerErrorMessage }: any = useAppSelector((state) => state.ErrorMessageReducer)

    const [creatAcquisitionApi, { isLoading: creatAcquisitionApiIsloading }] = useCreateAcquisitionMutation()
    const { data: aquisitionDropdownsData, isSuccess: aquisitionDropdownsApiIsSuccess } = useGetAquisitionDropdownsDetailsQuery()
    const [sendOtpApi, { isLoading: sendOtpApiIsloading }] = useSendOtpMutation();
    const [validateOtpApi, { isLoading: validateOtpApiIsloading }] = useValidateOtpMutation();
    const { data: salesDropdownsApiResponse, isSuccess: salesDropdownsApiIsSuccess } = useAssignFieldDropdownListQuery({})

    const next = () => setStep(step + 1);;
    const prev = () => setStep(step - 1);;

    const getAcquisitionInfo = (event: any) => {
        const { name, value }: any = event.target
        if (name === 'firstName' || name === 'lastName' || name === 'areaOfCurrentResident' || name === 'referredCPName' || name === 'referredFriendName' || name === "referredEmpName" || name === "referredEmpId" || name === "otherReferrence" || name === 'referredProjectName' || name === 'existingUserProjectName' || name === 'existingUserUnitNo') {
            setAcquisitionInfo({ ...acquisitionInfo, [name]: value })
        } else {
            setAcquisitionInfo({ ...acquisitionInfo, [name]: value.trim() })
        }
        acquisitionFieldsValidation(event, dispatch)
        localStorage.setItem('acquisitionInfo', JSON.stringify(acquisitionInfo))
    }

    const getSelectInfo = (value: any, name: string) => {
        if (name === 'ownerEmail') {
            setAcquisitionInfo({
                ...acquisitionInfo,
                ownerEmail: value
            });
        } else if (name === "customerType") {
            setAcquisitionInfo({ ...acquisitionInfo, customerType: value });
            if (value.value === "Booked Customer") {
                setBookedCustomer(true);
            } else {
                setBookedCustomer(false);
            }
        } else {
            setAcquisitionInfo({ ...acquisitionInfo, [name]: value });
        }
        acquisitionFieldsValidation({ target: { name, value } }, dispatch);
        emptyAcquisitionErrors(dispatch);
    };

    const handleNext = () => {
        if (!checkAcquisitionFirstStepErrors(acquisitionInfo, dispatch)) {
            next()
        } 
        // else {
        //     doNotify('warning', messages.fillAllRequiredFields, dispatch)
        // }
    }
    const handleSendOtp = async () => {
        await sendOtpApi( acquisitionInfo.mobile ).unwrap().then((payload) => {
            doNotify('success', payload?.data?.message || 'OTP sent successfully', dispatch);
            setIsOtpSent(true);
        }).catch((err) => {
            if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
            doNotify('error', err?.data?.error?.message || 'Failed to send OTP', dispatch);
        });
        };

        const handleValidateOtp = async () => {
            await validateOtpApi({ phoneNumber: acquisitionInfo.mobile, otp }).unwrap().then((payload) => {
                doNotify('success', payload?.data?.message || 'OTP validation successful', dispatch);
                setOtpValidated(true);
            }).catch((err) => {
            if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                doNotify('error', err?.data?.error?.message || 'Failed to validate OTP', dispatch);
            });
        };
        const handleBookedCusSubmit = async () => {
            if (acquisitionInfo?.customerType?.value  === 'Booked Customer') {
                if (!checkAcquisitionError(acquisitionInfo, dispatch)) {
                let AcquisitionData: any = formatAcquisitionRequestBody(acquisitionInfo, bookedCustomer)
                await creatAcquisitionApi(AcquisitionData).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Acquisition form submitted successfully', dispatch)
                    setAcquisitionInfo(acquisitionInitialState)
                    emptyAcquisitionErrors(dispatch)
                    setOtpValidated(false)
                    setOtp('')
                    setIsFormSubmitted(true);
                    localStorage.clear();
                    // window.location.reload();
                    navigate(PATH.ACQUISITION_FORM_MAIN_SUCCESS)
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to submit Acquisition form', dispatch)
                })
            }}
        }
    
    const handleSubmit = async () => {
        if (!checkAcquisitionErrors(acquisitionInfo, dispatch)) {
            let AcquisitionData: any = formatAcquisitionRequestBody(acquisitionInfo, bookedCustomer)
            await creatAcquisitionApi(AcquisitionData).unwrap().then((payload: any) => {
                doNotify('success', payload?.data?.message || 'Acquisition form submitted successfully', dispatch)
                prev()
                setAcquisitionInfo(acquisitionInitialState)
                emptyAcquisitionErrors(dispatch)
                setOtpValidated(false)
                setOtp('')
                setIsFormSubmitted(true);
                localStorage.clear();
                navigate(PATH.ACQUISITION_FORM_MAIN_SUCCESS)
            }).catch((err: any) => {
                if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                doNotify('error', err?.data?.error?.message || 'Failed to submit Acquisition form', dispatch)
            })
        }
    }
    const handleReset = () => {
        localStorage.clear();      
        setAcquisitionInfo(acquisitionInitialState);
        setCustomerType(null);
        setBookedCustomer(false);
        setIsOtpSent(false);
        setOtp("");
        setOtpValidated(false);
        setIsMobileValid(false);
        setIsFormSubmitted(false);      
        emptyAcquisitionErrors(dispatch);
        window.location.reload();
    };

    useEffect(() => {
        if (aquisitionDropdownsApiIsSuccess) {
            const dropdowndata = aquisitionDropdownsData?.data?.data
            setDropDownsData(getAquisitionFormOptionsInfo(dropdowndata))
        }
    }, [aquisitionDropdownsData])
    
    useEffect(() => {
        const storedAcquisitionInfo = localStorage.getItem('acquisitionInfo');
        if (!isFormSubmitted && storedAcquisitionInfo && JSON.parse(storedAcquisitionInfo) !== acquisitionInitialState) {
            setAcquisitionInfo(JSON.parse(storedAcquisitionInfo));
        }
        return () => {
            emptyAcquisitionErrors(dispatch);
            setAcquisitionInfo(acquisitionInitialState);
        };
    }, [isFormSubmitted]);

    const renderStep = () => {
        switch (step) {
            case 1:
                return (
                    <div>
                        <div className="row gy-3">
                        <div className='col-md-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Customer Type*</Form.Label>
                                    <Select
                                        placeholder="Select Customer Type"
                                        isSearchable
                                        options={[
                                            { value: "New", label: "New" },
                                            { value: "Booked Customer", label: "Booked Customer" },
                                        ]}
                                        value={acquisitionInfo.customerType}
                                        onChange={(value) => getSelectInfo(value, "customerType")} // update the customerType field in the acquisitionInfo state object
                                    />
                                </Form.Group>
                            </div>
                            <div className='col-md-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Select Project*</Form.Label>
                                    <Select
                                        placeholder='Select Project'
                                        options={dropDownsData?.projects}
                                        value={acquisitionInfo.project || null}
                                        onChange={(value) => getSelectInfo(value, 'project')}
                                        onBlur={() => doValidateProject(acquisitionInfo.project?.value, dispatch)}
                                        isSearchable
                                    />
                                    <p className='error-msg'>{projectErrorMessage}</p>
                                </Form.Group>
                            </div>

                            <div className='col-md-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>First Name*</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter Full Name"
                                        name="firstName"
                                        value={acquisitionInfo.firstName}
                                        onChange={getAcquisitionInfo}
                                        onBlur={(e) => doValidateFirstName(e.target.value, dispatch)}

                                    />
                                    <p className='error-msg'>{firstNameErrorMessage}</p>
                                </Form.Group>
                            </div>
                            <div className='col-md-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Last Name*</Form.Label>
                                    <Form.Control
                                        type="text"
                                        value={acquisitionInfo.lastName}
                                        placeholder="Enter Full Name"
                                        name="lastName"
                                        onChange={getAcquisitionInfo}
                                        onBlur={(e) => doValidateLatName(e.target.value, dispatch)}
                                    />
                                    <p className='error-msg'>{lastNameErrorMessage}</p>
                                </Form.Group>
                            </div>
                            {acquisitionInfo?.customerType?.value === 'New' && (
                                <>
                                    <div className='col-md-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Area of Current Residence*</Form.Label>
                                            <Form.Control
                                                type="text"
                                                value={acquisitionInfo.areaOfCurrentResident}
                                                placeholder="Enter Area of Current Residence"
                                                name="areaOfCurrentResident"
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidateAreaOfCurrentResident(e.target.value, dispatch)}
                                            />
                                            <p className='error-msg'>{areaOfCurrentResidentErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                </>
                            )}
                            <div className='col-sm-12 col-md-12 col-lg-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Mobile Number*</Form.Label>
                                    <div className="input-group d-block">
                                        <div className="row gy-3">
                                            <div className="col-lg-7 col-md-12 col-sm-12 col-12 d-flex">
                                                <Select
                                                    className='cc-select main-form'
                                                    options={countryCodes.map(country => ({
                                                        value: country.phone,
                                                        label: `${country.label} (+${country.phone})`,
                                                        phoneLength: country.phoneLength
                                                    }))}
                                                    value={acquisitionInfo.countryCode || { code: 'IN', label: 'India', phone: '91', phoneLength: 10 }}
                                                    onChange={(selectedOption) => {
                                                        if (selectedOption) {
                                                            const countryCode = countryCodes.find(country => country.phone === selectedOption.value);
                                                            setAcquisitionInfo({
                                                                ...acquisitionInfo,
                                                                countryCode,
                                                                mobile: ''
                                                            });
                                                            emptyAcquisitionErrors(dispatch)
                                                        }
                                                    }}
                                                    isSearchable
                                                />
                                                <span className="input-group-text phone-input-field">
                                                    {acquisitionInfo.countryCode ? `+${acquisitionInfo.countryCode.phone}` : '+91'}
                                                </span>
                                                <Form.Control
                                                    className='mobile-number'
                                                    type="text"
                                                    value={acquisitionInfo.mobile}
                                                    placeholder="Enter Mobile Number"
                                                    name="mobile"
                                                    onChange={getAcquisitionInfo}
                                                    onBlur={(e) => {
                                                        const isValid = doValidateMobileNumber(e.target.value, dispatch, acquisitionInfo.countryCode);
                                                        setIsMobileValid(isValid);
                                                    }}
                                                />
                                            </div>
    
                                            <div className="col-lg-3 col-md-6 col-sm-12 col-sm-6 col-6 position-relative">
                                                <Form.Control
                                                    type="text"
                                                    placeholder="OTP"
                                                    name="otp"
                                                    value={otp}
                                                    onChange={(e) => setOtp(e.target.value)}
                                                />
                                                <a className="otp-text" onClick={() => handleSendOtp()} style={{ pointerEvents: isMobileValid ? "auto" : "none" }} aria-disabled={!isMobileValid}>
                                                    Send OTP
                                                </a>
                                            </div>
                                            <div className="col-lg-2 col-md-6 col-sm-12 col-sm-6 col-6">
                                                <button className='btn-secondary submit-btn btn h-100 w-100' style={{ minWidth: 'auto' }} disabled={!isOtpSent} onClick={handleValidateOtp}>Verify</button>
                                            </div>
                                            <p className='error-msg mobile-num'>{mobileErrorMessage}</p>
                                        </div>
                                    </div>
                                </Form.Group>
                            </div>
                            <div className='col-sm-12 col-md-12 col-lg-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Alternative Mobile Number</Form.Label>
                                    <div className="input-group d-block">
                                        <div className="row gy-3">
                                            <div className="col-md-12 d-flex">
                                                <Select
                                                    className='cc-select main-form'
                                                    options={countryCodes.map(country => ({
                                                        value: country.phone,
                                                        label: `${country.label} (+${country.phone})`,
                                                        phoneLength: country.phoneLength
                                                    }))}
                                                    value={acquisitionInfo?.alternateCountryCode || { code: 'IN', label: 'India', phone: '91', phoneLength: 10 }}
                                                    onChange={(selectedOption) => {
                                                        if (selectedOption) {
                                                            const alternateCountryCode = countryCodes.find(country => country.phone === selectedOption.value);
                                                            setAcquisitionInfo({
                                                                ...acquisitionInfo,
                                                                alternateCountryCode,
                                                                alternateMobile: ''
                                                            });
                                                            emptyAcquisitionErrors(dispatch);
                                                        }
                                                    }}
                                                    isSearchable
                                                />
                                                <span className="input-group-text phone-input-field">
                                                    {acquisitionInfo.alternateCountryCode ? `+${acquisitionInfo.alternateCountryCode.phone}` : '+91'}
                                                </span>
                                                <Form.Control
                                                    className='mobile-number'
                                                    type="text"
                                                    placeholder="Enter Alternative Mobile Number"
                                                    value={acquisitionInfo.alternateMobile}
                                                    name="alternateMobile"
                                                    onChange={getAcquisitionInfo}
                                                    onBlur={(e) => doValidateAlternateMobileNumber(e.target.value, dispatch, acquisitionInfo.alternateCountryCode)}
                                                />
                                                <p className='error-msg'>{alternateMobileErrorMessage}</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </Form.Group>
                            </div>
                            {acquisitionInfo?.customerType?.value === 'New' && (
                                <>
                                    <div className='col-md-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Email ID</Form.Label>
                                            <Form.Control
                                                type="text"
                                                value={acquisitionInfo.email}
                                                placeholder="e.g John@mail.com"
                                                name="email"
                                                onChange={getAcquisitionInfo}
                                            />
                                            <p className='error-msg'></p>
                                        </Form.Group>
                                    </div>
                                </>
                            )}
                            {acquisitionInfo?.customerType?.value === 'Booked Customer' && (
                                <>
                                    <div className='col-md-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Unit Number*</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="unitNumber"
                                                placeholder="Enter Unit No"
                                                value={acquisitionInfo.unitNumber}
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidateUnitNo(e.target.value, dispatch, true)}
                                            />
                                            <p className='error-msg'>{unitNoErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                    <div className='col-md-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Purpose of Visit*</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="purposeOfVisit"
                                                placeholder='Enter your purpose'
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidatePurposeOfVisit(e.target.value, dispatch)}
                                            />
                                            <p className='error-msg'>{purposeOfVisitErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                </>
                            )}
                            {(acquisitionInfo?.customerType?.value === 'New' || acquisitionInfo?.customerType?.value === 'Booked Customer') && (
                                <>
                                    <div className="col-md-12 select">
                                        <Form.Group className="mb-2 form-group">
                                            <Form.Check
                                                type="checkbox"
                                                label="Other Site FLS"
                                                checked={acquisitionInfo.enableLeadOwner}
                                                onChange={(e) =>
                                                    setAcquisitionInfo({
                                                        ...acquisitionInfo,
                                                        enableLeadOwner: e.target.checked ? 1 : 0
                                                    })
                                                } />
                                        </Form.Group>
                                    </div>
                                    { acquisitionInfo.enableLeadOwner === 1 && (
                                    <div className="col-md-12 select">
                                        <Form.Group className="mb-2 form-group">
                                            <Form.Label>FLS*</Form.Label>
                                            <Select
                                                className="common-input"
                                                placeholder="Select"
                                                options={
                                                    salesDropdownsApiResponse?.data?.fieldEmployees?.fls.map((fls: { email: any }) => ({
                                                        value: fls.email,
                                                        label: fls.email,
                                                    })) || []
                                                }
                                                value={
                                                    acquisitionInfo?.ownerEmail
                                                        ? { value: acquisitionInfo.ownerEmail, label: acquisitionInfo.ownerEmail }
                                                        : null
                                                }
                                                onChange={(value: any) => {
                                                    getSelectInfo(value.value, 'ownerEmail');
                                                }}
                                                isSearchable
                                                onBlur={() => doValidateLeadOwner(acquisitionInfo.ownerEmail, dispatch)}
                                            />
                                            <p className="error-msg">{leadOwnerErrorMessage}</p>
                                        </Form.Group>
                                    </div>)}
                                </>
                            )}
                        </div>
                    </div>
                );
            case 2:
                return (
                    <div className='step-2'>
                        <div className="row gy-3">
                            <div className='col-md-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>No.of Preferred Unit</Form.Label>
                                    <Select
                                        className='common-input'
                                        placeholder="Select No.of Preferred Unit"
                                        options={dropDownsData?.preferredUnits}
                                        value={acquisitionInfo.preferredUnits || null}
                                        onChange={(value) => getSelectInfo(value, 'preferredUnits')}
                                        isSearchable
                                    />
                                    <p className='error-msg'>{preferredUnitsErrorMessage}</p>
                                </Form.Group>
                            </div>
    
                            <div className='col-md-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Preferred Budget Range</Form.Label>
                                    <Select
                                        className='common-input'
                                        placeholder="Select Budget Range"
                                        options={dropDownsData?.budgetRanges}
                                        value={acquisitionInfo.preferredBudgetRange || null}
                                        onChange={(value) => getSelectInfo(value, 'preferredBudgetRange')}
                                        isSearchable
                                    />
                                    <p className='error-msg'>{preferredBudgetRangeErrorMessage}</p>
                                </Form.Group>
                            </div>
    
                            <div className='col-md-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Age Range</Form.Label>
                                    <Select
                                        className='common-input'
                                        placeholder="Select Age Range"
                                        options={dropDownsData?.ageRanges}
                                        value={acquisitionInfo.ageRange || null}
                                        onChange={(value) => getSelectInfo(value, 'ageRange')}
                                        isSearchable
                                    />
                                </Form.Group>
                            </div>
    
                            <div className='col-md-12'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Occupation</Form.Label>
                                    <Select
                                        className='common-input'
                                        placeholder="Select Occupation"
                                        options={dropDownsData?.occupations}
                                        value={acquisitionInfo.occupation || null}
                                        onChange={(value) => getSelectInfo(value, 'occupation')}
                                        isSearchable
                                    />
                                </Form.Group>
                            </div>
    
                            <div className="col-md-12">
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Preferred Size</Form.Label>
                                    <Select
                                        className='common-input'
                                        placeholder="Select Preferred Size"
                                        options={dropDownsData?.sizes}
                                        value={acquisitionInfo.preferredSize || null}
                                        onChange={(value) => getSelectInfo(value, 'preferredSize')}
                                        isSearchable
                                    />
                                </Form.Group>
                            </div>
    
                            <div className="col-md-12">
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Purpose of Purchase</Form.Label>
                                    <Select
                                        className='common-input'
                                        placeholder="Select Purpose of Purchase"
                                        options={dropDownsData?.purposeOfPurchases}
                                        value={acquisitionInfo.purposeOfPurchase || null}
                                        onChange={(value) => getSelectInfo(value, 'purposeOfPurchase')}
                                        isSearchable
                                    />
                                </Form.Group>
                            </div>
    
                            <div className='col-md-12 select'>
                                <Form.Group className='mb-2 form-group'>
                                    <Form.Label>How did you Know about US*</Form.Label>
                                    <Select
                                        className='common-input'
                                        placeholder="Select"
                                        options={dropDownsData?.sourceOfInformations}
                                        value={acquisitionInfo.howDidYouKnowAboutUs || null}
                                        onChange={(value) => getSelectInfo(value, 'howDidYouKnowAboutUs')}
                                        onBlur={() => doValidateHowDidYouKnowAboutUs(acquisitionInfo.howDidYouKnowAboutUs?.value, dispatch)}
                                        isSearchable
                                    />
                                    <p className='error-msg'> {howDidYouKnowAboutUsErrorMessage}</p>
                                </Form.Group>
                            </div>
                            {acquisitionInfo.howDidYouKnowAboutUs?.label === 'Channel Partner' && (
                                <div className='col-md-12'>
                                    <Form.Group className='mb-2 form-group'>
                                        <Form.Label>Channel Partner Name</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="ChannelPartnerName"
                                            name="referredCPName"
                                            value={acquisitionInfo.referredCPName}
                                            onChange={getAcquisitionInfo}
                                        />
                                        <p className='error-msg'></p>
                                    </Form.Group>
                                </div>
                            )}
                            {acquisitionInfo.howDidYouKnowAboutUs?.label === 'Social Media' && (
                                <div className='col-sm-12 col-md-12 col-lg-12'>
                                    <Form.Group className='mb-2 form-group'>
                                        <Form.Label>Social Media*</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="Enter Social Media Name"
                                            name="socialMedia"
                                            value={acquisitionInfo.socialMedia}
                                            onChange={getAcquisitionInfo}
                                            onBlur={(e) => doValidateSocialMedia(e.target.value, dispatch)}
                                        />
                                        <p className='error-msg'>{socialMediaErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            )}
                            {acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred By Friend Or Family' && (
                                <>
                                    <div className='col-sm-12 col-md-12 col-lg-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Referrer Name*</Form.Label>
                                            <Form.Control
                                                type="text"
                                                placeholder="Enter Referrer Name"
                                                name="referredFriendName"
                                                value={acquisitionInfo.referredFriendName}
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidateEmpName(e.target.value, dispatch)}
                                            />
                                            <p className='error-msg'>{empNameErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                    <div className='col-sm-12 col-md-12 col-lg-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Project Name*</Form.Label>
                                            <Form.Control
                                                type="text"
                                                placeholder='Enter Project Name'
                                                name='referredProjectName'
                                                value={acquisitionInfo.referredProjectName}
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidateRefProject(e.target.value, dispatch)}
                                            />
                                            <p className='error-msg'>{refProjectErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                    <div className='col-sm-12 col-md-12 col-lg-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Contact No*</Form.Label>
                                            <div className="input-group d-block">
                                                <div className="row gy-3">
                                                    <div className="col-md-12 d-flex">
                                                        <Select
                                                            className='cc-select main-form'
                                                            options={countryCodes.map(country => ({
                                                                value: country.phone,
                                                                label: `${country.label} (+${country.phone})`,
                                                            }))}
                                                            value={acquisitionInfo.referredCountryCode || { code: 'IN', label: 'India', phone: '91', phoneLength: 10 }}
                                                            onChange={(selectedOption) => {
                                                                if (selectedOption) {
                                                                    const referredCountryCode = countryCodes.find(country => country.phone === selectedOption.value);
                                                                    setAcquisitionInfo({
                                                                        ...acquisitionInfo,
                                                                        referredCountryCode,
                                                                        referredContactNo: ''
                                                                    });
                                                                    emptyAcquisitionErrors(dispatch);
                                                                }
                                                            }}
                                                            isSearchable
                                                        />
                                                        <span className="input-group-text phone-input-field">
                                                            {acquisitionInfo.referredCountryCode ? `+${acquisitionInfo.referredCountryCode.phone}` : '+91'}
                                                        </span>
                                                        <Form.Control
                                                            className='mobile-number'
                                                            type="text"
                                                            placeholder='Enter Contact No'
                                                            name='referredContactNo'
                                                            value={acquisitionInfo.referredContactNo}
                                                            onChange={getAcquisitionInfo}
                                                            onBlur={(e) => doValidateContactNumber(e.target.value, dispatch, acquisitionInfo.referredCountryCode)}
                                                        />
                                                        <p className='error-msg'>{contactErrorMessage}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </Form.Group>
                                    </div>
                                    <div className='col-sm-12 col-md-12 col-lg-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Unit No</Form.Label>
                                            <Form.Control
                                                type="text"
                                                placeholder='Enter Unit No'
                                                name='referredUnitNo'
                                                value={acquisitionInfo.referredUnitNo}
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidateUnitNo(e.target.value, dispatch, false)}
                                            />
                                            <p className='error-msg'>{unitNoErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                </>
                            )}
                            {acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred by an Employee' && (
                                <>
                                    <div className='col-sm-12 col-md-12 col-lg-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Employee Name*</Form.Label>
                                            <Form.Control
                                                type="text"
                                                placeholder="Enter Employee Name"
                                                name="referredEmpName"
                                                value={acquisitionInfo.referredEmpName}
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidateEmpName(e.target.value, dispatch)}
                                            />
                                            <p className='error-msg'>{empNameErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                    <div className='col-sm-12 col-md-12 col-lg-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Department*</Form.Label>
                                            <Form.Control
                                                type="text"
                                                placeholder="Enter Department"
                                                name="referredEmpDept"
                                                value={acquisitionInfo.referredEmpDept}
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidateDepartmentName(e.target.value, dispatch)}
                                            />
                                            <p className='error-msg'>{departmentNameErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                    <div className='col-sm-12 col-md-12 col-lg-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Employee ID</Form.Label>
                                            <Form.Control
                                                type="text"
                                                placeholder="Enter Employee ID"
                                                name="referredEmpId"
                                                value={acquisitionInfo.referredEmpId}
                                                onChange={getAcquisitionInfo}
                                            />
                                        </Form.Group>
                                    </div>
                                </>
                            )}
                            {acquisitionInfo.howDidYouKnowAboutUs?.label === 'Others' && (
                                <div className='col-md-12'>
                                    <Form.Group className='mb-2 form-group'>
                                        <Form.Label>Others</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="Others"
                                            name="otherReferrence"
                                            value={acquisitionInfo.otherReferrence}
                                            onChange={getAcquisitionInfo}
                                        />
                                        <p className='error-msg'></p>
                                    </Form.Group>
                                </div>
                            )}
                            {acquisitionInfo.howDidYouKnowAboutUs?.label === 'Existing Customer' && (
                                <>
                                    <div className='col-sm-12 col-md-12 col-lg-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Project Name</Form.Label>
                                            <Form.Control
                                                type="text"
                                                placeholder='Enter Project Name'
                                                name='existingUserProjectName'
                                                value={acquisitionInfo.existingUserProjectName}
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidateRefProject(e.target.value, dispatch)}
                                            />
                                            <p className='error-msg'>{refProjectErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                    <div className='col-sm-12 col-md-12 col-lg-12'>
                                        <Form.Group className='mb-2 form-group'>
                                            <Form.Label>Unit No</Form.Label>
                                            <Form.Control
                                                type="text"
                                                placeholder='Enter Unit No'
                                                name='existingUserUnitNo'
                                                value={acquisitionInfo.existingUserUnitNo}
                                                onChange={getAcquisitionInfo}
                                                onBlur={(e) => doValidateUnitNo(e.target.value, dispatch, false)}
                                            />
                                            <p className='error-msg'>{unitNoErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                );
            default:
                return null;
        }
    };
    
    const progressBar = () => {
        if (acquisitionInfo?.customerType?.value === "Booked Customer") {
            return null;
        }
        return (
            <ul className='acq-form-progressbar' style={{ display: 'flex', listStyleType: 'none' }}>
                <li className={step >= 1 ? 'active' : ''} style={{ color: step > 1 ? 'green' : 'black' }}><span className='icon'>1</span>First</li>
                <li className={step === 2 ? 'active' : ''} style={{ color: step >= 2 ? 'green' : 'black' }}><span className='icon'>2</span>Last</li>
            </ul>
        );
    };

    return (
        <div>
            <div className='acquisitionFormMain-wrapper'>
                <div className='titleContainer'>
                    <a href='#' className='logo'>
                        <img src={logo} loading="lazy" />
                    </a>
                </div>
                <div className="row justify-content-center">
                    <div className="col-md-10 col-lg-5">
                        <div className='form-container'>
                            <h3>Acquisition Form</h3>
                            <div className='main-progress-bar'>
                            {progressBar()}
                            </div>
                            <div className='inner-form'>
                                <form onSubmit={(e) => { e.preventDefault(); handleSubmit(); }}>
                                    {renderStep()}
                                </form>
                            </div>
                            <div className='footer-btn'>
                            <a className='reset-btn' onClick={handleReset}>Reset</a>
                            {acquisitionInfo?.customerType?.value === 'New' && step === 1 && (
                                <Button type="button" className='btn btn-outline-dark' variant="outline-dark" onClick={handleNext} disabled={!otpValidated}>
                                Next
                                </Button>
                            )}
                            {acquisitionInfo?.customerType?.value  === 'Booked Customer' && step === 1 && (
                                <Button className='submit-btn' disabled={!otpValidated} onClick={handleBookedCusSubmit}>
                                {creatAcquisitionApiIsloading ? <Spinner animation="border" size="sm" /> : 'Submit'}
                                </Button>
                            )}
                            {step === 2 && (
                                <>
                                <Button className='btn btn-outline-dark' variant="outline-dark" onClick={prev}>
                                    Previous
                                </Button>
                                <Button className='submit-btn' disabled={creatAcquisitionApiIsloading} onClick={handleSubmit}>
                                    {creatAcquisitionApiIsloading ? <Spinner animation="border" size="sm" /> : 'Submit'}
                                </Button>
                                </>
                            )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default AcquisitionFormMain;

