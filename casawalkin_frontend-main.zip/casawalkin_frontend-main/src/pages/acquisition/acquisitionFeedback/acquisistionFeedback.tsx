import React, { useState, useEffect } from 'react';
import './acquisitionFeedback.scss';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { useAppDispatch } from '../../../base/hooks/hooks';
import { doNotify } from "../../../utils/utils";
import { useGetAquisitionFormQuestionsQuery, useGetCustomerBasicInfoQuery, useAddReviewMutation, useGetExistingReviewQuery } from '../../../services/apiService/acquisitionForm/acquisitionForm';
import { useLocation, useNavigate } from 'react-router-dom';
import { PATH } from '../../../constants/path';
import { FaStar } from 'react-icons/fa';
import casaLogo from '../../../assets/logo1.svg';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import Spinner from 'react-bootstrap/Spinner';

interface Field {
    maxRating: number;
    id: string;
    type: string;
    label: string;
    options?: string[];
    placeholder?: string;
    active: boolean;
    manditory: boolean;
    answerTypeCode: string
}

const AcquisitionFeedback = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const searchParams = new URLSearchParams(location.search);
    const id = searchParams.get('id') || '';

    const { data: existingReview, isSuccess: existingReviewSuccess, isError: existingReviewError, error: existingReviewErrorData } = useGetExistingReviewQuery({ id });
    const { data: formQuestions, isSuccess: formQuestionsSuccess } = useGetAquisitionFormQuestionsQuery();
    const { data: customerData, isSuccess: customerDataSuccess } = useGetCustomerBasicInfoQuery({ id });
    const [addReview, { isLoading, isSuccess, isError, error }] = useAddReviewMutation();

    const [fields, setFields] = useState<Field[]>([]);
    const [customerInfo, setCustomerInfo] = useState({ name: '', phone: '', email: '' });
    const dispatch = useAppDispatch();

    useEffect(() => {
        if (existingReviewSuccess) {
            if (existingReview?.data?.data) {
                const existingReviewData = existingReview.data.data;
                const activeFields = existingReviewData.reviews.map((review: any) => {
                    if (review.reviewModel) {
                        return {
                            id: review.reviewModel._id,
                            type: review.reviewModel.answerType,
                            label: review.reviewModel.question,
                            options: review.reviewModel.answerOptions?.map((option: any) => option.value),
                            placeholder: 'Enter Your Feedback...',
                            active: review.reviewModel.active,
                            maxRating: review.reviewModel.maxRating,
                            manditory: review.reviewModel.manditory,
                        };
                    }
                    return null;
                }).filter(Boolean);
    
                setFields(activeFields);

                setFormState(prevState => {
                    const newState = { ...prevState };
                    existingReviewData.reviews.forEach((review: any) => {
                        if (review.reviewModel) {
                            const fieldId = review.reviewModel._id;
                            switch (review.answerType) {
                                case 'Single Selection':
                                    newState.singleSelection[fieldId] = review.answer[0]?.key;
                                    break;
                                case 'Multiple Selection':
                                    newState.multipleSelection[fieldId] = review.answer.map((option: any) => option.key);
                                    break;
                                case 'Text Field':
                                    newState.textField[fieldId] = review.answer;
                                    break;
                                case 'Rating':
                                    newState.rating[fieldId] = review.answer;
                                    break;
                                case 'Multiple Selection With Others':
                                    newState.multipleSelection[fieldId] = review.answer.map((option: any) => option.key);
                                    if (review.answer.some((option: { key: string; }) => option.key === 'Others')) {
                                        newState.others[fieldId] = review.answer.find((option: { key: string; }) => option.key === 'Others')?.text || '';
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                    });
                    return newState;
                });
            }
        }

        if (!existingReviewSuccess && formQuestionsSuccess) {
            if (formQuestions?.data?.data) {
                const activeFields = formQuestions.data.data
                    .filter((item: any) => item.active)
                    .map((item: any) => ({
                        id: item._id,
                        type: item.answerType,
                        label: item.question,
                        options: item.answerOptions?.map((option: any) => option.value),
                        placeholder: 'Enter Your Feedback...',
                        active: item.active,
                        maxRating: item.maxRating,
                        manditory: item.manditory
                    }));
                setFields(activeFields);
            }
        }

        if (customerDataSuccess) {
            setCustomerInfo({
                name: customerData?.data?.customer?.name || '',
                phone: customerData?.data?.customer?.phone || '',
                email: customerData?.data?.customer?.email || '',
            });
        }
    }, [existingReviewSuccess, formQuestionsSuccess, customerDataSuccess, formQuestions?.data?.data, customerData?.data?.customer]);

    const [formState, setFormState] = useState({
        textField: {} as { [key: string]: string },
        singleSelection: {} as { [key: string]: string },
        multipleSelection: {} as { [key: string]: string[] },
        rating: {} as { [key: string]: number },
        others: {} as { [key: string]: string },
        errors: {} as { [key: string]: string }
    });

    const handleFieldChange = (id: string, type: string, eventOrOptions: any) => {
        setFormState(prevState => {
            const newState = { ...prevState };
            switch (type) {
                case 'Text Field':
                    newState.textField[id] = eventOrOptions.target.value;
                    if (eventOrOptions.target.value) delete newState.errors[id];
                    else if (fields.find(field => field.id === id)?.manditory) newState.errors[id] = 'This field is required.';
                    break;
                case 'Single Selection':
                    newState.singleSelection[id] = eventOrOptions.target.value;
                    if (eventOrOptions.target.value) delete newState.errors[id];
                    else if (fields.find(field => field.id === id)?.manditory) newState.errors[id] = 'This field is required.';
                    break;
                case 'Multiple Selection':
                case 'Multiple Selection With Others':
                    const { value, checked } = eventOrOptions.target;
                    newState.multipleSelection[id] = checked
                        ? [...(newState.multipleSelection[id] || []).filter(val => val !== value), value]
                        : (newState.multipleSelection[id] || []).filter(val => val !== value);
                    if (newState.multipleSelection[id].length > 0) delete newState.errors[id];
                    else if (fields.find(field => field.id === id)?.manditory) newState.errors[id] = 'This field is required.';
                    break;
                case 'Others':
                    newState.others[id] = eventOrOptions.target.value;
                    break;
                default:
                    break;
            }
            return newState;
        });
    };

    const handleRatingChange = (id: string, ratingValue: number) => {
        setFormState(prevState => {
            const newState = { ...prevState, rating: { ...prevState.rating, [id]: ratingValue } };
            if (ratingValue) delete newState.errors[id];
            else if (fields.find(field => field.id === id)?.manditory) newState.errors[id] = 'This field is required.';
            return newState;
        });
    };

    const handleSubmit = async (event: React.FormEvent) => {
        event.preventDefault();

        const errors: { [key: string]: string } = {};
        fields.forEach(field => {
            if (field.manditory) {
                switch (field.type) {
                    case 'Text Field':
                        if (!formState.textField[field.id]) errors[field.id] = 'Please enter a value for this field.';
                        break;
                    case 'Single Selection':
                        if (!formState.singleSelection[field.id]) errors[field.id] = 'Please choose one option.';
                        break;
                    case 'Multiple Selection':
                    case 'Multiple Selection With Others':
                        if (!formState.multipleSelection[field.id] || formState.multipleSelection[field.id].length === 0) errors[field.id] = 'Please select at least one option';
                        break;
                    case 'Rating':
                        if (!formState.rating[field.id]) errors[field.id] = 'Please provide a rating.';
                        break;
                    default:
                        break;
                }
            }
        });

        if (Object.keys(errors).length > 0) {
            setFormState(prevState => ({ ...prevState, errors }));
            return;
        }

        const reviewData = {
            customer: id,
            name: customerInfo.name,
            phone: customerInfo.phone,
            email: customerInfo.email,
            reviews: fields.map(field => {
                let answer;
    
                if (field.type === 'Multiple Selection With Others') {
                    answer = (formState.multipleSelection[field.id] || []).map(option => ({
                        key: option,
                        value: option,
                        text: option === 'Others' ? formState.others[field.id] : undefined
                    }));
                } else if (field.type === 'Multiple Selection') {
                    answer = (formState.multipleSelection[field.id] || []).map(option => ({
                        key: option,
                        value: option
                    }));
                } else if (field.type === 'Single Selection') {
                    answer = [{ key: formState.singleSelection[field.id], value: formState.singleSelection[field.id] }];
                } else if (field.type === 'Text Field') {
                    answer = formState.textField[field.id] || '';
                } else if (field.type === 'Rating') {
                    answer = formState.rating[field.id] || 0;
                }

                if (!field.manditory && !answer) {
                    answer = field.type === 'Text Field' ? '' : field.type === 'Rating' ? 0 : field.type === 'Single Selection' ? [] : [];
                }
                if (Array.isArray(answer) && answer.length === 1 && Object.keys(answer[0]).length === 0) {
                    answer = [];
                  }                  

                let answerTypeCode = '';
                switch (field.type) {
                    case 'Text Field':
                        answerTypeCode = '101';
                        break;
                    case 'Single Selection':
                        answerTypeCode = '102';
                        break;
                    case 'Multiple Selection':
                        answerTypeCode = '103';
                        break;
                        case 'Multiple Selection With Others':
                            answerTypeCode = '105';
                            break;    
                    case 'Rating':
                        answerTypeCode = '104';
                        break;
                    default:
                        break;
                }

                return {
                    reviewModel: field.id,
                    answerTypeCode: answerTypeCode,
                    answer
                };
            })
        };

        try {
            const payload = await addReview(reviewData).unwrap();
            
            doNotify('success', payload?.data?.message || 'Acquisition-Feedback Submited successfully', dispatch);
            navigate(PATH.CUSTOMER_REVIEW_FORM_SUCCESS);
        } catch (err: any) {
            if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
            doNotify('error', err?.data?.error?.message || 'Failed to Submit Acquisition-Feedback', dispatch)
        }
    };
    const renderField = (field: Field) => {
        const labelWithAsterisk = field.manditory ? `${field.label}*` : field.label;
    
        switch (field.type) {
            case 'Rating':
                return (
                    <Form.Group className='mb-3' key={field.id}>
                        <Form.Label>{labelWithAsterisk}</Form.Label>
                        {field.maxRating === 5 && (
                            <div className="rating-wrapper my-1">
                                <h5 className="rating-title">Rate your experience (5-star):</h5>
                                <div className="stars">
                                    {[...Array(5)].map((_, index) => (
                                        <FaStar
                                            key={index}
                                            size={24}
                                            color={(formState.rating[field.id] || 0) > index ? "#ffc107" : "#e4e5e9"}
                                            onClick={!existingReviewSuccess || !existingReview?.data?.data ? () => handleRatingChange(field.id, index + 1) : undefined}
                                            style={{ cursor: !existingReviewSuccess || !existingReview?.data?.data ? 'pointer' : 'default', marginRight: '5px' }}
                                        />
                                    ))}
                                </div>
                            </div>
                        )}
                        {field.maxRating === 10 && (
                            <div className="rating-wrapper my-1">
                                <h5 className="rating-title">Rate your experience (10-star):</h5>
                                <div className="stars">
                                    {[...Array(10)].map((_, index) => (
                                        <FaStar
                                            key={index}
                                            size={24}
                                            color={(formState.rating[field.id] || 0) > index ? "#ffc107" : "#e4e5e9"}
                                            onClick={!existingReviewSuccess || !existingReview?.data?.data ? () => handleRatingChange(field.id, index + 1) : undefined}
                                            style={{ cursor: !existingReviewSuccess || !existingReview?.data?.data ? 'pointer' : 'default', marginRight: '5px' }}
                                        />
                                    ))}
                                </div>
                            </div>
                        )}
                        <p className='error-msg'>{formState.errors[field.id]}</p>
                    </Form.Group>
                );
                case 'Text Field':
                return (
                    <Form.Group className='mb-3' key={field.id}>
                        <Form.Label>{labelWithAsterisk}</Form.Label>
                        <Form.Control
                            as="textarea"
                            rows={2}
                            value={formState.textField[field.id] || ''}
                            onChange={(event) => handleFieldChange(field.id, field.type, event)}
                            placeholder={field.placeholder}
                            disabled={existingReviewSuccess && existingReview?.data?.data}
                        />
                        <p className='error-msg'>{formState.errors[field.id]}</p>
                    </Form.Group>
                );
            case 'Single Selection':
                return (
                    <Form.Group className='mb-3' key={field.id}>
                        <Form.Label>{labelWithAsterisk}</Form.Label>
                        <div className="row">
                            <div className="col-6">
                                {field.options?.slice(0, Math.ceil(field.options.length / 2)).map(option => (
                                    <Form.Check
                                        key={option}
                                        type="radio"
                                        id={`${field.id}-${option}`}
                                        label={option}
                                        value={option}
                                        checked={formState.singleSelection[field.id] === option}
                                        onChange={(event) => handleFieldChange(field.id, field.type, event)}
                                        disabled={existingReviewSuccess && existingReview?.data?.data}
                                    />
                                ))}
                            </div>
                            <div className="col-6">
                                {field.options?.slice(Math.ceil(field.options.length / 2)).map(option => (
                                    <Form.Check
                                        key={option}
                                        type="radio"
                                        id={`${field.id}-${option}`}
                                        label={option}
                                        value={option}
                                        checked={formState.singleSelection[field.id] === option}
                                        onChange={(event) => handleFieldChange(field.id, field.type, event)}
                                        disabled={existingReviewSuccess && existingReview?.data?.data}
                                    />
                                ))}
                            </div>
                        </div>
                        <p className='error-msg'>{formState.errors[field.id]}</p>
                    </Form.Group>
                );
                case 'Multiple Selection With Others':
                    return (
                        <Form.Group className='mb-3' key={field.id}>
                            <Form.Label>{labelWithAsterisk}</Form.Label>
                            <div className="row">
                                <div className="col-6">
                                    {field.options?.slice(0, Math.ceil(field.options.length / 2)).map(option => (
                                        <Form.Check
                                            key={option}
                                            type="checkbox"
                                            id={`${field.id}-${option}`}
                                            label={option}
                                            value={option}
                                            checked={(formState.multipleSelection[field.id] || []).includes(option)}
                                            onChange={(event) => handleFieldChange(field.id, field.type, event)}
                                            disabled={existingReviewSuccess && existingReview?.data?.data}
                                        />
                                    ))}
                                </div>
                                <div className="col-6">
                                    {field.options?.slice(Math.ceil(field.options.length / 2)).map(option => (
                                        <Form.Check
                                            key={option}
                                            type="checkbox"
                                            id={`${field.id}-${option}`}
                                            label={option}
                                            value={option}
                                            checked={(formState.multipleSelection[field.id] || []).includes(option)}
                                            onChange={(event) => handleFieldChange(field.id, field.type, event)}
                                            disabled={existingReviewSuccess && existingReview?.data?.data}
                                        />
                                    ))}
                                </div>
                            </div>
                            {(formState.multipleSelection[field.id] || []).includes('Others') && (
                                <Form.Group className='mb-3'>
                                    <Form.Label>Specify Others:</Form.Label>
                                    <Form.Control
                                        as="textarea"
                                        rows={2}
                                        value={formState.others[field.id] || ''}
                                        onChange={(event) => handleFieldChange(field.id, 'Others', event)}
                                        placeholder="Enter your feedback..."
                                        disabled={existingReviewSuccess && existingReview?.data?.data}
                                    />
                                </Form.Group>
                            )}
                            <p className='error-msg'>{formState.errors[field.id]}</p>
                        </Form.Group>
                    );
                    
            case 'Multiple Selection':
                return (
                    <Form.Group className='mb-3' key={field.id}>
                        <Form.Label>{labelWithAsterisk}</Form.Label>
                        <div className="row">
                            <div className="col-6">
                                {field.options?.slice(0, Math.ceil(field.options.length / 2)).map(option => (
                                    <Form.Check
                                        key={option}
                                        type="checkbox"
                                        id={`${field.id}-${option}`}
                                        label={option}
                                        value={option}
                                        checked={(formState.multipleSelection[field.id] || []).includes(option)}
                                        onChange={(event) => handleFieldChange(field.id, field.type, event)}
                                        disabled={existingReviewSuccess && existingReview?.data?.data}
                                    />
                                ))}
                            </div>
                            <div className="col-6">
                                {field.options?.slice(Math.ceil(field.options.length / 2)).map(option => (
                                    <Form.Check
                                        key={option}
                                        type="checkbox"
                                        id={`${field.id}-${option}`}
                                        label={option}
                                        value={option}
                                        checked={(formState.multipleSelection[field.id] || []).includes(option)}
                                        onChange={(event) => handleFieldChange(field.id, field.type, event)}
                                        disabled={existingReviewSuccess && existingReview?.data?.data}
                                    />
                                ))}
                            </div>
                        </div>
                        <p className='error-msg'>{formState.errors[field.id]}</p>
                    </Form.Group>
                );
            default:
                return null;
        }
    };
    

    return (
        <div className='feedback-container'>
            <div className='row justify-content-center'>
                <div className='col-md-auto'>
                    <div className='feedback-wrapper'>
                        <div className='feedback-hero'>
                            <div className='d-flex justify-content-end px-4 pt-4'>
                                <img src={casaLogo} alt="" />
                            </div>
                            <div className='px-4 pt-2 customer-review-wrapper'>
                                <h1 className='main-title'>Customer Review</h1>
                                <label className='review-sub-title'>Please help us to improve our product or service by completing this survey. We value you as a customer and would appreciate your feedback.</label>
                                <div className='row'>
                                    <div className='col-md-7'>
                                        <div className='d-flex align-items-center mb-3'>
                                            <label className='hero-label me-3'>Name:</label><span><strong>{customerInfo.name}</strong></span>

                                            {/* <input
                                                className='hero-input form-control'
                                                type="text"
                                                name="name"
                                                value={customerInfo.name}
                                                disabled
                                            /> */}
                                        </div>
                                        <div className='d-flex align-items-center mb-3'>
                                            <label className='hero-label me-3'>Phone:</label><span><strong>{customerInfo.phone}</strong></span>
                                            {/* <input
                                                className='hero-input form-control'
                                                type="text"
                                                name="phone"
                                                value={customerInfo.phone}
                                                disabled
                                            /> */}
                                        </div>
                                        <div className='d-flex align-items-center mb-3'>
                                            <label className='hero-label me-3'>Email:</label><span><strong>{customerInfo.email}</strong></span>
                                            {/* <input
                                                className='hero-input form-control'
                                                type="text"
                                                name="email"
                                                value={customerInfo.email}
                                                disabled
                                            /> */}
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>

                        <div className="row gy-3 p-4 row-main">
                            <Form>
                                {fields.map((field) => (
                                    <React.Fragment key={field.id}>
                                        {renderField(field)}
                                    </React.Fragment>
                                ))}
                                <div className="mt-3 d-flex justify-content-center">
                                    <Button
                                        type="submit"
                                        onClick={handleSubmit}
                                        className='submit-btn btn btn-primary'
                                        disabled={isLoading || (existingReviewSuccess && existingReview?.data?.data)}
                                    >
                                        {isLoading ? <Spinner animation="border" size="sm" /> : 'Submit'}
                                    </Button>
                                </div>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AcquisitionFeedback;
