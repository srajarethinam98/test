import React from 'react'
import './acquisitionFormMainSuccess.scss';
import logo from '../../../assets/cg-logo-nobg.png'
import { useNavigate } from 'react-router-dom'
import { PATH } from '../../../constants/path';


function AcquisitionFormMainSuccess() {
    const navigate = useNavigate()

    const goToPreviousPage = () => {
        navigate(PATH.ACQUISITION_FORM_MAIN)
    }

    return (
        <div>
            <div className='acquisitionFormMain-wrapper'>
                <div className='titleContainer'>
                    <a href='#' className='logo'>
                        <img src={logo} loading="lazy" />
                    </a>
                </div>
                <div className="row justify-content-center">
                    <div className="col-md-10 col-lg-4">
                        <div className='form-container-success'>
                            <div className="wrapper green">
                                <div className="header__wrapper">
                                    <div className="header">
                                        <div className="sign"><span></span></div>
                                    </div>
                                </div>
                                <div className="content">
                                <h1>Congratulations</h1>
                                <p>Thank you for choosing Casa Grand. Your application has been successfully submitted. If you have any questions, please feel free to ask.</p>

                                <button onClick={goToPreviousPage}>Done</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AcquisitionFormMainSuccess