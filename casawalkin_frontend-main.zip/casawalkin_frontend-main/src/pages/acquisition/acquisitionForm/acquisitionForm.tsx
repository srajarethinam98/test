import { useEffect, useState } from 'react'
import { AcquisitionInfoType, acquisitionFieldsValidation, acquisitionInitialState, checkAcquisitionErrors, emptyAcquisitionErrors, formatAcquisitionRequestBody, formatSfRequestBody } from './acquisitionFormController';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify, doValidateAlternateMobileNumber, doValidateFirstName, doValidateHowDidYouKnowAboutUs, doValidateLatName, doValidateMobileNumber, doValidateProject, doValidateEmpName, doValidateContactNumber, doValidateDepartmentName, doValidateRefProject, doValidateSocialMedia, doValidateUnitNo, doValidateAreaOfCurrentResident, doValidatePartnerName, doValidateEmpId, doValidateLeadOwner} from '../../../utils/utils';
import { useAssignFieldDropdownListQuery, useCreateAcquisitionMutation, useEditAcquisitionMutation, useEditAcquisitionSFMutation, useGetAquisitionDropdownsDetailsQuery, useGetSingleCustomerQuery } from '../../../services/apiService/acquisitionForm/acquisitionForm';
import { PATH } from '../../../constants/path';
import { setContactErrorMessage, setEmpIdErrorMessage, setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { checkScreenAccess, filterSalesForceDetails, getAquisitionFormOptionsInfo, getOptionObject, getOptionObjects } from '../../../utils/commonUtils';
import { Accordion, Breadcrumb, Button, Form, Spinner } from 'react-bootstrap';
import Select from 'react-select'
import { useLocation, useParams } from 'react-router';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { sfStatusList } from '../../../constants/dropdowns';
import { useGetProfileQuery } from '../../../services/apiService/profile/profile';
import { AcquisitionAssignInfoType, acquisitionAssignInitialState, checkAcquisitionUpdateFieldsErrors, getAquisitionSFFormOptionsInfo } from '../acquisitionList/aquisitionController';
import { MdOutlineClose, MdOutlineCheck } from "react-icons/md";
import { countryCodes } from '../../common/country';

function AcquisitionForm() {
  const [acquisitionInfo, setAcquisitionInfo] = useState<AcquisitionInfoType>(acquisitionInitialState)
  const [acquisitionAssignInfo, setAcquisitionAssignInfo] = useState<AcquisitionAssignInfoType>(acquisitionAssignInitialState)
  const [enableLeadOwner, setEnableLeadOwner] = useState(false);
  const [dropDownsData, setDropDownsData] = useState<any>({})
  const [sfdropDownData, setSfDropDownData] = useState<any>({})
  const defaultCountryCode = countryCodes.find((code) => code.suggested);
  const [selectedCountryCode, setSelectedCountryCode] = useState(defaultCountryCode || null);
  

  const dispatch = useAppDispatch()
  const navigate = useCustomNavigate()
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const id: any = searchParams.get('id')
  const { type }: any = useParams();

  const { mobileErrorMessage, projectErrorMessage, alternateMobileErrorMessage, preferredUnitsErrorMessage,areaOfCurrentResidentErrorMessage,partnerNameErrorMessage,
    preferredBudgetRangeErrorMessage, howDidYouKnowAboutUsErrorMessage, firstNameErrorMessage,departmentNameErrorMessage,unitNoErrorMessage,empIdErrorMessage,
    lastNameErrorMessage, leadIdErrorMessage, statusErrorMessage, flsTlErrorMessage, empNameErrorMessage, contactErrorMessage, refProjectErrorMessage, socialMediaErrorMessage, leadOwnerErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer)

  const { data: profileResponse, isSuccess: getProfileApiIsSuccess }: any = useGetProfileQuery()

  const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
  const [creatAcquisitionApi, { isLoading: creatAcquisitionApiIsloading }] = useCreateAcquisitionMutation()
  const { data: aquisitionDropdownsData, isSuccess: aquisitionDropdownsApiIsSuccess } = useGetAquisitionDropdownsDetailsQuery()
  const { data: getSingleAquisition, isSuccess: getSingleAquisitionApiIsSuccess, isError: getSingleAquisitionApiIsError, error: getSingleAquisitionApiError }: any = useGetSingleCustomerQuery(id, { skip: !id })
  const { data: salesDropdownsApiResponse, isSuccess: salesDropdownsApiIsSuccess } = useAssignFieldDropdownListQuery({})
  const [editAquisitionApi, { isLoading: editAquisitionApiIsloading }] = useEditAcquisitionMutation()
  const [editAssignApi, { isLoading: editAssignApiIsLoading }] = useEditAcquisitionSFMutation()

  const getAcquisitionInfo = (event: any) => {
    const { name, value }: any = event.target
    if (name === 'leadId' || name === 'notes' || name === 'uniqueLeadId') {
      setAcquisitionAssignInfo({ ...acquisitionAssignInfo, [name]: value })
    }
    else if (name === 'firstName' || name === 'lastName' || name === 'areaOfCurrentResident' || name === 'referredCPName' || name === 'referredFriendName' || name === "referredEmpName" || name === 'referredEmpDept' || name=== "referredEmpId" || name=== "otherReferrence" || name=== 'referredProjectName' || name === 'referredUnitNo' || name === 'referredContactNo' || name === 'socialMedia' || name ==='existingUserProjectName' || name === 'existingUserUnitNo') {
      setAcquisitionInfo({ ...acquisitionInfo, [name]: value })
    } else {
      setAcquisitionInfo({ ...acquisitionInfo, [name]: value.trim() })
    }
    acquisitionFieldsValidation(event, dispatch)
  }

  const getSelectInfo = (selectedOption: any, name: string) => {
    const dropdowndetails = salesDropdownsApiResponse?.data?.fieldEmployees
    if (name === 'ownerEmail') {
      setAcquisitionAssignInfo({
              ...acquisitionAssignInfo,
              ownerEmail: selectedOption
            });
          }
    if (name === 'fls') {
      if (acquisitionAssignInfo?.fls?.value === selectedOption.value) {
        setAcquisitionAssignInfo({
          ...acquisitionAssignInfo, [name]: null,
          svc: null,
          flsTl: '',
          svcTl: ''
        })
      } else {
        let flsObj = filterSalesForceDetails(dropdowndetails?.fls, selectedOption.value)
        setAcquisitionAssignInfo({
          ...acquisitionAssignInfo, [name]: selectedOption,
          svc:flsObj?.svc? { label: flsObj?.svc?.email, value: flsObj?.svc?.email }:null,
          flsTl: flsObj?.flsTl?.email || '',
          svcTl: flsObj?.svcTl?.email || ''
        })
      }
    } else if (name === 'svc') {
      if (acquisitionAssignInfo?.svc?.value === selectedOption.value) {
        setAcquisitionAssignInfo({
          ...acquisitionAssignInfo,
          [name]: null,
          svcTl: ''
        })
      } else {
        let flsObj = filterSalesForceDetails(dropdowndetails?.svc, selectedOption.value)
        setAcquisitionAssignInfo({
          ...acquisitionAssignInfo,
          [name]: selectedOption,
          svcTl: flsObj?.svcTl?.email || ''
        })
      }
    } else if (name === 'leadId' || name === 'status' || name === 'flsTl' || name === 'svcTl' || name === 'notes') {
      setAcquisitionAssignInfo({
        ...acquisitionAssignInfo,
        [name]: selectedOption
      })
    } else {
      setAcquisitionInfo({ ...acquisitionInfo, [name]: selectedOption })
    }
    acquisitionFieldsValidation({ target: { name, value: selectedOption.value } }, dispatch)
    emptyAcquisitionErrors(dispatch)
  }

  const handleSubmit = async () => {
    if (!checkAcquisitionErrors(acquisitionInfo, dispatch)) {
      let acquisitionData: any = formatAcquisitionRequestBody(acquisitionInfo,false)
      if (id) {
        await editAquisitionApi({ acquisitionData, id }).unwrap().then((payload: any) => {
          doNotify('success', payload?.data?.message || 'Acquisition updated successfully', dispatch)
          navigate(PATH.ACQUISITION_LIST)
          handleCancel()
        }).catch((err: any) => {
          if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
          doNotify('error', err?.data?.error?.message || 'Failed to update Acquisition', dispatch)
        })
      } else {
        await creatAcquisitionApi(acquisitionData).unwrap().then((payload: any) => {
          doNotify('success', payload?.data?.message || 'Acquisition form submitted successfully', dispatch)
          navigate(PATH.ACQUISITION_LIST)
          handleCancel()
        }).catch((err: any) => {
          if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
          doNotify('error', err?.data?.error?.message || 'Failed to submit Acquisition form', dispatch)
        })
      }
    }
  }

  // const assignSfTeamHandler = async () => {
  //   let acquisitionAssignData = formatSfRequestBody(acquisitionAssignInfo)
  //   if (!checkAcquisitionUpdateFieldsErrors(acquisitionAssignInfo, dispatch)) {
  //     await editAssignApi({ acquisitionData: acquisitionAssignData, id }).unwrap().then((payload: any) => {
  //       doNotify('success', payload?.data?.message || 'Acquisition updated successfully', dispatch)
  //       navigate(PATH.ACQUISITION_LIST)
  //       handleCancel()
  //     }).catch((err: any) => {
  //       if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
  //       doNotify('error', err?.data?.error?.message || 'Failed to update Acquisition', dispatch)
  //     })
  //   }
  // }

  const handleCancel = () => {
    emptyAcquisitionErrors(dispatch)
    navigate(PATH.ACQUISITION_LIST)
    setAcquisitionInfo(acquisitionInitialState)
    setAcquisitionAssignInfo(acquisitionAssignInitialState)
  }

  useEffect(() => {
    if (salesDropdownsApiIsSuccess) {
      const dropDownData = salesDropdownsApiResponse?.data?.fieldEmployees
      setSfDropDownData(getAquisitionSFFormOptionsInfo(dropDownData))
    }
    if (aquisitionDropdownsApiIsSuccess) {
      const dropDownData = aquisitionDropdownsData?.data?.data
      setDropDownsData(getAquisitionFormOptionsInfo(dropDownData))
    }

  }, [aquisitionDropdownsData, salesDropdownsApiResponse])

  useEffect(() => {
    if (permissionsListApiIsSuccess) {
      checkScreenAccess(permissionsList, SCREEN_CODES.AQUISITION_FORM, navigate)
    }

    if (type === 'edit-acquisition') {
      !id && navigate(PATH.ACQUISITION_LIST)
      if (getSingleAquisitionApiIsError) {
        navigate(PATH.ACQUISITION_LIST)
        doNotify('error', getSingleAquisitionApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
      }
    } else {
      if (getProfileApiIsSuccess && aquisitionDropdownsData) {
        if (!profileResponse?.data?.user?.role?.adminRole) setAcquisitionInfo(
          {
            ...acquisitionInfo,
            project: getOptionObject(dropDownsData?.projects, profileResponse?.data?.user?.project),
          })
      }
    }

    if (getSingleAquisitionApiIsSuccess && aquisitionDropdownsApiIsSuccess && salesDropdownsApiResponse) {
      let aquisitionObj: any = getSingleAquisition?.data?.customer
      setAcquisitionInfo({
        ...acquisitionInfo,
        project: getOptionObject(dropDownsData?.projects, aquisitionObj?.project?.name),
        firstName: aquisitionObj?.firstName,
        lastName: aquisitionObj?.lastName,
        areaOfCurrentResident: aquisitionObj?.currentResidentArea,
        // areaOfCurrentResident: getOptionObject(dropDownsData?.areaOfResidence, aquisitionObj?.currentResidentArea?._id),
        mobile: aquisitionObj?.phoneNumber,
        alternateMobile: aquisitionObj?.alternateNumber,
        email: aquisitionObj?.email,
        preferredUnits: getOptionObject(dropDownsData?.preferredUnits, aquisitionObj?.preferredUnit?._id),
        preferredBudgetRange: getOptionObject(dropDownsData?.budgetRanges, aquisitionObj?.preferredBudgetRange?._id),
        howDidYouKnowAboutUs: getOptionObject(dropDownsData?.sourceOfInformations, aquisitionObj?.sourceOfInformation?._id),
        ageRange: getOptionObject(dropDownsData?.ageRanges, aquisitionObj?.ageRange?._id),
        occupation: getOptionObject(dropDownsData?.occupations, aquisitionObj?.occupation?._id),
        preferredSize: getOptionObject(dropDownsData?.sizes, aquisitionObj?.preferredSize?._id),
        purposeOfPurchase: getOptionObject(dropDownsData?.purposeOfPurchases, aquisitionObj?.purposeOfPurchase?._id),
        socialMedia: aquisitionObj?.socialMedia,
        referredCPName: aquisitionObj?.referredCPName,
        referredEmpName: aquisitionObj?.referredEmpName,
        referredEmpDept: aquisitionObj?.referredEmpDept,
        referredFriendName: aquisitionObj?.referredFriendName,
        referredUnitNo: aquisitionObj?.referredUnitNo,
        referredContactNo : aquisitionObj?.referredContactNo,
        referredProjectName: aquisitionObj?.referredProjectName,
        referredEmpId: aquisitionObj?.referredEmpId,
        otherReferrence: aquisitionObj?.otherReferrence,
        existingUserProjectName: aquisitionObj?.existingUserProjectName,
        existingUserUnitNo: aquisitionObj?.existingUserUnitNo,
        countryCode : getOptionObjects (countryCodes, aquisitionObj?.primaryMobCountryCode),
        alternateCountryCode: getOptionObjects(countryCodes, aquisitionObj?.secondaryMobCountryCode),
        referredCountryCode: getOptionObjects (countryCodes, aquisitionObj?.referredMobCountryCode),
        ownerEmail: aquisitionObj?.ownerEmail || null,
        enableLeadOwner: aquisitionObj?.otherSiteFls

      })
      setAcquisitionAssignInfo({
        ...acquisitionAssignInfo,
        leadId: aquisitionObj?.leadId || '',
        status: getOptionObject(sfStatusList, aquisitionObj?.status),
        fls: aquisitionObj?.salesTeam?.fls,
        flsTl: aquisitionObj?.salesTeam?.flstl,
        svc: aquisitionObj?.salesTeam?.svc,
        svcTl: aquisitionObj?.salesTeam?.svctl,
        notes: aquisitionObj?.remarks,
        uniqueLeadId: aquisitionObj?.uniqueLeadId || ''
      })
    }

    return () => {
      emptyAcquisitionErrors(dispatch)
      setAcquisitionInfo(acquisitionInitialState)
    }
  }, [getSingleAquisition, id, profileResponse, dropDownsData, permissionsList, getSingleAquisitionApiIsError])
  return (
    <>
      <div className='dashboard-wrapper'>
        <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
          <Breadcrumb className='breadcrumb-main'>
            <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
            <Breadcrumb.Item onClick={handleCancel}>
              Acquisition List
            </Breadcrumb.Item>
            <Breadcrumb.Item active>{type === 'edit-acquisition' ? 'Edit Acquisition' : 'Acquisition Form'}</Breadcrumb.Item>
          </Breadcrumb>
        </div>
        <div className="dashboard-card">
          <div className="dashboard-card-body">
            <Form autoComplete="off">
              <Accordion className='assignee-details-accordion mt-2' defaultActiveKey="0">
                <Accordion.Item eventKey="0">
                  <Accordion.Header className='accordion-nocollapse'>Personal Details</Accordion.Header>
                  <Accordion.Body>
                    <div className="row gy-4 mt-2">
                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Select Project*</Form.Label>
                          <Select
                            placeholder='Select Project'
                            options={dropDownsData?.projects}
                            value={acquisitionInfo.project || null}
                            onChange={(value) => getSelectInfo(value, 'project')}
                            onBlur={() => doValidateProject(acquisitionInfo.project?.value, dispatch)}
                            isSearchable
                            isDisabled={!profileResponse?.data?.user?.role?.adminRole}
                          />
                          <p className='error-msg'>{projectErrorMessage}</p>
                        </Form.Group>
                      </div>

                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>First Name*</Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="Enter Full Name"
                            name="firstName"
                            value={acquisitionInfo.firstName}
                            onChange={getAcquisitionInfo}
                            onBlur={(e) => doValidateFirstName(e.target.value, dispatch)}
                          />
                          <p className='error-msg'>{firstNameErrorMessage}</p>
                        </Form.Group>
                      </div>
                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Last Name*</Form.Label>
                          <Form.Control
                            type="text"
                            value={acquisitionInfo.lastName}
                            placeholder="Enter Last Name"
                            name="lastName"
                            onChange={getAcquisitionInfo}
                            onBlur={(e) => doValidateLatName(e.target.value, dispatch)}
                          />
                          <p className='error-msg'>{lastNameErrorMessage}</p>
                        </Form.Group>
                      </div>

                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                        <Form.Label>Area of Current Residence*</Form.Label>
                          <Form.Control
                            type="text"
                            value={acquisitionInfo.areaOfCurrentResident}
                            placeholder="Enter Area of Current Residence"
                            name="areaOfCurrentResident"
                            onChange={getAcquisitionInfo}
                            onBlur={(e) => doValidateAreaOfCurrentResident(e.target.value, dispatch)}

                          // <Form.Label>Area of Current Residence*</Form.Label>
                          // <Select
                          //   placeholder='Select Area of Current Residence'
                          //   options={dropDownsData?.areaOfResidence}
                          //   value={acquisitionInfo?.areaOfCurrentResident || null}
                          //   onChange={(value) => getSelectInfo(value, 'areaOfCurrentResident')}
                          //   onBlur={() => doValidateAreaOfCurrentResident(acquisitionInfo?.areaOfCurrentResident?.value, dispatch)}
                          //   isSearchable
                          />
                          <p className='error-msg'>{areaOfCurrentResidentErrorMessage}</p>
                        </Form.Group>
                      </div>

                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Mobile Number*</Form.Label>
                          <div className="input-group d-block">
                            <div className="row gy-2">
                              <div className="col-md-4 col-lg-4 d-flex">
                              <Select
                              className='cc-select'
                              options={countryCodes.map(country => ({
                                value: country.phone,
                                label: `${country.label} (+${country.phone})`,
                                phoneLength: country.phoneLength
                              }))}
                              value={acquisitionInfo.countryCode || { code: 'IN', label: 'India', phone: '91', phoneLength: 10 }}
                                onChange={(selectedOption) => {
                                if (selectedOption) {
                                  const countryCode = countryCodes.find(country => country.phone === selectedOption.value);
                                  setAcquisitionInfo({
                                    ...acquisitionInfo,
                                    countryCode,
                                    mobile: ''
                                  });
                                  emptyAcquisitionErrors(dispatch)
                                }
                              }}
                              isSearchable
                            />
                              <span className="input-group-text phone-input-field">
                                {acquisitionInfo.countryCode ? `+${acquisitionInfo.countryCode.phone}` : '+91'}
                              </span>
                              </div>
                              <div className="col-md-8 col-lg-8 pl-0">
                              <Form.Control
                              type="text"
                              value={acquisitionInfo.mobile}
                              placeholder="Enter Mobile Number"
                              name="mobile"
                              onChange={getAcquisitionInfo}
                              onBlur={(e) => doValidateMobileNumber(e.target.value, dispatch, acquisitionInfo.countryCode)}
                            />
                              </div>
                            </div>

                            
                          </div>
                          <p className='error-msg'>{mobileErrorMessage}</p>
                        </Form.Group>
                      </div>

                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Alternative Mobile Number</Form.Label>
                          <div className="input-group d-block">
                            <div className="row gy-2">
                              <div className="col-md-4 col-lg-4 d-flex">
                              <Select
                              className='cc-select'
                              options={countryCodes.map(country => ({
                                value: country.phone,
                                label: `${country.label} (+${country.phone})`,
                                phoneLength: country.phoneLength
                              }))}
                              value={acquisitionInfo?.alternateCountryCode || { code: 'IN', label: 'India', phone: '+91', phoneLength: 10 }}
                              onChange={(selectedOption) => {
                                if (selectedOption) {
                                  const alternateCountryCode = countryCodes.find(country => country.phone === selectedOption.value);
                                  setAcquisitionInfo({
                                    ...acquisitionInfo,
                                    alternateCountryCode,
                                    alternateMobile: ''
                                  });
                                  emptyAcquisitionErrors(dispatch);
                                }
                              }}
                              isSearchable
                            />
                              <span className="input-group-text phone-input-field">
                                {acquisitionInfo.alternateCountryCode ? `+${acquisitionInfo.alternateCountryCode.phone}` : '+91'}
                                
                              </span>
                              </div>
                              <div className="col-md-8 col-lg-8 pl-0">
                              <Form.Control
                              type="text"
                              placeholder="Enter Alternative Mobile Number"
                              value={acquisitionInfo.alternateMobile}
                              name="alternateMobile"
                              onChange={getAcquisitionInfo}
                              onBlur={(e) => doValidateAlternateMobileNumber(e.target.value, dispatch, acquisitionInfo.alternateCountryCode)}
                            />
                              </div>
                            </div>
                            
                          </div>
                          <p className='error-msg'>{alternateMobileErrorMessage}</p>
                        </Form.Group>
                      </div>

                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Email ID</Form.Label>
                          <Form.Control
                            type="text"
                            value={acquisitionInfo.email}
                            placeholder="e.g John@mail.com"
                            name="email"
                            onChange={getAcquisitionInfo}
                          />
                          <p className='error-msg'></p>
                        </Form.Group>
                      </div>

                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-goup'>
                          <Form.Label>No.of Preferred Unit</Form.Label>
                          <Select
                            className='common-input'
                            placeholder="Select No.of Preferred Unit"
                            options={dropDownsData?.preferredUnits}
                            value={acquisitionInfo.preferredUnits || null}
                            onChange={(value) => getSelectInfo(value, 'preferredUnits')}
                            isSearchable
                          />
                          <p className='error-msg'>{preferredUnitsErrorMessage}</p>
                        </Form.Group>
                      </div>

                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Preferred Budget Range</Form.Label>
                          <Select
                            className='common-input'
                            placeholder="Select Budget Range"
                            options={dropDownsData?.budgetRanges}
                            value={acquisitionInfo.preferredBudgetRange || ''}
                            onChange={(value) => getSelectInfo(value, 'preferredBudgetRange')}
                            isSearchable
                          />
                          <p className='error-msg'>{preferredBudgetRangeErrorMessage}</p>
                        </Form.Group>
                      </div>

                      

                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Age Range</Form.Label>
                          <Select
                            className='common-input'
                            placeholder="Select Age Range"
                            options={dropDownsData?.ageRanges}
                            value={acquisitionInfo.ageRange || null}
                            onChange={(value) => getSelectInfo(value, 'ageRange')}
                            isSearchable
                          />
                        </Form.Group>
                      </div>

                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Occupation</Form.Label>
                          <Select
                            className='common-input'
                            placeholder="Select Occupation"
                            options={dropDownsData?.occupations}
                            value={acquisitionInfo.occupation || null}
                            onChange={(value) => getSelectInfo(value, 'occupation')}
                            isSearchable
                          />
                        </Form.Group>
                      </div>

                      <div className="col-sm-12 col-md-6 col-lg-4">
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Preferred Size</Form.Label>
                          <Select
                            className='common-input'
                            placeholder="Select Preferred Size"
                            options={dropDownsData?.sizes}
                            value={acquisitionInfo.preferredSize || null}
                            onChange={(value) => getSelectInfo(value, 'preferredSize')}
                            isSearchable
                          />
                        </Form.Group>
                      </div>

                      <div className="col-sm-12 col-md-6 col-lg-4">
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Purpose of Purchase</Form.Label>
                          <Select
                            className='common-input'
                            placeholder="Select Purpose of Purchase"
                            options={dropDownsData?.purposeOfPurchases}
                            value={acquisitionInfo.purposeOfPurchase || null}
                            onChange={(value) => getSelectInfo(value, 'purposeOfPurchase')}
                            isSearchable
                          />
                        </Form.Group>
                      </div>
                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>How did you Know about US*</Form.Label>
                          <Select
                            className='common-input'
                            placeholder="Select"
                            options={dropDownsData?.sourceOfInformations}
                            value={acquisitionInfo.howDidYouKnowAboutUs || null}
                            onChange={(value) => getSelectInfo(value, 'howDidYouKnowAboutUs')}
                            onBlur={() => doValidateHowDidYouKnowAboutUs(acquisitionInfo.howDidYouKnowAboutUs?.value, dispatch)}
                            isSearchable
                          />
                          <p className='error-msg'>{howDidYouKnowAboutUsErrorMessage}</p>
                        </Form.Group>
                      </div>
                      <div>
                      <Form.Group className='mb-2 form-group'>
                        <Form.Check
                          type="checkbox"
                          label="Other Site FLS"
                          checked={acquisitionInfo.enableLeadOwner}
                          onChange={(e) => 
                            setAcquisitionInfo({ 
                              ...acquisitionInfo, 
                              enableLeadOwner:  e.target.checked ? 1 : 0  
                            })
                          } />
                      </Form.Group>
                      </div>
                      { acquisitionInfo.enableLeadOwner === 1 && (
                      <div className="col-sm-12 col-md-6 col-lg-4">
                        <Form.Group className="mb-3">
                          <Form.Label>FLS*</Form.Label>
                          <Select
                            className='common-input'
                            placeholder="Select"
                            options={salesDropdownsApiResponse?.data?.fieldEmployees?.fls.map((fls: { email: any; }) => ({
                              value: fls.email,
                              label: fls.email
                            })) || []}
                            value={acquisitionInfo?.ownerEmail ? { value: acquisitionInfo.ownerEmail, label: acquisitionInfo.ownerEmail } : null}                            onChange={(value: any) => {
                              getSelectInfo(value.value, 'ownerEmail');
                            }}
                            isSearchable
                            onBlur={() => doValidateLeadOwner(acquisitionInfo.ownerEmail, dispatch)}
                          />
                          <p className='error-msg'>{leadOwnerErrorMessage}</p>
                        </Form.Group>
                      </div>)}
                      { acquisitionInfo.howDidYouKnowAboutUs?.label === 'Social Media' && (
                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Social Media*</Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="Enter Social Media Name"
                            name="socialMedia"
                            value={acquisitionInfo.socialMedia}
                            onChange={getAcquisitionInfo}
                            onBlur={(e) => doValidateSocialMedia(e.target.value, dispatch)}
                          />
                          <p className='error-msg'>{socialMediaErrorMessage}</p>
                        </Form.Group>
                      </div>
                      )}
                      { acquisitionInfo.howDidYouKnowAboutUs?.label === 'Channel Partner' && (
                      <div className='col-sm-12 col-md-6 col-lg-4'>
                        <Form.Group className='mb-2 form-group'>
                          <Form.Label>Channel Partner Name</Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="ChannelPartnerName"
                            name="referredCPName"
                            value={acquisitionInfo.referredCPName}
                            onChange={getAcquisitionInfo}
                            onBlur={(e) => doValidatePartnerName(e.target.value, dispatch)}
                          />
                          <p className='error-msg'>{partnerNameErrorMessage}</p>
                        </Form.Group>
                      </div>
                      )}
                          { acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred By Friend Or Family' && (
                            <>
                              <div className='col-sm-12 col-md-6 col-lg-4'>
                                <Form.Group className='mb-2 form-group'>
                                  <Form.Label>Referrer Name*</Form.Label>
                                  <Form.Control
                                    type="text"
                                    placeholder="Enter Referrer Name"
                                    name="referredFriendName"
                                    value={acquisitionInfo.referredFriendName}
                                    onChange={getAcquisitionInfo}
                                    onBlur={(e) => doValidateEmpName(e.target.value, dispatch)}
                                  />
                                  <p className='error-msg'>{empNameErrorMessage}</p>
                                </Form.Group>
                              </div>
                              <div className='col-sm-12 col-md-6 col-lg-4'>
                                <Form.Group className='mb-2 form-group'>
                                  <Form.Label>Project Name*</Form.Label>
                                  <Form.Control
                                    type="text"
                                    placeholder='Enter Project Name'
                                    name='referredProjectName'
                                    value={acquisitionInfo.referredProjectName}
                                    onChange={getAcquisitionInfo}
                                    onBlur={(e) => doValidateRefProject(e.target.value, dispatch)}
                                  />
                                  <p className='error-msg'>{refProjectErrorMessage}</p>
                                </Form.Group>
                              </div>
                              <div className='col-sm-12 col-md-6 col-lg-4'>
                                <Form.Group className='mb-2 form-group'>
                                  <Form.Label>Contact No*</Form.Label>
                                  <div className="input-group d-block">
                                  <div className="row gy-2">
                                  <div className="col-md-4 col-lg-4 d-flex">
                                  <Select
                                      className='cc-select'
                                      options={countryCodes.map(country => ({
                                        value: country.phone,
                                        label: `${country.label} (+${country.phone})`,
                                        // phoneLength: country.phoneLength
                                      }))}
                                      value={acquisitionInfo.referredCountryCode || { code: 'IN', label: 'India', phone: '91', phoneLength: 10 }}
                                      onChange={(selectedOption) => {
                                        if (selectedOption) {
                                          const referredCountryCode = countryCodes.find(country => country.phone === selectedOption.value);
                                          setAcquisitionInfo({
                                            ...acquisitionInfo,
                                            referredCountryCode,
                                            referredContactNo: ''
                                          });
                                          emptyAcquisitionErrors(dispatch);
                                        }
                                      }}
                                      isSearchable
                                    />
                                    <span className="input-group-text phone-input-field">
                                      {acquisitionInfo.referredCountryCode ? `+${acquisitionInfo.referredCountryCode.phone}` : '+91'}
                                      
                                    </span>
                                  </div>
                                  <div className="col-md-8 col-lg-8 pl-0">
                                  <Form.Control
                                      type="text"
                                      placeholder='Enter Contact No'
                                      name='referredContactNo'
                                      value={acquisitionInfo.referredContactNo}
                                      onChange={getAcquisitionInfo}
                                      onBlur={(e) => doValidateContactNumber(e.target.value, dispatch, acquisitionInfo.referredCountryCode)}
                                    />
                                  </div>
                                  </div>
                                    
                                  </div>
                                  <p className='error-msg'>{contactErrorMessage}</p>
                                </Form.Group>
                              </div>
                              <div className='col-sm-12 col-md-6 col-lg-4'>
                                <Form.Group className='mb-2 form-group'>
                                  <Form.Label>Unit No</Form.Label>
                                  <Form.Control
                                    type="text"
                                    placeholder='Enter Unit No'
                                    name='referredUnitNo'
                                    value={acquisitionInfo.referredUnitNo}
                                    onChange={getAcquisitionInfo}
                                    onBlur={(e) => doValidateUnitNo(e.target.value, dispatch, false)}
                                    />
                                    <p className='error-msg'>{unitNoErrorMessage}</p>
                                    </Form.Group>
                              </div>
                            </>
                          )}
                            { acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred by an Employee' && (
                              <>
                            <div className='col-sm-12 col-md-6 col-lg-4'>
                            <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Employee Name*</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter Employee Name"
                                        name="referredEmpName"
                                        value={acquisitionInfo.referredEmpName}
                                        onChange={getAcquisitionInfo}
                                        onBlur={(e) => doValidateEmpName(e.target.value, dispatch)}
                                    />
                                    <p className='error-msg'>{empNameErrorMessage}</p>
                                </Form.Group>
                            </div>
                            <div className='col-sm-12 col-md-6 col-lg-4'>
                              <Form.Group className='mb-2 form-group'>
                                <Form.Label>Department*</Form.Label>
                                <Form.Control
                                  type="text"
                                  placeholder="Enter Department"
                                  name="referredEmpDept"
                                  value={acquisitionInfo.referredEmpDept}
                                  onChange={getAcquisitionInfo}
                                  onBlur={(e)=> doValidateDepartmentName(e.target.value , dispatch)}
                                />
                                <p className='error-msg'>{departmentNameErrorMessage}</p>
                              </Form.Group>
                              </div>
                            <div className='col-sm-12 col-md-6 col-lg-4'>
                            <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Employee ID</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter Employee ID"
                                        name="referredEmpId"
                                        value={acquisitionInfo.referredEmpId}
                                        onChange={getAcquisitionInfo} 
                                        onBlur={(e)=> doValidateEmpId(e.target.value , dispatch)}
                                        />
                                        <p className='error-msg'>{empIdErrorMessage}</p>
                                        </Form.Group>
                            </div></>
                            )}
                            { acquisitionInfo.howDidYouKnowAboutUs?.label === 'Others' && (
                            <div className='col-sm-12 col-md-6 col-lg-4'>
                            <Form.Group className='mb-2 form-group'>
                                    <Form.Label>Others</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Others"
                                        name="otherReferrence"
                                        value={acquisitionInfo.otherReferrence}
                                        onChange={getAcquisitionInfo}          
                                    />
                                    <p className='error-msg'></p>
                                </Form.Group>
                            </div>
                            )}
                            { acquisitionInfo.howDidYouKnowAboutUs?.label === 'Existing Customer' && (
                              <>
                              <div className='col-sm-12 col-md-6 col-lg-4'>
                              <Form.Group className='mb-2 form-group'>
                                <Form.Label>Project Name</Form.Label>
                                <Form.Control
                                  type="text"
                                  placeholder='Enter Project Name'
                                  name='existingUserProjectName'
                                  value={acquisitionInfo.existingUserProjectName}
                                  onChange={getAcquisitionInfo}
                                  onBlur={(e) => doValidateRefProject(e.target.value, dispatch)}
                                />
                                <p className='error-msg'>{refProjectErrorMessage}</p>
                              </Form.Group>
                            </div>
                              <div className='col-sm-12 col-md-6 col-lg-4'>
                              <Form.Group className='mb-2 form-group'>
                                <Form.Label>Unit No</Form.Label>
                                <Form.Control
                                  type="text"
                                  placeholder='Enter Unit No'
                                  name='existingUserUnitNo'
                                  value={acquisitionInfo.existingUserUnitNo}
                                  onChange={getAcquisitionInfo}
                                  onBlur={(e) => doValidateUnitNo(e.target.value, dispatch, false)}
                                />
                                <p className='error-msg'>{unitNoErrorMessage}</p>
                              </Form.Group>
                            </div></>                          
                          )}
                    </div>
                    <div className="row mt-4 mb-3">
                      <div className="col-md-12">
                        <div className='d-flex justify-content-center gap-3 mt-3'>
                          <Button className='close-btn' onClick={handleCancel}>
                            <span><MdOutlineClose /> Cancel</span>
                          </Button>
                          <Button className='submit-btn' onClick={handleSubmit} disabled={creatAcquisitionApiIsloading || editAquisitionApiIsloading}><span>{creatAcquisitionApiIsloading || editAquisitionApiIsloading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                        </div>
                      </div>
                    </div>
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion>

              {/* update

              {id && <><Accordion className='assignee-details-accordion mt-4' defaultActiveKey="0">
                <Accordion.Item eventKey="0">
                  <Accordion.Header>Assignee Details</Accordion.Header>
                  <Accordion.Body>
                    <div className="row p-4 gy-4">
                      <div className="col-sm-12 col-md-6 col-lg-4">
                        <Form.Group className="mb-3 form-group" controlId="userName">
                          <Form.Label>Lead Id*</Form.Label>
                          <Form.Control type="text" placeholder="Enter Lead ID"
                            name='leadId' onChange={getAcquisitionInfo} value={acquisitionAssignInfo.uniqueLeadId} disabled
                            onBlur={(event) => doValidateLeadId(event.target.value, dispatch)}
                          />
                          <p className='error-msg'>{leadIdErrorMessage}</p>
                        </Form.Group>
                      </div>


                      <div className="col-sm-12 col-md-6 col-lg-4">
                        <Form.Group className="mb-3 form-group">
                          <Form.Label>Status*</Form.Label>
                          <Select
                            className='common-input'
                            value={acquisitionAssignInfo?.status}
                            onChange={(option: any) => getSelectInfo(option, 'status')}
                            options={sfStatusList}
                            placeholder="Select Status"
                            isSearchable
                            isDisabled
                            onBlur={(event: any) => doValidateStatus(acquisitionAssignInfo.status?.value, dispatch)}
                          />
                          <p className='error-msg'>{statusErrorMessage}</p>
                        </Form.Group>

                      </div>

                      <div className="col-sm-12 col-md-6 col-lg-4">
                        <Form.Group className="mb-3">
                          <Form.Label>FLS</Form.Label>
                          <Select
                            className='common-input'
                            value={acquisitionAssignInfo?.fls}
                            onChange={(option: any) => getSelectInfo(option, 'fls')}
                            options={sfdropDownData?.fls || []}
                            placeholder="Select FLS"
                            isSearchable
                            isDisabled
                          />
                        </Form.Group>

                      </div>

                      <div className="col-sm-12 col-md-6 col-lg-4">
                        <Form.Group className="mb-3">
                          <Form.Label>FLS TL</Form.Label>
                          <Form.Control type="text" placeholder="Enter Lead ID"
                            name='flsTl' onChange={getAcquisitionInfo} value={acquisitionAssignInfo.flsTl} disabled
                            onBlur={(event) => doValidateLeadId(event.target.value, dispatch)}
                          />
                          <p className='error-msg'>{flsTlErrorMessage}</p>
                        </Form.Group>
                      </div>
                      <div className="col-sm-12 col-md-6 col-lg-4">
                        <Form.Group className="mb-3">
                          <Form.Label>SVC</Form.Label>
                          <Select
                            className='common-input'
                            value={acquisitionAssignInfo?.svc}
                            onChange={(option: any) => getSelectInfo(option, 'svc')}
                            options={sfdropDownData?.svc || []}
                            placeholder="Select SVC"
                            isSearchable
                            isDisabled
                          />
                        </Form.Group>
                      </div>

                      <div className="col-sm-12 col-md-6 col-lg-4">
                        <Form.Group className="mb-3">
                          <Form.Label>SVC TL</Form.Label>
                          <Form.Control type="text" placeholder="Enter Lead ID"
                            name='svcTl' onChange={getAcquisitionInfo} value={acquisitionAssignInfo?.svcTl} disabled
                          />
                        </Form.Group>
                      </div>

                      <div className="col-md-12">
                        <Form.Group className="" controlId="userName">
                          <Form.Label>Remarks</Form.Label>
                          <Form.Control type="text" as="textarea" placeholder="Enter Notes" rows={5}
                            name='notes' onChange={getAcquisitionInfo} value={acquisitionAssignInfo.notes} disabled />
                        </Form.Group>
                      </div>

                    </div>
                    <div className="row mb-3">
                      <div className="col-md-12">
                        <div className='d-flex justify-content-center gap-3 mt-3'>
                          <Button className='close-btn' onClick={handleCancel}>
                            <span><MdOutlineClose /> Cancel</span>
                          </Button>
                          <Button className='submit-btn' disabled={editAssignApiIsLoading} onClick={() => assignSfTeamHandler()}><span>{editAssignApiIsLoading ? <Spinner animation="border" size="sm" /> : <><MdOutlineCheck />Save</>} </span></Button>
                        </div>
                      </div>
                    </div>
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion></>
              } */}
            </Form>
          </div>
        </div>
      </div>
    </>
  )
}

export default AcquisitionForm