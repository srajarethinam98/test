import { setEmailErrorMessage, setAreaOfCurrentResidentErrorMessage, setMobileErrorMessage, setAlternateMobileErrorMessage, setPreferredBudgetErrorMessage, setPreferredUnitsErrorMessage, setHowDidYouKnowAboutUsErrorMessage, setProjectErrorMessage, setLastNameErrorMessage, setFirstNameErrorMessage, setLeadIdErrorMessage, setStatusErrorMessage, setFlsErrorMessage, setFlsTlErrorMessage, setEmpNameErrorMessage, setEmpIdErrorMessage, setContactErrorMessage, setRefProjectErrorMessage, setSocialMediaErrorMessage, setDepartmentNameErrorMessage, setUnitNoErrorMessage, setPurposeOfVisitErrorMessage, setLeadOwnerErrorMessage } from "../../../base/reducer/errorMessageReducer"
import messages from '../../../constants/messageConstants'
import { doValidateEmail, doValidateProject, doValidateAreaOfCurrentResident, doValidateAlternateMobileNumber, doValidatePreferredUnits, doValidateMobileNumber, doValidatePreferredBudgetRange, doValidateHowDidYouKnowAboutUs, doValidateLatName, doValidateFirstName, doValidateEmpName, doValidateDepartmentName,doValidateContactNumber, doValidateRefProject, doValidateSocialMedia, doValidateUnitNo, doValidateEmpId, doValidatePurposeOfVisit, doValidateLeadOwner } from "../../../utils/utils"
import { AcquisitionAssignInfoType } from "../acquisitionList/aquisitionController"

export type AcquisitionInfoType = {
    alternateCountryCode: any
    project: any,
    firstName: any,
    lastName: any,
    areaOfCurrentResident: any,
    mobile: any,
    alternateMobile: any,
    email: any,
    preferredUnits: any,
    preferredBudgetRange: any,
    howDidYouKnowAboutUs: any,
    ageRange: any,
    occupation: any,
    preferredSize: any,
    purposeOfPurchase: any,
    socialMedia:any,
    referredCPName: any,
    referredFriendName: any,
    referredEmpDept: any,
    referredUnitNo: any,
    referredContactNo: any,
    referredEmpName : any,
    referredEmpId : any,
    otherReferrence : any
    referredProjectName : any,
    uniqueLeadId:any,
    existingUserProjectName: any,
    existingUserUnitNo: any,
    countryCode: any,
    referredCountryCode : any,
    bookedCustomer : any,
    unitNumber : any,
    purposeOfVisit : any,
    customerType:any,
    // areaOfResidence: any,
    ownerEmail : any,
    fls: any,
    enableLeadOwner : any
}

export const acquisitionInitialState: AcquisitionInfoType = {
    project: null,
    firstName: null,
    lastName: null,
    areaOfCurrentResident: null,
    mobile: null,
    alternateMobile: null,
    email: null,
    preferredUnits: null,
    preferredBudgetRange: null,
    howDidYouKnowAboutUs: null,
    ageRange: null,
    occupation: null,
    preferredSize: null,
    purposeOfPurchase: null,
    socialMedia:null,
    referredCPName: null,
    referredFriendName: null,
    referredEmpDept: null,
    referredUnitNo: null,
    referredContactNo:null,
    referredEmpName : null,
    referredEmpId : null,
    otherReferrence : null,
    referredProjectName : null,
    uniqueLeadId:null,
    existingUserProjectName: null,
    existingUserUnitNo: null, 
    countryCode:null,
    alternateCountryCode:null,
    referredCountryCode : null,
    bookedCustomer : null,
    unitNumber : null,
    purposeOfVisit: null,
    customerType:null,
    // areaOfResidence: null,
    ownerEmail: null,
    fls: null,
    enableLeadOwner : 0

}

export const acquisitionFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'project':
            value !== '' ? dispatch(setProjectErrorMessage('')) : dispatch(setProjectErrorMessage(`${messages.emptyField} Project`))
            break
        case 'firstName':
            value !== '' ? dispatch(setFirstNameErrorMessage('')) : dispatch(setFirstNameErrorMessage(`${messages.emptyField} First Name`))
            break
        case 'lastName':
            value !== '' ? dispatch(setLastNameErrorMessage('')) : dispatch(setLastNameErrorMessage(`${messages.emptyField} Last Name`))
            break
        // case 'areaOfCurrentResident':
        //     value !== '' ? dispatch(setAreaOfCurrentResidentErrorMessage('')) : dispatch(setAreaOfCurrentResidentErrorMessage(`${messages.emptyField} Area of Current Residence`))
        //     break
        // case 'mobile':
        //     value !== '' ? dispatch(setMobileErrorMessage('')) : dispatch(setMobileErrorMessage(`${messages.emptyField} Mobile Number`))
        //     break
    // case 'alternateMobile':
    //     value !== '' ? dispatch(setAlternateMobileErrorMessage('')) : dispatch(setAlternateMobileErrorMessage(`${messages.emptyField} Alternate Mobile Number`))
    //     break
    // case 'email':
    //     value !== '' ? dispatch(setEmailErrorMessage('')) : dispatch(setEmailErrorMessage(`${messages.emptyField} email`))
    //     break
        case 'preferredUnits':
            value !== '' ? dispatch(setPreferredUnitsErrorMessage('')) : dispatch(setPreferredUnitsErrorMessage(`${messages.emptyField} Preferred Units`))
            break
        case 'preferredBudgetRange':
            value !== '' ? dispatch(setPreferredBudgetErrorMessage('')) : dispatch(setPreferredBudgetErrorMessage(`${messages.emptyField} Preferred Budget Range`))
            break
        case 'howDidYouKnowAboutUs':
            value !== '' ? dispatch(setHowDidYouKnowAboutUsErrorMessage('')) : dispatch(setHowDidYouKnowAboutUsErrorMessage(`${messages.emptyField} How you know`))
            break
        case 'leadId':
            value !== '' ? dispatch(setLeadIdErrorMessage('')) : dispatch(setLeadIdErrorMessage(`${messages.emptyField} Lead Id`))
            break
        case 'status':
            value !== '' ? dispatch(setStatusErrorMessage('')) : dispatch(setStatusErrorMessage(`${messages.select} Status`))
            break
        case 'fls':
            value !== '' ? dispatch(setFlsErrorMessage('')) : dispatch(setFlsErrorMessage(`${messages.select} FLS`))
            break
        case 'flsTl':
            value !== '' ? dispatch(setFlsTlErrorMessage('')) : dispatch(setFlsTlErrorMessage(`${messages.select} FLS TL`));
            break
    }
}

export const formatAcquisitionRequestBody = (acquisitionInfo: AcquisitionInfoType, bookedCustomer:boolean) => {
    return {
        project: acquisitionInfo.project?.value,
        firstName: acquisitionInfo.firstName,
        lastName: acquisitionInfo.lastName || null,
        email: acquisitionInfo.email || null,
        primaryMobCountryCode: acquisitionInfo.countryCode?.phone ? `+${acquisitionInfo.countryCode.phone}`: "+91",
        phoneNumber: acquisitionInfo.mobile,
        secondaryMobCountryCode: acquisitionInfo.alternateMobile ? acquisitionInfo.alternateCountryCode?.phone ? `+${acquisitionInfo.alternateCountryCode.phone}`: "+91" : null,
        alternateNumber: acquisitionInfo.alternateMobile || null,
        currentResidentArea: acquisitionInfo.areaOfCurrentResident || null,
        // currentResidentArea: acquisitionInfo.areaOfCurrentResident?.value || null,
        preferredUnit: acquisitionInfo.preferredUnits?.value || null,
        preferredBudgetRange: acquisitionInfo.preferredBudgetRange?.value || null,
        sourceOfInformation: acquisitionInfo.howDidYouKnowAboutUs?.value,
        ageRange: acquisitionInfo.ageRange?.value || null,
        occupation: acquisitionInfo.occupation?.value || null,
        preferredSize: acquisitionInfo.preferredSize?.value || null,
        purposeOfPurchase: acquisitionInfo.purposeOfPurchase?.value || null,
        socialMedia: acquisitionInfo.howDidYouKnowAboutUs?.label === 'Social Media' ? acquisitionInfo.socialMedia:null,
        referredCPName: acquisitionInfo.howDidYouKnowAboutUs?.label === 'Channel Partner' ? acquisitionInfo.referredCPName: null,

        referredEmpId: acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred by an Employee' ? acquisitionInfo.referredEmpId:null,
        referredEmpName: acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred by an Employee' ? acquisitionInfo.referredEmpName: null,
        referredEmpDept: acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred by an Employee' ? acquisitionInfo.referredEmpDept: null,

        referredFriendName: acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred By Friend Or Family' ? acquisitionInfo.referredFriendName: null,
        referredProjectName: acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred By Friend Or Family' ? acquisitionInfo.referredProjectName: null,
        referredUnitNo: (acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred By Friend Or Family'
            ? (acquisitionInfo.referredUnitNo === '' ? null : acquisitionInfo.referredUnitNo)
            : null),
        referredContactNo: acquisitionInfo.howDidYouKnowAboutUs?.label === 'Referred By Friend Or Family' ? acquisitionInfo.referredContactNo: null,
        referredMobCountryCode: acquisitionInfo.referredContactNo
        ? acquisitionInfo.howDidYouKnowAboutUs?.label === "Referred By Friend Or Family"
          ? `+${acquisitionInfo.referredCountryCode?.phone || "+91"}`
          : null
        : null,
        otherReferrence: acquisitionInfo.howDidYouKnowAboutUs?.label === 'Others' ? acquisitionInfo.otherReferrence : null,
        
        existingUserProjectName : acquisitionInfo.howDidYouKnowAboutUs?.label === 'Existing Customer' ? acquisitionInfo.existingUserProjectName : null,
        existingUserUnitNo : acquisitionInfo.howDidYouKnowAboutUs?.label === 'Existing Customer' ? acquisitionInfo.existingUserUnitNo : null,
        bookedCustomer: bookedCustomer,
        unitNumber: bookedCustomer ? acquisitionInfo?.unitNumber : null,
        purposeOfVisit: bookedCustomer ? acquisitionInfo?.purposeOfVisit : null,
        ownerEmail:  acquisitionInfo?.enableLeadOwner === 1 ? acquisitionInfo?.ownerEmail?.value || acquisitionInfo?.ownerEmail : null,
        otherSiteFls : acquisitionInfo?.enableLeadOwner || 0
    }
}

export const formatSfRequestBody = (acquisitionInfo: AcquisitionAssignInfoType) => {
    return {
        SFLeadId: acquisitionInfo.leadId,
        status: acquisitionInfo.status?.value || null,
        SalesTeamMemberEmail: acquisitionInfo.fls?.value ? acquisitionInfo.fls?.value : acquisitionInfo.svc?.value,
        remarks: acquisitionInfo.notes
    }
    // fls: acquisitionInfo.fls?.value || null,
    // flstl: acquisitionInfo.flsTl || null,
    // svc: acquisitionInfo.svc?.value || null,
    // svctl: acquisitionInfo.svcTl || null,
}

export const checkAcquisitionError = (acquisitionInfo: AcquisitionInfoType, dispatch: any) => {
    doValidateProject(acquisitionInfo.project?.value, dispatch);
    doValidateFirstName(acquisitionInfo.firstName, dispatch);
    doValidateLatName(acquisitionInfo.lastName, dispatch);
    doValidateMobileNumber(acquisitionInfo.mobile, dispatch, acquisitionInfo.countryCode);
    doValidateUnitNo(acquisitionInfo.unitNumber, dispatch, true);
    doValidatePurposeOfVisit(acquisitionInfo.purposeOfVisit, dispatch);

    if (acquisitionInfo.enableLeadOwner) {
        doValidateLeadOwner(acquisitionInfo.ownerEmail, dispatch);
    }

    const isValid = (
        doValidateProject(acquisitionInfo.project?.value, dispatch) &&
        doValidateFirstName(acquisitionInfo.firstName, dispatch) &&
        doValidateLatName(acquisitionInfo.lastName, dispatch) &&
        doValidateMobileNumber(acquisitionInfo.mobile, dispatch, acquisitionInfo.countryCode) &&
        doValidateUnitNo(acquisitionInfo.unitNumber, dispatch, true) &&
        doValidatePurposeOfVisit(acquisitionInfo.purposeOfVisit, dispatch) &&
        (!acquisitionInfo.enableLeadOwner || doValidateLeadOwner(acquisitionInfo.ownerEmail, dispatch))
    );

    return !isValid;
};

export const checkAcquisitionErrors = (acquisitionInfo: AcquisitionInfoType, dispatch: any) => {
    // Validate common fields
    doValidateProject(acquisitionInfo.project?.value, dispatch);
    doValidateFirstName(acquisitionInfo.firstName, dispatch);
    doValidateLatName(acquisitionInfo.lastName, dispatch);
    doValidateMobileNumber(acquisitionInfo.mobile, dispatch, acquisitionInfo.countryCode);
    doValidateHowDidYouKnowAboutUs(acquisitionInfo.howDidYouKnowAboutUs?.value, dispatch);
    doValidateAlternateMobileNumber(acquisitionInfo.alternateMobile, dispatch, acquisitionInfo.alternateCountryCode);
    doValidateAreaOfCurrentResident(acquisitionInfo.areaOfCurrentResident, dispatch);

    if (acquisitionInfo.enableLeadOwner) {
        doValidateLeadOwner(acquisitionInfo.ownerEmail, dispatch);
    }

    switch (acquisitionInfo.howDidYouKnowAboutUs?.label) {
        case 'Social Media':
            doValidateSocialMedia(acquisitionInfo.socialMedia, dispatch);
            break;
        case 'Referred By Friend Or Family':
            doValidateEmpName(acquisitionInfo.referredFriendName, dispatch);
            doValidateRefProject(acquisitionInfo.referredProjectName, dispatch);
            doValidateContactNumber(acquisitionInfo.referredContactNo, dispatch, acquisitionInfo.referredCountryCode);
            doValidateUnitNo(acquisitionInfo.referredUnitNo, dispatch, false);
            break;
        case 'Referred by an Employee':
            doValidateEmpName(acquisitionInfo.referredEmpName, dispatch);
            doValidateDepartmentName(acquisitionInfo.referredEmpDept, dispatch);
            doValidateEmpId(acquisitionInfo.referredEmpId, dispatch);
            break;
        default:
            break;
    }

    const isValid = (
        doValidateProject(acquisitionInfo.project?.value, dispatch) &&
        doValidateFirstName(acquisitionInfo.firstName, dispatch) &&
        doValidateLatName(acquisitionInfo.lastName, dispatch) &&
        doValidateMobileNumber(acquisitionInfo.mobile, dispatch, acquisitionInfo.countryCode) &&
        doValidateHowDidYouKnowAboutUs(acquisitionInfo.howDidYouKnowAboutUs?.value, dispatch) &&
        doValidateAlternateMobileNumber(acquisitionInfo.alternateMobile, dispatch, acquisitionInfo.alternateCountryCode) &&
        doValidateAreaOfCurrentResident(acquisitionInfo.areaOfCurrentResident, dispatch) &&
        (!acquisitionInfo.enableLeadOwner || doValidateLeadOwner(acquisitionInfo.ownerEmail, dispatch)) &&
        (
            acquisitionInfo.howDidYouKnowAboutUs?.label !== 'Social Media' ||
            doValidateSocialMedia(acquisitionInfo.socialMedia, dispatch)
        ) &&
        (
            acquisitionInfo.howDidYouKnowAboutUs?.label !== 'Referred By Friend Or Family' ||
            (
                doValidateEmpName(acquisitionInfo.referredFriendName, dispatch) &&
                doValidateRefProject(acquisitionInfo.referredProjectName, dispatch) &&
                doValidateContactNumber(acquisitionInfo.referredContactNo, dispatch, acquisitionInfo.referredCountryCode) &&
                doValidateUnitNo(acquisitionInfo.referredUnitNo, dispatch, false)
            )
        ) &&
        (
            acquisitionInfo.howDidYouKnowAboutUs?.label !== 'Referred by an Employee' ||
            (
                doValidateEmpName(acquisitionInfo.referredEmpName, dispatch) &&
                doValidateDepartmentName(acquisitionInfo.referredEmpDept, dispatch) &&
                doValidateEmpId(acquisitionInfo.referredEmpId, dispatch)
            )
        )
    );

    return !isValid;
};

export const emptyAcquisitionErrors = (dispatch: any) => {
    dispatch(setProjectErrorMessage(''))
    dispatch(setFirstNameErrorMessage(''));
    dispatch(setLastNameErrorMessage(''));
    dispatch(setAreaOfCurrentResidentErrorMessage(''))
    dispatch(setMobileErrorMessage(''));
    dispatch(setAlternateMobileErrorMessage(''));
    dispatch(setEmailErrorMessage(''))
    dispatch(setPreferredUnitsErrorMessage(''));
    dispatch(setPreferredBudgetErrorMessage(''))
    dispatch(setHowDidYouKnowAboutUsErrorMessage(''));
    dispatch(setSocialMediaErrorMessage(''))
    dispatch(setLeadIdErrorMessage(''))
    dispatch(setStatusErrorMessage(''));
    dispatch(setFlsErrorMessage(''))
    dispatch(setFlsTlErrorMessage(''));
    dispatch(setEmpNameErrorMessage(''))
    dispatch(setEmpIdErrorMessage(''))
    dispatch(setContactErrorMessage(''))
    dispatch(setRefProjectErrorMessage(''))
    dispatch(setDepartmentNameErrorMessage(''))
    dispatch(setUnitNoErrorMessage(''))
    dispatch(setPurposeOfVisitErrorMessage(''))
    dispatch(setLeadOwnerErrorMessage(''))
}