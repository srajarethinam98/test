import { setLeadIdErrorMessage, setStatusErrorMessage, setFlsTlErrorMessage, setFlsErrorMessage, setRemarks, setLeadOwnerErrorMessage } from "../../../base/reducer/errorMessageReducer"
import messages from '../../../constants/messageConstants'
import { convertToSelectOptionsAssign } from "../../../utils/commonUtils"
import { doValidateStatus, doValidateLeadId, doNotify, doValidateRemarks, doValidateLeadOwner, doValidateLeadType } from "../../../utils/utils"

export type AcquisitionAssignInfoType = {
    leadId: string,
    ownerName: string,
    ownerEmail: any,
    ownerProfileName: string,
    status: any,
    fls: any,
    flsTl: string,
    svc: any,
    svcTl: string,
    notes: string,
    leadDetails: any,
    salesTeam: any,
    uniqueLeadId: any,
    svcCount: any,
    adminRole: boolean,
    svStatus: any,
    svLeadId : any,
    svOwner : any,
    otherSiteFls : any,
    adminRemarks: any,
    changeFls: boolean,
    localVisitStatus : any,
    salesCallCount : number,
    svcCallCount : any,
    createdAt: any,
    pushToSalesDate : any

}

export const acquisitionAssignInitialState: AcquisitionAssignInfoType = {
    leadId: '',
    ownerName: '',
    ownerEmail:'',
    ownerProfileName: '',
    status: '',
    fls: null,
    flsTl: '',
    svc: null,
    svcTl: '',
    notes: '',
    salesTeam: '',
    leadDetails:'',
    uniqueLeadId:'',
    svcCount: '',
    adminRole: false,
    svStatus:'',
    svLeadId : null,
    svOwner : null,
    otherSiteFls : '',
    adminRemarks: '',
    changeFls: false,
    localVisitStatus: '',
    salesCallCount: 0,
    svcCallCount: 0,
    createdAt: null,
    pushToSalesDate: ''
}

export const getAquisitionSFFormOptionsInfo = (dropdowndata: any) => {
    return {
        fls: convertToSelectOptionsAssign(dropdowndata?.fls || []),
        svc: convertToSelectOptionsAssign(dropdowndata?.svc || [])
    }
}

export const acquisitionFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'leadId':
            value !== '' ? dispatch(setLeadIdErrorMessage('')) : dispatch(setLeadIdErrorMessage(`${messages.emptyField} Lead Id`))
            break
    }
}

export const checkAcquisitionUpdateFieldsErrors = (AcquisitionInfo: AcquisitionAssignInfoType, isFvsChecked: any, dispatch: any) => {
    // Validate leadId and remarks
    doValidateLeadId(AcquisitionInfo.leadId, dispatch);
    doValidateRemarks(AcquisitionInfo.notes, dispatch);
    doValidateLeadType(AcquisitionInfo.localVisitStatus, dispatch)

    // Validate lead owner only if isFvsChecked is true
    if (isFvsChecked) {
        doValidateLeadOwner(AcquisitionInfo.fls, dispatch);
    }

    // Check if all validations pass
    if (
        doValidateLeadId(AcquisitionInfo.leadId, dispatch) &&
        doValidateStatus(AcquisitionInfo.status?.value, dispatch) &&
        doValidateRemarks(AcquisitionInfo.notes, dispatch) &&
        doValidateLeadType(AcquisitionInfo.localVisitStatus, dispatch) &&
        (!isFvsChecked || doValidateLeadOwner(AcquisitionInfo?.fls || AcquisitionInfo?.ownerEmail , dispatch))
    ) {
        if (AcquisitionInfo.notes) {
            // doNotify('warning', "kindly enter your remarks", dispatch)
            return false
         }
        //   else {
        //      doNotify('warning', "enter your remarks", dispatch)
        //       return true
        //   }
        // return true
    }
    return true
}

export const emptyAcquisitionErrors = (dispatch: any) => {
    dispatch(setLeadIdErrorMessage(''))
    dispatch(setStatusErrorMessage(''));
    dispatch(setFlsErrorMessage(''))
    dispatch(setFlsTlErrorMessage(''));
    dispatch(setRemarks(''))
    dispatch(setLeadOwnerErrorMessage(''))
}