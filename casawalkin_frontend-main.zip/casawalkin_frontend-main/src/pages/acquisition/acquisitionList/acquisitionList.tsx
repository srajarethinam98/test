import { useEffect, useMemo, useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import { useAssignFieldDropdownListQuery, useDeleteAcquisitionMutation, useEditAcquisitionSFMutation, useGetAcquisitionListQuery, useGetSingleCustomerQuery, useUpdateAdminRemarksMutation, useSendWhatsAppFeedbackRequestMutation } from '../../../services/apiService/acquisitionForm/acquisitionForm';
import { doNotify, doValidateLeadId, doValidateStatus, doValidateRemarks, doValidateLeadOwner, doValidateLeadType } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { AcquisitionAssignInfoType, acquisitionFieldsValidation, acquisitionAssignInitialState, checkAcquisitionUpdateFieldsErrors, emptyAcquisitionErrors, getAquisitionSFFormOptionsInfo } from './aquisitionController';
import Select from 'react-select';
import { Form, Button, Spinner, Badge } from 'react-bootstrap';
import { useLocation, useParams } from 'react-router-dom';
import { PATH } from '../../../constants/path';
import { checkScreenAccess, filterSalesForceDetails, getOptionObject } from '../../../utils/commonUtils';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { searchParamsInitialData, searchParamsType, sfStatusList, svStatusList } from '../../../constants/dropdowns';
import Loading from '../../miscellanious/tableLoader/index';
import NoData from '../../miscellanious/noData/index';
import ResponsivePagination from 'react-responsive-pagination';
import { BiSearch } from "react-icons/bi";
import { AiOutlinePlus, AiOutlineEdit, AiOutlineDelete, AiOutlineEye } from "react-icons/ai";
import { useGetProfileQuery } from '../../../services/apiService/profile/profile';
import { RxOpenInNewWindow } from "react-icons/rx";
import moment from 'moment';
import { FaExternalLinkAlt } from "react-icons/fa";
import { config } from '../../../config/index';
import QRCode from 'react-qr-code';
import { toPng } from 'html-to-image';
import DateRangePicker from 'react-bootstrap-daterangepicker';
import 'bootstrap-daterangepicker/daterangepicker.css';
import { BsCalendarDate } from "react-icons/bs";
import { GrPowerReset } from 'react-icons/gr';
import { FaWhatsapp } from "react-icons/fa";

function AcquisitionList() {
    const [currentPage, setCurrentPage] = useState(1);
    const [dropDownData, setDownData] = useState<any>({});
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id');
    const { type }: any = useParams();
    const [show, setShow] = useState(false);
    const [assignInfo, setAssignInfo] = useState<AcquisitionAssignInfoType>(acquisitionAssignInitialState);
    const [apiParams, setApiParams] = useState<searchParamsType>(searchParamsInitialData);
    const [adminRole, setAdminRole] = useState(false);
    const dispatch = useAppDispatch();
    const navigate = useCustomNavigate();
    const [isFvsChecked, setIsFvsChecked] = useState(false);
    const [isSvcChecked, setIsSvcChecked] = useState(false);
    const [otherSiteFls, setIsOtherSiteFls] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [remarks, setRemarks] = useState('');
    const [adminRemarkId, setAdminRemarkId] = useState('');

    const { leadIdErrorMessage, statusErrorMessage, remarksErrorMessage, leadOwnerErrorMessage, leadTypeErrorMessage }: any = useAppSelector((state) => state.ErrorMessageReducer);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const { BASE_URL } = config();
    const modifiedBaseUrl = BASE_URL.replace('/api', '');
    const link = `${modifiedBaseUrl}`;

    const getassignInfo = (event: any) => {
        const { name, value }: any = event.target;
        setAssignInfo({ ...assignInfo, [name]: value });
        acquisitionFieldsValidation(event, dispatch);
    };

    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery();
    const { data: profileData, isSuccess: profileApiSuccess } = useGetProfileQuery();
    const { data: salesDropdownsApiResponse, isSuccess: salesDropdownsApiIsSuccess } = useAssignFieldDropdownListQuery({});
    const { data: acquisitionListData, isFetching: acquisitionListApiIsFetching, isSuccess: acquisitionListApiIsSuccess, refetch } = useGetAcquisitionListQuery(apiParams);
    const { data: singleCustomer, isSuccess: singleCustomerApiIsSuccess, isError: getSingleCustomerApiIsError, error: getSingleCustomerApiError } = useGetSingleCustomerQuery(id, { skip: !id });
    const [editCustomerApi, { isLoading: editCustomerApiIsLoading }] = useEditAcquisitionSFMutation();
    const [deleteCustomerApi] = useDeleteAcquisitionMutation();
    const [adminRemarks] = useUpdateAdminRemarksMutation();
    const [sendWhatsAppFeedbackRequest, { isLoading, isSuccess, isError, error }] = useSendWhatsAppFeedbackRequestMutation();

    const handleSelectChange = (selectedOption: any, name: string,) => {
        const dropdowndetails = salesDropdownsApiResponse?.data?.fieldEmployees;
        if (name === 'localVisitStatus') {
            setAssignInfo({
                    ...assignInfo,
                    localVisitStatus: selectedOption
                  });
                }
              if (name === 'fls') {
            if (assignInfo?.fls?.value === selectedOption.value) {
                setAssignInfo({
                    ...assignInfo, [name]: null,
                    svc: null,
                    flsTl: '',
                    svcTl: ''
                });
            } else {
                let flsObj = filterSalesForceDetails(dropdowndetails?.fls, selectedOption.value);
                console.log(flsObj);
                setAssignInfo({
                    ...assignInfo, [name]: selectedOption,
                    svc: flsObj?.svc ? { label: flsObj?.svc?.email, value: flsObj?.svc?.email } : null,// getSFOptionObject(dropdowndetails?.svc, flsObj?.svc?.email),
                    flsTl: flsObj?.flsTl?.email || '',
                    svcTl: flsObj?.svcTl?.email || ''
                });
            }
        } else if (name === 'svc') {
            if (assignInfo?.svc?.value === selectedOption.value) {
                setAssignInfo({
                    ...assignInfo, [name]: null,
                    svcTl: ''
                });
            } else {
                let svcObj = filterSalesForceDetails(dropdowndetails?.svc, selectedOption.value);
                setAssignInfo({
                    ...assignInfo,
                    [name]: selectedOption,
                    svcTl: svcObj?.svcTl?.email || ''
                });
            }

        } else {
            setAssignInfo({ ...assignInfo, [name]: selectedOption });
            acquisitionFieldsValidation({ target: { name: name, value: selectedOption.value } }, dispatch);
        }
    };

    const doFormArrayOfObject = (apiValue: any) => {
        if (acquisitionListApiIsSuccess) {
            return apiValue?.data?.customers?.map((customerObj: any) => {
                let budget = customerObj?.preferredBudgetRange?.description || '-';
                let fullName = `${customerObj?.firstName || ''} ${customerObj?.lastName || ''}`;
                let ageRange = customerObj?.ageRange?.minAge ? `${customerObj?.ageRange?.minAge} - ${customerObj?.ageRange?.maxAge}` || '-' : null;
                let size = customerObj?.preferredSize?.description || '-';
                return {
                    id: customerObj._id,
                    fullName: fullName,
                    leadId: customerObj?.leadId,
                    email: customerObj?.email,
                    phoneNumber: customerObj?.phoneNumber,
                    alternateNumber: customerObj?.alternateNumber,
                    currentResidentArea: customerObj?.currentResidentArea,
                    projectName: customerObj?.project?.name,
                    budget: budget,
                    occupation: customerObj?.occupation?.occupation,
                    purpose: customerObj?.purposeOfPurchase?.purpose,
                    ageRange: ageRange,
                    assignedTo: customerObj?.assignedTo,
                    size: size,
                    unit: customerObj?.preferredUnit?.varient,
                    source: customerObj?.sourceOfInformation?.source,
                    status: customerObj?.status,
                    createdAt: customerObj?.createdAt,
                    uniqueLeadId: customerObj?.uniqueLeadId,
                    adminRemarks: customerObj?.adminRemarks,
                    changeFls: customerObj?.changeFls
                };
            });
        }
        return [];
    };

    const aquisitionTableList = useMemo(() => doFormArrayOfObject(acquisitionListData), [acquisitionListData]);

    const handleSubmit = async () => {
        if (!checkAcquisitionUpdateFieldsErrors(assignInfo,isFvsChecked, dispatch)) {
            let salesTeamMemberEmail;
            const [emailName, emailDomain] = assignInfo?.ownerEmail?.value?.split('@') || [];

            if (assignInfo.fls?.value) {
                salesTeamMemberEmail = assignInfo.fls.value;
            } else if (assignInfo.ownerEmail?.value && !assignInfo.fls?.value) {
                salesTeamMemberEmail = assignInfo?.ownerEmail?.value;
            }
            if (salesTeamMemberEmail) {
                const emailDomain = salesTeamMemberEmail.split('@')[1];
                if (emailDomain.startsWith('purplstack') || emailDomain.startsWith('test') || emailDomain.startsWith('recovery')) {
                    doNotify('warning', "Please select the valid user.", dispatch);
                    return;
                }
            }
            let acquisitionData: any = {
                SFLeadId: assignInfo.svLeadId ? assignInfo.svLeadId : assignInfo.leadId,
                ownerEmail: salesTeamMemberEmail || '',
                remarks: assignInfo.notes,
                status: assignInfo.status?.value || "",
                svcCount: assignInfo.svcCount,
                changeFls: isFvsChecked,
                otherSiteFls: assignInfo.otherSiteFls,
                localVisitStatus : assignInfo.localVisitStatus.value || assignInfo.localVisitStatus,
                createdAt : assignInfo.createdAt
            };
            // fls: assignInfo.fls?.value,
            // flstl: assignInfo.flsTl,
            // svc: assignInfo.svc?.value,
            // svctl: assignInfo.svcTl,
            await editCustomerApi({ acquisitionData, id }).unwrap().then((payload: any) => {
                doNotify('success', payload?.data?.message || 'Sales team assigned successfully', dispatch);
                navigate(PATH.ACQUISITION_LIST);
                handleCancel();
            }).catch((err: any) => {
                if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                doNotify('error', err?.data?.error?.message || 'Failed to assign Sales team', dispatch);
            });
        }
    };

    const handleCancel = () => {
        navigate(PATH.ACQUISITION_LIST);
        handleClose();
        emptyAcquisitionErrors(dispatch);
        setAssignInfo(acquisitionAssignInitialState);
        setIsFvsChecked(false);
        setIsSvcChecked(false);
    };

    const deleteCustomer = async (id: any) => {
        await deleteCustomerApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'Customer deleted successfully', dispatch);

        }).catch((err: any) => {
            if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
            doNotify('error', err?.data?.error?.message || 'Failed to delete Customer', dispatch);
        });
    };

    const handleCopyLink = (customerId: any) => {
        const copyLink = `${link}/acquisition-feedback?id=${customerId}`;
        navigator.clipboard.writeText(copyLink)
            .then(() => {
                doNotify('alert','Link copied to clipboard!', dispatch);
            })
            .catch(err => {
                console.error('Failed to copy: ', err);
            });
    };

    const handleDownloadQRCode = async (customerId: any) => {
        const node = document.getElementById(`qr-code-${customerId}`);
        if (node) {
            const dataUrl = await toPng(node);
            const link = document.createElement('a');
            link.download = `qr-code-${customerId}.png`;
            link.href = dataUrl;
            link.click();
        }
    };

    const [showQRCodeModal, setShowQRCodeModal] = useState(false);
    const [qrCodeCustomerId, setQRCodeCustomerId] = useState(null);

    const handleShowQRCode = (customerId: any) => {
        setQRCodeCustomerId(customerId);
        setShowQRCodeModal(true);
    };
    const handleWhatsAppReq = async (customerId: any) => {
        try {
            const payload = await sendWhatsAppFeedbackRequest({ id: customerId }).unwrap();
            doNotify('success', payload?.data?.message || 'WhatsApp feedback request sent successfully', dispatch);
        } catch (err: any) {
            if (err?.data?.statusCode === 401) {
                dispatch(setUnAuthorized(true));
            }
            doNotify('error', err?.data?.error?.message || 'Failed to send WhatsApp feedback request', dispatch);
        }
    };

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.AQUISITION_LIST, navigate);
            setAdminRole(profileData?.data?.user?.role?.adminRole);
        }
        if (type === 'acquisition-assign' && id) {
            handleShow();
        }
        if (salesDropdownsApiIsSuccess) {
            const data = salesDropdownsApiResponse?.data?.fieldEmployees;
            setDownData(getAquisitionSFFormOptionsInfo(data));
        }
        if (singleCustomerApiIsSuccess) {
            const customer = singleCustomer?.data?.customer;
            const dropdowndetails = salesDropdownsApiResponse?.data?.fieldEmployees;
            setAssignInfo({
                ...assignInfo,
                leadId: customer?.leadId || '',
                status: getOptionObject(sfStatusList, customer?.status),
                ownerName: customer?.ownerName || '',
                ownerEmail: customer?.ownerEmail ? { label: customer?.ownerEmail, value: customer?.ownerEmail } : '',
                ownerProfileName: customer?.ownerProfileName || '',
                fls: customer?.salesTeam?.fls,
                flsTl: customer?.salesTeam?.flstl?.value,
                svc: customer?.salesTeam?.svc,
                svcTl: customer?.salesTeam?.svctl?.value,
                notes: customer?.remarks,
                uniqueLeadId : customer?.uniqueLeadId,
                svcCount: customer?.svcCount || 0,
                svStatus: customer?.svStatus,
                svLeadId : customer?.svLeadId,
                svOwner : customer?.svOwner,
                otherSiteFls : customer?.otherSiteFls || 0,
                adminRemarks: customer?.adminRemarks,
                salesCallCount : customer?.salesCallCount || 0,
                svcCallCount: customer?.svcCallCount || 0,
                localVisitStatus : customer?.localVisitStatus || '',
                createdAt : customer?.createdAt || null,
                pushToSalesDate: customer?.pushToSalesDate || ''
            });
        } else if (getSingleCustomerApiIsError) {
            navigate(PATH.ACQUISITION_LIST);
            handleCancel();
        }
    }, [salesDropdownsApiResponse, id, singleCustomer, permissionsList, getSingleCustomerApiError, profileData?.data?.user?.role?.adminRole, apiParams, permissionsListApiIsSuccess, type, salesDropdownsApiIsSuccess, singleCustomerApiIsSuccess, getSingleCustomerApiIsError]);

    // Separate useEffect for refetching the acquisition list
    useEffect(() => {
        refetch();
    }, [apiParams, refetch]);

    const handleEditRemarks = (adminRemarks: any, id: any) => {
        setShowModal(true);
        setRemarks(adminRemarks);
        setAdminRemarkId(id)
    };
    const handleSaveRemark = async () => {
            try {
                const result = await adminRemarks({
                    adminRemarkId,
                    adminRemarks: remarks
                }).unwrap();

                doNotify('success', result?.data?.message || 'Remarks updated successfully', dispatch);
                setShowModal(false);
                refetch();
            } catch (error: any) {
                if (error?.status === 401) dispatch(setUnAuthorized(true));
                doNotify('error', error?.data?.error?.message || 'Failed to update remarks', dispatch);
        }
    };

    const handleDateRangePickerEvent = (event: any, picker: any) => {
        setApiParams({
            ...apiParams,
            startDate: picker.startDate.format('YYYY-MM-DD'),
            endDate: picker.endDate.format('YYYY-MM-DD'),
            selectedStartDate: picker.startDate,
            selectedEndDate: picker.endDate,
        });
    };

    const handleSelectSvStatus = (selectedOption: any) => {
        setApiParams({
            ...apiParams,
            svStatus: selectedOption.value
        });
    };

    const handleSearchTypeChange = (selectedOption: any) => {
        setApiParams(prevParams => ({
            ...prevParams,
            searchType: selectedOption.value,
            searchString: selectedOption.value === 'fls' ? '' : prevParams.searchString,
            fls: selectedOption.value === 'customer' ? '' : prevParams.fls
        }));
    };

    const handleReset = () => {
            setApiParams(searchParamsInitialData);
            refetch();
        };
        const formatDate = (dateString: string) => {
            if (!dateString || isNaN(new Date(dateString).getTime())) {
                return "-";
            }
            const date = new Date(dateString);
            return `${date.getUTCDate()}/${date.getUTCMonth() + 1}/${date.getUTCFullYear()} ${date.toLocaleTimeString('en-US', { hour12: true, hour: '2-digit', minute: '2-digit', timeZone: 'UTC' })}`;
        };
                                
    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header row mb-1'>
                    <div className='d-flex align-items-center gap-3 col-md-auto'>
                        <h5 className='page-title'>Acquisition List <Badge bg="success">{!acquisitionListApiIsFetching ? acquisitionListData?.data?.totalCount || 0 : <Spinner size="sm" />}</Badge></h5>

                    </div>
                    <div className="col-md-2 col-sm-12 search-type">
                        <Form.Group className='datepicker-form'>
                            <Select
                                key={apiParams.searchType}
                                className='common-input'
                                value={[{ label: 'FLS Search', value: 'fls' }, { label: 'Customer Search', value: 'customer' }].find(option => option.value === apiParams.searchType)}
                                onChange={handleSearchTypeChange}
                                options={[{ label: 'FLS Search', value: 'fls' }, { label: 'Customer Search', value: 'customer' }]}
                                placeholder="Select Search Type"
                                isSearchable
                            />
                        </Form.Group>
                    </div>
                    <div className="col-md-2 search-input">
                        <Form.Group controlId="userName">
                            <Form.Control
                                type="text"
                                name="name"
                                value={apiParams.searchString}
                                onChange={(event) => setApiParams({ ...apiParams, searchString: event.target.value })}
                                placeholder={ apiParams.searchType === "fls" ? "Search Fls.." : "Search Customer.." }
                            />
                        </Form.Group>
                        <BiSearch className="search-icon" />
                    </div>

                    <div className="col-md-2 col-sm-12">
                        <Form.Group className='datepicker-form'>
                            <DateRangePicker
                                initialSettings={{ startDate: apiParams.selectedStartDate, endDate: apiParams.selectedEndDate }}
                                onApply={handleDateRangePickerEvent}
                            >
                                <button>{apiParams?.startDate ? `${apiParams?.startDate}  -  ${apiParams?.endDate}` : 'Choose Date Range'}</button>
                            </DateRangePicker>
                            <BsCalendarDate className='calendar-icon' />
                        </Form.Group>
                    </div>

                    <div className="col-md-2 col-sm-12">
                        <Form.Group className='datepicker-form'>
                            <Select
                                key={apiParams.svStatus}
                                className='common-input'
                                value={svStatusList.find((option: { value: string; }) => option.value === apiParams.svStatus)}
                                onChange={handleSelectSvStatus}
                                options={svStatusList.filter((option: { value: string; }) => ['Scheduled', 'Not Scheduled', 'Revisit'].includes(option.value))}
                                placeholder="Select SV Status"
                                isSearchable
                            />
                        </Form.Group>
                    </div>
                    <div className="col-md-auto">
                    <Button className='btn btn-secondary' style={{ minWidth: 'auto' }} onClick={handleReset}><span><GrPowerReset /></span></Button>
                    </div>
                    <div className="col-md-1 p-0">
                    <Button className='add-btn' style={{ minWidth: 'auto', width: '100%' }} onClick={() => navigate(PATH.ACQUISITION_FORM)}><span><AiOutlinePlus /> Add</span></Button>
                    </div>

                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <div className="table-responsive">
                            <table className="table text-nowrap">
                            <thead>
                                <tr>
                                    <th scope="col" style={{ width: "80px" }}>
                                    S.No
                                    </th>
                                    <th scope="col">Assign Sales</th>
                                    {adminRole && <th scope="col">Existing Lead</th>}
                                    <th scope="col">Name</th>
                                    <th scope="col">Lead ID</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Phone Number</th>
                                    <th scope="col">Sec Phone Number</th>
                                    <th scope="col">Address</th>
                                    <th scope="col">Project Name</th>
                                    <th scope="col">Created At</th>
                                    <th scope="col">Budget</th>
                                    <th scope="col">Occupation</th>
                                    <th scope="col">Purpose</th>
                                    <th scope="col">Age</th>
                                    <th scope="col">Assigned To</th>
                                    <th scope="col">Size</th>
                                    <th scope="col">Unit</th>
                                    <th scope="col">How did i know</th>
                                    <th>Customer Review</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Remarks</th>
                                    <th scope="col">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                    {
                                        !acquisitionListApiIsFetching ? acquisitionListApiIsSuccess ? acquisitionListData?.data?.customers?.length > 0 ?
                                            aquisitionTableList?.map((customerObj: any, index: any) => {
                                                let id = customerObj?._id;
                                                return (
                                                    <tr key={index}>

                                                        <td>{index + 1 + (apiParams.currentPage - 1) * acquisitionListData?.data?.limit}</td>
                                                        <td>
                                                            <a
                                                                className="assign-btn"
                                                                onClick={() => {
                                                                    navigate(`/acquisition/acquisition-list/acquisition-assign/?id=${customerObj?.id}`);
                                                                    handleShow();
                                                                }}
                                                                style={{
                                                                    cursor: 'pointer',
                                                                    // color: customerObj?.changeFls ? '#ccc' : '#007bff',
                                                                    // pointerEvents: customerObj?.changeFls ? 'none' : 'auto'
                                                                }}
                                                            >
                                                                <AiOutlineEdit style={{ marginRight: '5px' }} />
                                                                Assign
                                                            </a>
                                                        </td>
                                                        {adminRole && (
                                                            <td><a className='assign-btn' onClick={() => navigate(`/existing-lead/?id=${customerObj?.id}`)} style={{ padding: '0px', background: '#fff' }}>
                                                            <RxOpenInNewWindow /> Existing Lead
                                                            </a></td>
                                                        )}
                                                        <td>{customerObj?.fullName || '-'}</td>
                                                        <td>{customerObj?.uniqueLeadId || '-'}</td>
                                                        <td>{customerObj?.email || '-'}</td>
                                                        <td>{customerObj?.phoneNumber || '-'}</td>
                                                        <td>{customerObj?.alternateNumber || '-'}</td>
                                                        <td>{customerObj?.currentResidentArea || '-'}</td>
                                                        {/* <td>{customerObj?.currentResidentArea?.areaName || '-'}</td> */}
                                                        <td>{customerObj?.projectName || '-'}</td>
                                                        <td>{customerObj?.createdAt || '-'}</td>
                                                        <td>{customerObj?.budget || '-'}</td>
                                                        <td>{customerObj?.occupation || '-'}</td>
                                                        <td>{customerObj?.purpose || '-'}</td>
                                                        <td>{customerObj?.ageRange || '-'}</td>
                                                        <td>{customerObj?.assignedTo || '-'}</td>
                                                        <td>{customerObj?.size}</td>
                                                        <td>{customerObj?.unit}</td>
                                                        <td>{customerObj?.source}</td>
                                                        <td>
                                                            <div>
                                                                <a
                                                                    className='assign-btn mb-2'
                                                                    onClick={() => window.open(`/acquisition-feedback?id=${customerObj?.id}`, '_blank')}
                                                                >
                                                                    <AiOutlineEye /> View Review
                                                                </a>
                                                                <a
                                                                    className='assign-btn mb-2'
                                                                    onClick={() => handleCopyLink(customerObj?.id)} // Pass customer ID on click
                                                                    style={{ cursor: 'pointer' }}
                                                                >
                                                                    <FaExternalLinkAlt /> Copy Link
                                                                </a>
                                                                <a
                                                                    className='assign-btn mb-2'
                                                                    onClick={() => handleShowQRCode(customerObj?.id)} // Pass customer ID on click
                                                                    style={{ cursor: 'pointer' }}
                                                                >
                                                                    <FaExternalLinkAlt /> Show QR Code
                                                                </a>
                                                                <a
                                                                    className='assign-btn mb-2'
                                                                    onClick={() => handleWhatsAppReq(customerObj?.id)}
                                                                    style={{ cursor: 'pointer' }}
                                                                >
                                                                    <FaWhatsapp /> Notice
                                                                </a>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className='status-col'>
                                                                <span className={customerObj?.status === 'Booked' ? 'completed' : ''}> {customerObj?.status} </span>
                                                            </div>
                                                        </td>
                                                        <td onClick={() => handleEditRemarks(customerObj?.adminRemarks, customerObj?.id)} className='remarks' style={{ cursor: 'pointer' }}>
                                                            <a className="edit" style={{ marginLeft: '1px' }}>
                                                            {customerObj?.adminRemarks}
                                                                <i className="edit" title='Edit'><AiOutlineEdit /></i>
                                                            </a>
                                                        </td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                            {(adminRole || moment(customerObj?.createdAt, "D/M/YYYY, h:mm:ss a").format("D/M/YY") === moment(new Date()).format('D/M/YY')) && (
                                                                    <a
                                                                        className='edit'
                                                                        title='Edit'
                                                                        onClick={() => {
                                                                            navigate(`/acquisition/edit-acquisition/?id=${customerObj?.id}`);
                                                                        }}
                                                                    >
                                                                        <AiOutlineEdit />
                                                                    </a>
                                                                )}
                                                                {adminRole && (
                                                                    <a
                                                                        className='delete'
                                                                        title='Delete'
                                                                        onClick={() => deleteCustomer(customerObj?.id)}
                                                                    >
                                                                        <AiOutlineDelete />
                                                                    </a>
                                                                )}
                                                            </div>
                                                        </td>
                                                    </tr>

                                                );
                                            }) : <NoData /> : <>Api error</> : <Loading />
                                    }
                                </tbody>
                            </table>
                        </div>
                        <div className='export-data-footer'>
                            <ResponsivePagination
                                current={apiParams.currentPage}
                                total={acquisitionListData?.data?.totalPages || 1}
                                maxWidth={7}
                                onPageChange={(page: any) => setApiParams({ ...apiParams, currentPage: page })}
                            />
                        </div>
                    </div>
                </div>
            </div>

            <Modal
                show={show}
                onHide={handleCancel}
                backdrop="static"
                keyboard={false}
                size="lg"
            >
                <Modal.Header closeButton>
                    <Modal.Title>Assign Sales Team</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form autoComplete="off">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-3">
                                        <Form.Group className="mb-3 mt-2" controlId="userName">
                                            <Form.Check
                                                type="checkbox"
                                                label="Change FLS"
                                                checked={isFvsChecked}
                                                onChange={() => { setIsFvsChecked(!isFvsChecked);
                                                                emptyAcquisitionErrors(dispatch);
                                                }}
                                            />
                                        </Form.Group>
                                    </div>
                                    <div className="col-md-3">
                                        <Form.Group className="mb-3 mt-2" controlId="userName">
                                            <Form.Check
                                                type="checkbox"
                                                label="SVC Count"
                                                checked={assignInfo.svcCount === 1}
                                                onChange={() => {
                                                    setAssignInfo({
                                                        ...assignInfo,
                                                        svcCount: assignInfo.svcCount === 1 ? 0 : 1
                                                    });
                                                    setIsSvcChecked(assignInfo.svcCount === 1 ? false : true);
                                                }}
                                            />
                                        </Form.Group>
                                    </div>
                                    <div className="col-md-3">
                                        <Form.Group className="mb-3 mt-2" controlId="userName">
                                            <Form.Check
                                                type="checkbox"
                                                label="Other Site FLS"
                                                checked={assignInfo?.otherSiteFls === 1}
                                                onChange={() => {
                                                    setAssignInfo({
                                                        ...assignInfo,
                                                        otherSiteFls: assignInfo.otherSiteFls === 1 ? 0 : 1
                                                    });
                                                    setIsOtherSiteFls(assignInfo.otherSiteFls === 1 ? false : true);
                                                }}
                                            />
                                        </Form.Group>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-3">
                                        <div className="mb-3 mt-2 count-wrapper">
                                            <label>Sales call count:</label> <span>{assignInfo.salesCallCount}</span>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="mb-3 mt-2 count-wrapper">
                                            <label>SVC call count:</label> <span>{assignInfo.svcCallCount}</span>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="mb-3 mt-2 count-wrapper">
                                            <label>Push To Sales Date:</label> <span>{formatDate(assignInfo.pushToSalesDate)}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <Form.Group className="mb-3" controlId="userName">
                                    <Form.Label>Lead Id</Form.Label>
                                    <Form.Control type="text" placeholder="Enter Lead ID"
                                        name='leadId' onChange={getassignInfo} value={assignInfo?.uniqueLeadId} disabled
                                        onBlur={(event) => doValidateLeadId(event.target.value, dispatch)}
                                    />
                                    <p className='error-msg'>{leadIdErrorMessage}</p>
                                </Form.Group>
                            </div>

                            <div className="col-md-6">
                                <Form.Group className="mb-3">
                                    <Form.Label>Status</Form.Label>
                                    <Select
                                        className='common-input'
                                        value={assignInfo?.status}
                                        onChange={(option: any) => handleSelectChange(option, 'status')}
                                        options={sfStatusList}
                                        placeholder="Select Status"
                                        isSearchable
                                        onBlur={(event: any) => doValidateStatus(assignInfo.status?.value, dispatch)}
                                        isDisabled
                                    />
                                    <p className='error-msg'>{statusErrorMessage}</p>
                                </Form.Group>

                            </div>
                            <div className="col-md-6">
                    <Form.Group className="mb-3">
                        <Form.Label>Type*</Form.Label>
                        <Select
                            className='common-input'
                            value={assignInfo.localVisitStatus ? { value: assignInfo.localVisitStatus, label: assignInfo.localVisitStatus } : null}
                            onChange={(option: any) => handleSelectChange(option.value, 'localVisitStatus')}
                            options={[
                                { value: 'Walk In', label: 'Walk In' },
                                { value: 'Scheduled', label: 'Scheduled' },
                                { value: 'Revisit', label: 'Revisit' }
                            ]}
                            onBlur={() => {
                                doValidateLeadType(assignInfo.localVisitStatus , dispatch);
                            }}
                            placeholder="Select Type"
                            isSearchable
                        />
                        <p className='error-msg'>{leadTypeErrorMessage}</p>
                    </Form.Group>
                </div>

                            <div className="col-md-6">
                                <Form.Group className="mb-3">
                                    <Form.Label>Lead Owner*</Form.Label>
                                    <Select
                                        className='leadOwner*'
                                        value={assignInfo?.fls?.value ? { value: assignInfo?.fls?.value, label: assignInfo?.fls?.label } : assignInfo?.ownerEmail ?? null}

                                        onChange={(option: any) => {
                                            if (assignInfo?.ownerEmail && !assignInfo?.fls?.value) {
                                                handleSelectChange(option, 'ownerEmail');
                                            } else if (assignInfo?.fls?.value) {
                                                handleSelectChange(option, 'fls');
                                            } else if (assignInfo?.ownerEmail && assignInfo?.fls?.value) {
                                                handleSelectChange(option, 'fls');
                                            }
                                            else {
                                                handleSelectChange(option, 'fls');
                                            }
                                        }}
                                        onBlur={() => {
                                            doValidateLeadOwner(assignInfo?.fls ?? assignInfo?.ownerEmail, dispatch);
                                        }}
                                        options={dropDownData?.fls || []}
                                        placeholder="Select Lead Owner"
                                        isSearchable
                                        isDisabled={!isFvsChecked}
                                        getOptionLabel={(option) => option.label}
                                        getOptionValue={(option) => option.value}
                                    />
                                    <p className='error-msg'>{leadOwnerErrorMessage}</p>
                                </Form.Group>
                            </div>
                            <div className="col-md-6">
                                <Form.Group className="mb-3" controlId="userName">
                                    <Form.Label>Lead Owner Profile</Form.Label>
                                    <Form.Control type="text" placeholder="Enter Owner Profile"
                                        name='leadOwnerProfil' onChange={getassignInfo} value={assignInfo?.ownerProfileName}
                                        disabled
                                    />
                                    <p className='error-msg'></p>
                                </Form.Group>
                            </div>
                            {singleCustomer?.data?.customer?.salesTeam?.fls === null && singleCustomer?.data?.customer?.salesTeam?.svc === null && singleCustomer?.data?.customer?.salesTeam?.flstl === null && singleCustomer?.data?.customer?.salesTeam?.svctl === null && (
                                <div className="col-md-12">
                                    <Form.Group className="mb-3" controlId="userName">
                                        <Form.Label>Remarks*</Form.Label>
                                        <Form.Control type="text" as="textarea" placeholder="Enter Notes"
                                            name='notes' onChange={getassignInfo} value={assignInfo.notes}
                                            onBlur={() => doValidateRemarks(assignInfo?.notes, dispatch)}
                                        />
                                        <p className='error-msg'>{remarksErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            )}
                            <div className="col-md-12">
                                <Form.Group className="mb-3" controlId="userName">
                                    <Form.Label>Notes</Form.Label>
                                    <Form.Control type="text" as="textarea"
                                        name='notes' 
                                        disabled
                                    />
                                </Form.Group>
                            </div>
                        </div>
                        {(singleCustomer?.data?.customer?.salesTeam?.fls !== null || singleCustomer?.data?.customer?.salesTeam?.svc !== null || singleCustomer?.data?.customer?.salesTeam?.flstl !== null || singleCustomer?.data?.customer?.salesTeam?.svctl !== null) && (
                            <>
                                <div className="row">

                                    <div className="col-md-6">
                                        <Form.Group className="mb-3">
                                            <Form.Label>SVC Tagged</Form.Label>
                                            <Select
                                                className='common-input'
                                                value={assignInfo?.svc}
                                                onChange={(option: any) => handleSelectChange(option, 'svc')}
                                                options={dropDownData?.svc || []}
                                                placeholder="Select SVC Tagged"
                                                isSearchable
                                                isDisabled={true}
                                            />
                                        </Form.Group>

                                    </div>

                                    <div className="col-md-6">
                                        <Form.Group className="mb-3">
                                            <Form.Label>SVC TL</Form.Label>
                                            <Form.Control type="text" placeholder="Enter SVC TL"
                                                name='svcTl' onChange={getassignInfo} value={assignInfo?.svcTl}
                                                disabled
                                            />
                                        </Form.Group>

                                    </div>

                                    {/* <div className="col-md-6">
                                        <Form.Group className="mb-3">
                                            <Form.Label>FLS</Form.Label>
                                            <Select
                                                className='common-input'
                                                value={assignInfo?.fls}
                                                onChange={(option: any) => handleSelectChange(option, 'fls')}
                                                options={dropDownData?.fls || []}
                                                placeholder="Select FLS"
                                                isSearchable
                                                isDisabled={!isFvsChecked}
                                            />
                                        </Form.Group>

                                    </div> */}

                                    <div className="col-md-6">
                                        <Form.Group className="mb-3">
                                            <Form.Label>FLS TL</Form.Label>
                                            <Form.Control type="text" placeholder="Enter FLS TL"
                                                name='flsTl' onChange={getassignInfo} value={assignInfo.flsTl}
                                                disabled={true}
                                            />
                                        </Form.Group>

                                    </div>
                                    <div className="col-md-6">
                                        <Form.Group className="mb-3">
                                            <Form.Label>Remarks*</Form.Label>
                                            <Form.Control type="text" placeholder="Enter Notes"
                                                name='notes' onChange={getassignInfo} value={assignInfo?.notes}
                                                onBlur={() => doValidateRemarks(assignInfo?.notes, dispatch)}
                                            />
                                            <p className='error-msg'>{remarksErrorMessage}</p>
                                        </Form.Group>
                                    </div>
                                </div>

                                <div className="row">

                                </div></>
                            )}
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button className='close-btn' onClick={handleCancel}>
                        Close
                    </Button>
                    <Button className='submit-btn' disabled={editCustomerApiIsLoading} onClick={handleSubmit}>{editCustomerApiIsLoading ? <Spinner animation="border" size="sm" /> : 'Submit'}</Button>
                </Modal.Footer>
            </Modal>

            <Modal className='qr-modal-container'
                show={showQRCodeModal}
                onHide={() => setShowQRCodeModal(false)}
                backdrop="static"
                keyboard={false}
                size="lg"
            >
                <Modal.Header closeButton>
                    <Modal.Title>QR Code</Modal.Title>
                </Modal.Header>
                <Modal.Body className='mx-auto my-0 qr-modal'>
                    <h2 className='text-center'>Scan QR Code</h2>
                    <p className='mb-0'>Scan the image below to preview your review</p>
                    <div id={`qr-code-${qrCodeCustomerId}`} className='text-center border py-5 my-2'>
                        <QRCode value={`${link}/acquisition-feedback?id=${qrCodeCustomerId}`} />
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button className='qr-download-btn' onClick={() => handleDownloadQRCode(qrCodeCustomerId)}>Download QR Code</Button>
                    <Button className='qr-close-btn' onClick={() => setShowQRCodeModal(false)}>Close</Button>
                </Modal.Footer>
            </Modal>
            {/* Modal for editing the adminRemarks */}
            <Modal show={showModal} onHide={() => setShowModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit Remarks</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        <Form.Group>
                            <Form.Label>Remarks</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter Remarks"
                                name='adminRemarks'
                                value={remarks}
                                onChange={(e) => setRemarks(e.target.value)}
                            />
                        </Form.Group>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowModal(false)}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={() => handleSaveRemark()}>
                        Save Changes
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default AcquisitionList;
