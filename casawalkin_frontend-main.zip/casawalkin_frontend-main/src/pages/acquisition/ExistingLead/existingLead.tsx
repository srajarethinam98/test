import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { useGetCustomerDuplicatesQuery } from "../../../services/apiService/acquisitionForm/acquisitionForm";
import { Form, Spinner, Badge } from "react-bootstrap";
import { BiSearch } from "react-icons/bi";

interface DataItem {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    countryCode: string;
    mobile: string;
    secondaryCountryCode: string;
    secondaryMobileNo: string | null;
    ownerProfileName: string;
    ownerName: string;
    sfLeadId: string;
}

function ExistingLead() {
    const [data, setData] = useState<DataItem[]>([]);
    const [loading, setLoading] = useState(true);
    const location = useLocation();
    const id = new URLSearchParams(location.search).get("id");
    const {
        data: getCustomerDuplicates,
        isSuccess: getCustomerDuplicatesSuccess,
    } = useGetCustomerDuplicatesQuery({ id });

    useEffect(() => {
        if (getCustomerDuplicatesSuccess) {
            setData(getCustomerDuplicates.data.data);
            setLoading(false);
        }
    }, [getCustomerDuplicates, getCustomerDuplicatesSuccess]);

    if (loading) {
        return (
            <Spinner animation="border" role="status">
                <span className="visually-hidden">Loading...</span>
            </Spinner>
        );
    }

    return (
        <div>
            <div className="dashboard-wrapper">
                <div className="header d-flex w-100 justify-content-between align-items-center mb-3">
                    <div className="d-flex align-items-center gap-3">
                        <h5 className="page-title">
                            Existing Lead List <Badge bg="success">{data.length}</Badge>
                        </h5>
                        {/* <div className="col-md-6 search-input">
                            <Form.Group controlId="userName">
                                <Form.Control
                                    type="text"
                                    name="name"
                                    placeholder="Search Customer.."
                                />
                            </Form.Group>
                            <BiSearch className="search-icon" />
                        </div> */}
                    </div>
                    {/* <Button className='add-btn mx-3'><span><AiOutlinePlus /> Add</span></Button> */}
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <div className="table-responsive">
                            {data.length > 0 ? (
                                <table className="table text-nowrap">
                                    <thead>
                                        <tr>
                                            <th scope="col" style={{ width: "80px", textAlign: "left" }}>
                                                S.No
                                            </th>
                                            <th scope="col"  style={{textAlign: "left"}}>First Name</th>
                                            <th scope="col" style={{textAlign: "left"}}>Last Name</th>
                                            <th scope="col" style={{textAlign: "left"}}>Lead ID</th>
                                            <th scope="col" style={{textAlign: "left"}}>Email</th>
                                            <th scope="col" style={{textAlign: "left"}}>Phone Number</th>
                                            <th scope="col" style={{textAlign: "left"}}>Secondary Phone Number</th>
                                            <th scope="col" style={{textAlign: "left"}}>Owner Profile Name</th>
                                            <th scope="col" style={{textAlign: "left"}}>Owner Name</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {data.map((item, index) => (
                                            <tr key={index}>
                                                <td>{index + 1}</td>
                                                <td>{item.firstName}</td>
                                                <td>{item.lastName}</td>
                                                <td>{item.sfLeadId}</td>
                                                <td>{item.email}</td>
                                                <td>{item.mobile}</td>
                                                <td>
                                                    {item.secondaryMobileNo
                                                        ? item.secondaryCountryCode + item.secondaryMobileNo
                                                        : 'N/A'}
                                                </td>
                                                <td>{item.ownerProfileName}</td>
                                                <td>{item.ownerName}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            ) : (
                                <p>No existing leads found.</p>
                            )}
                        </div>
                        <div className="export-data-footer"></div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ExistingLead;
