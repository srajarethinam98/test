import { useEffect } from 'react'
import { Button } from 'react-bootstrap'
import { useAppDispatch, useCustomNavigate } from '../../../base/hooks/hooks';
import { doNotify } from '../../../utils/utils';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { useGetBudgetListQuery, useDeleteBudgetMutation } from '../../../services/apiService/budget/budgetRange';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { PATH } from '../../../constants/path';
import Loading from '../../miscellanious/tableLoader/index'
import NoData from '../../miscellanious/noData/index'
import { AiOutlinePlus,AiOutlineEdit ,AiOutlineDelete} from "react-icons/ai";

function PreferredBudgetRangeList() {
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()

    const [deleteBudgetApi] = useDeleteBudgetMutation()
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()
    const { data: budgetListData, isLoading: budgetListApiIsLoading, isSuccess: budgetListApiIsSuccess } = useGetBudgetListQuery()
    
    const deletebudget = async (id: any) => {
        await deleteBudgetApi(id).unwrap().then((payload: any) => {
            doNotify('success', payload?.data?.message || 'Budget deleted successfully', dispatch)
        }).catch((err: any) => {
            if (err?.data?.statusCode===401) {
                dispatch(setUnAuthorized(true))
            }
            doNotify('error', err?.data?.error?.message || 'Failed to delete Budget', dispatch)
        })
    } 

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.PREFERRED_BUDGET, navigate)
        }
    }, [permissionsList])

    return (
        <>
            <div className="dashboard-wrapper">
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Preferred Budget Range List</h5>
                    <Button className='add-btn mx-3' onClick={()=>navigate(PATH.PREFERRED_BUDGET_RANGE_ADD)}><span><AiOutlinePlus /> Create Budget Range</span></Button>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style={{ textAlign: 'left' }}>S.No</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Budget Range</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Label</th>
                                        <th scope="col" style={{ textAlign: 'left' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        !budgetListApiIsLoading ? budgetListApiIsSuccess ?budgetListData?.data?.budgetRanges?.length>0?
                                            budgetListData?.data?.budgetRanges?.map((budgetObj: any, index: any) => {
                                                let id = budgetObj?._id
                                                let budgetRange = `${budgetObj?.minBudget} - ${budgetObj?.maxBudget}`
                                                return (
                                                    <tr key={index}>

                                                        <td>{index + 1}</td>
                                                        <td>{budgetRange || '-'}</td>
                                                        <td>{budgetObj?.description || '-'}</td>
                                                        <td>
                                                            <div className='action-col d-flex gap-2'>
                                                                <a className='edit' title='Edit' onClick={() => {
                                                                    navigate(`/budget/edit-budget/?id=${id}`)
                                                                }}><AiOutlineEdit /></a>
                                                                <a className='delete' title='Delete' onClick={() => deletebudget(id)}><AiOutlineDelete /></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }):<NoData/> : <>Api error</> : <Loading/>
                                        }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default PreferredBudgetRangeList