import messages from '../../../constants/messageConstants'
import {  setLabelErrorMessage, setMaxBudgetErrorMessage, setMinBudgetErrorMessage } from "../../../base/reducer/errorMessageReducer"
import {  doValidateMaxBudget, doValidateMinBudget, doValidateLabel } from "../../../utils/utils"

export type preferredBudgetInfoType = {
    minBudget: string,
    maxBudget: string,
    description: string,
}

export const preferredBudgetInitialState: preferredBudgetInfoType = {
    minBudget: '',
    maxBudget: '',
    description: '',
}

export const preferredBudgetFieldsValidation = (event: any, dispatch: any) => {
    const { name, value } = event.target
    switch (name) {
        case 'minBudget':
            value !== '' ? dispatch(setMinBudgetErrorMessage('')) : dispatch(setMinBudgetErrorMessage(`${messages.emptyField} Min Budget`))
            break
        case 'maxBudget':
            value !== '' ? dispatch(setMaxBudgetErrorMessage('')) : dispatch(setMaxBudgetErrorMessage(`${messages.emptyField} Max Budget`))
            break
        case 'description':
            value !== '' ? dispatch(setLabelErrorMessage('')) : dispatch(setLabelErrorMessage(`${messages.emptyField} Label`))
            break    
    }
}

export const checkPreferredBudgetsFieldsErrors = (preferredBudgetInfo: preferredBudgetInfoType, dispatch: any) => {
    doValidateMinBudget((preferredBudgetInfo.minBudget), dispatch)
    doValidateMaxBudget((preferredBudgetInfo.maxBudget),preferredBudgetInfo.minBudget, dispatch)
    doValidateLabel((preferredBudgetInfo.description), dispatch, true)

    if (doValidateMinBudget((preferredBudgetInfo.minBudget), dispatch) && doValidateLabel((preferredBudgetInfo.description), dispatch, true) &&
    doValidateMaxBudget((preferredBudgetInfo.maxBudget),preferredBudgetInfo.minBudget, dispatch) 
    ) {
        return false
    }
    return true
}

export const emptyPreferredBudgetFieldsErrors = (dispatch: any) => {
    dispatch(setMinBudgetErrorMessage(''))
    dispatch(setMaxBudgetErrorMessage(''))
    dispatch(setLabelErrorMessage(''))
}