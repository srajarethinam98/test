import { useEffect, useState } from 'react'
import { preferredBudgetInfoType, preferredBudgetInitialState, checkPreferredBudgetsFieldsErrors, emptyPreferredBudgetFieldsErrors, preferredBudgetFieldsValidation } from './preferredBudgetController';
import { doNotify, doValidateMaxBudget, doValidateMinBudget, doValidateLabel } from '../../../utils/utils';
import { useAppDispatch, useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import { setUnAuthorized } from '../../../base/reducer/errorMessageReducer';
import { Form, Button, Breadcrumb, Spinner } from 'react-bootstrap';
import { useCreateBudgetMutation, useEditBudgetMutation, useGetSingleBudgetQuery } from '../../../services/apiService/budget/budgetRange';
import { PATH } from '../../../constants/path';
import { useLocation, useParams } from 'react-router-dom';
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { SCREEN_CODES } from '../../../constants/screensConstants';
import { checkScreenAccess } from '../../../utils/commonUtils';
import { MdOutlineClose ,MdOutlineCheck} from "react-icons/md";

function PreferredBudgetRangeAdd() {
    const [preferredBudgetInfo, setPreferredBudgetInfo] = useState<preferredBudgetInfoType>(preferredBudgetInitialState)
    const dispatch = useAppDispatch()
    const navigate = useCustomNavigate()
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const id: any = searchParams.get('id')
    const { type }: any = useParams();

    const { minbudgetErrorMessage, maxbudgetErrorMessage, labelErrorMessage } = useAppSelector((state) => state.ErrorMessageReducer)

    const [creatpreferredBudgetsApi, { isLoading: creatpreferredBudgetApiIsloading }] = useCreateBudgetMutation()
    const [editpreferredBudgetsApi, { isLoading: editpreferredBudgetApiIsloading }] = useEditBudgetMutation()
    const { data: getSinglepreferredBudget, isSuccess: getSinglepreferredBudgetApiIsSuccess, isError: getSinglepreferredBudgetApiIsError, error: getSinglepreferredBudgetApiError }: any = useGetSingleBudgetQuery(id, { skip: !id })
    const { data: permissionsList, isSuccess: permissionsListApiIsSuccess } = useGetRolePermissionsQuery()

    const getpreferredBudgetInfo = (event: any) => {
        const { name, value }: any = event.target
        setPreferredBudgetInfo({ ...preferredBudgetInfo, [name]: value })//.trim()
        preferredBudgetFieldsValidation(event, dispatch)
    }

    const handleSubmit = async () => {
        if (!checkPreferredBudgetsFieldsErrors(preferredBudgetInfo, dispatch)) {
            let body: any = {
                minBudget: preferredBudgetInfo.minBudget,
                maxBudget: preferredBudgetInfo.maxBudget,
                description: preferredBudgetInfo.description,
            }
            if (id) {
                await editpreferredBudgetsApi({ id, body }).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Preferred Budget updated successfully', dispatch)
                    navigate(PATH.PREFERRED_BUDGET_RANGE_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || 'Failed to update Preferred Budget', dispatch)
                })
            } else {
                await creatpreferredBudgetsApi(body).unwrap().then((payload: any) => {
                    doNotify('success', payload?.data?.message || 'Preferred Budget created successfully', dispatch)
                    navigate(PATH.PREFERRED_BUDGET_RANGE_LIST)
                    handleCancel()
                }).catch((err: any) => {
                    if (err?.data?.statusCode === 401) dispatch(setUnAuthorized(true));
                    doNotify('error', err?.data?.error?.message || err?.data?.error?.message || 'Failed to create Preferred Budget', dispatch)
                })
            }
        }
    }

    useEffect(() => {
        if (permissionsListApiIsSuccess) {
            checkScreenAccess(permissionsList, SCREEN_CODES.PREFERRED_BUDGET, navigate)
        }
        if (type === 'edit-budget') {
            !id && navigate(PATH.PREFERRED_BUDGET_RANGE_LIST)
            if (getSinglepreferredBudgetApiIsError) {
                navigate(PATH.PREFERRED_BUDGET_RANGE_LIST)
                doNotify('error', getSinglepreferredBudgetApiError?.data?.error?.message || 'Failed to get Acquisition', dispatch)
            }
        }
        if (getSinglepreferredBudgetApiIsSuccess) {
            let preferredBudgetObj: any = getSinglepreferredBudget?.data?.budgetRange
            setPreferredBudgetInfo({
                ...preferredBudgetInfo,
                minBudget: preferredBudgetObj?.minBudget,
                maxBudget: preferredBudgetObj?.maxBudget,
                description: preferredBudgetObj?.description
            })
        }
        return () => {
            emptyPreferredBudgetFieldsErrors(dispatch)
            setPreferredBudgetInfo(preferredBudgetInitialState)
        }
    }, [getSinglepreferredBudget, id, permissionsList, getSinglepreferredBudgetApiIsError])

    const handleCancel = () => {
        emptyPreferredBudgetFieldsErrors(dispatch)
        navigate(PATH.PREFERRED_BUDGET_RANGE_LIST)
        setPreferredBudgetInfo(preferredBudgetInitialState)
    }

    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <Breadcrumb className='breadcrumb-main'>
                        <Breadcrumb.Item onClick={() => navigate(PATH.DASHBOARD)}>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item onClick={handleCancel}>
                            Preferred Budget Range List
                        </Breadcrumb.Item>
                        <Breadcrumb.Item active>{type === 'add-budget' ? 'Add Preferred Budget' : 'Edit Preferred Budget'}</Breadcrumb.Item>
                    </Breadcrumb>
                </div>

                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <Form autoComplete="off">
                            <div className="row gy-4">
                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="budgetrange">
                                        <Form.Label>Preferred Min Budget Range*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Preferred Budget Range" value={preferredBudgetInfo?.minBudget} name='minBudget' onChange={getpreferredBudgetInfo} onBlur={(event) => doValidateMinBudget(event.target.value, dispatch)} />
                                        <p className='error-msg'>{minbudgetErrorMessage}</p>
                                    </Form.Group>
                                </div>

                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="description">
                                        <Form.Label>Preferred Max Budget Range*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Preferred Max Budget Range" value={preferredBudgetInfo?.maxBudget} name='maxBudget' onChange={getpreferredBudgetInfo} onBlur={(event) => doValidateMaxBudget(event.target.value, preferredBudgetInfo?.minBudget, dispatch)} />
                                        <p className='error-msg'>{maxbudgetErrorMessage}</p>
                                    </Form.Group>
                                </div>

                                <div className="col-md-6">
                                    <Form.Group className="mb-3" controlId="description">
                                        <Form.Label>Label*</Form.Label>
                                        <Form.Control type="text" placeholder="Enter Label" value={preferredBudgetInfo?.description} name='description' onChange={getpreferredBudgetInfo}
                                        onBlur={() => doValidateLabel(preferredBudgetInfo?.description, dispatch, true)}
                                        />
                                        <p className='error-msg'>{labelErrorMessage}</p>
                                    </Form.Group>
                                </div>
                            </div>

                            <div className="row mt-3 mb-2">
                                <div className="col-md-12">
                                    <div className='d-flex justify-content-center gap-3 mt-3'>
                                        <Button className='close-btn' onClick={handleCancel}>
                                            <span><MdOutlineClose /> Cancel</span>
                                        </Button>
                                        <Button onClick={handleSubmit} disabled={creatpreferredBudgetApiIsloading || editpreferredBudgetApiIsloading} className='submit-btn'><span> {creatpreferredBudgetApiIsloading || editpreferredBudgetApiIsloading ? <Spinner animation="border" size="sm" /> :<><MdOutlineCheck /> {id ? 'Save' : 'Submit'}</>}</span></Button>
                                    </div>
                                </div>
                            </div>

                        </Form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default PreferredBudgetRangeAdd