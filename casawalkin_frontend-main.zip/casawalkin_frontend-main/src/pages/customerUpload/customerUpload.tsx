import React, { useState, useRef, useEffect } from 'react';
import { Button, Form, Modal, Spinner } from 'react-bootstrap';
import { downloadExcel } from '../../utils/commonUtils';
import { useAppDispatch, useAppSelector } from '../../base/hooks/hooks';
import { setExcelFileErrorMessage } from '../../base/reducer/errorMessageReducer';
import { useUsersBulkImportMutation, useFetchSampleFileQuery } from '../../services/apiService/customerUpload/customerUpload';
import { FaCloudUploadAlt } from "react-icons/fa";
import { MdOutlineCheck } from 'react-icons/md';

function CustomerUpload() {
    const [usersInfo, setUsersInfo] = useState<File | null>(null);
    const [xlFileSuccess, setXlFileSuccess] = useState([]);
    const [xlFileFail, setXlFileFail] = useState([]);
    const [updateToSalesforce, setUpdateToSalesforce] = useState(false);
    const [isCheckboxEnabled, setIsCheckboxEnabled] = useState(false);
    const dispatch = useAppDispatch();
    const [show, setShow] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [bulkImportApi, { data: bulkImportApiResponse, error: bulkImportApiError, isLoading: bulkImportApiIsLoading, isSuccess: bulkImportApiIsSuccess }]: any = useUsersBulkImportMutation();
    const { data: sampleFile, error, isLoading: isSampleFileLoading } = useFetchSampleFileQuery();
    const { excelFileErrorMessage }: any = useAppSelector((state) => state.ErrorMessageReducer);

    useEffect(() => {
        if (error) {
            console.error('Error fetching sample file:', error);
        }
    }, [error]);

    const handleClose = () => {
        setXlFileFail([]);
        setXlFileSuccess([]);
        setShow(false);
    }
    const handleShow = () => setShow(true);

    const onSubmit = async (file: File | null) => {
        if (!file) {
            dispatch(setExcelFileErrorMessage("No file selected"));
            return;
        }

        setUsersInfo(file);
        const reader = new FileReader();

        reader.onload = async (event) => {
            if (event.target && event.target.result) {
                const arrayBuffer = event.target.result as ArrayBuffer;
                const blob = new Blob([arrayBuffer], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                });

                const formData = new FormData();
                formData.append('file', blob);
                formData.append('updateToSalesforce', updateToSalesforce.toString());

                try {
                    const response = await bulkImportApi(formData).unwrap();
                    if (response && response.success) {
                        setXlFileFail(response?.data?.failure);
                        setXlFileSuccess(response?.data?.success);
                        dispatch(setExcelFileErrorMessage(""));
                        setUsersInfo(null);
                        setIsCheckboxEnabled(false); // Disable checkbox after submission
                        if (fileInputRef.current) {
                            fileInputRef.current.value = '';
                        }
                        handleShow(); // Show the modal after successful upload
                    }
                } catch (error: any) {
                    dispatch(setExcelFileErrorMessage(error?.data?.error?.message));
                }
            }
        };

        reader.onerror = (event) => {
            if (event.target) {
                console.error("File reading failed:", event.target.error);
            }
        };

        reader.readAsArrayBuffer(file);
    };

    const downloadExcelReport = (type: string) => {
        let dataRes = type === 'success' ? xlFileSuccess : xlFileFail;
        downloadExcel(dataRes, type);
    };

    const getFileData = (event: any) => {
        const file = event.target.files?.[0];
        if (file) {
            if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
                setUsersInfo(file);
                setIsCheckboxEnabled(true); // Enable checkbox when file is selected
                dispatch(setExcelFileErrorMessage(""));
            } else {
                dispatch(setExcelFileErrorMessage("Invalid file type. Only Excel files (xlsx) are allowed"));
            }
        } else {
            dispatch(setExcelFileErrorMessage("Please select an excel file"));
        }
    };

    const downloadSampleExcel = async () => {
        if (sampleFile) {
            const url = window.URL.createObjectURL(sampleFile);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = 'sample.xlsx';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            console.log('Download link created and clicked.');
        } else {
            console.error('Sample file is not available.');
        }
    };

    return (
        <>
            <div className='dashboard-wrapper'>
                <div className='header d-flex w-100 justify-content-between align-items-center mb-3'>
                    <h5 className='page-title'>Customer Upload</h5>
                </div>
                <div className="dashboard-card">
                    <div className="dashboard-card-body">
                        <div className="row justify-content-center">
                            <div className="col-md-6">
                                <div className='upload-box-main'>
                                    <h4>Customer Bulk Import</h4>
                                    <p className="lead">Upload your <b>Excel File</b></p>
                                    <p>
                                        Download Sample <Button className='ml-3' variant="success" size='sm' onClick={downloadSampleExcel} disabled={isSampleFileLoading || !sampleFile}>Download</Button>
                                    </p>

                                    <form id="file-upload-form" className="uploader">
                                        <div className='form-group image-upload'>
                                            <Form.Group controlId="formFile" className="inside-upload-box">
                                                <div className='icon'>
                                                    <FaCloudUploadAlt />
                                                </div>
                                                <Form.Label>Select a Excel File to Upload</Form.Label>
                                                <Form.Control type="file" name='bannersImage'
                                                    onChange={(event) => getFileData(event)}
                                                    accept=".xlsx"
                                                    ref={fileInputRef}
                                                />
                                            </Form.Group>
                                        </div>
                                    </form>
                                    <p className='error-msg'>{excelFileErrorMessage}</p>

                                    <p className='select-file'>{usersInfo ? `Selected File :  ${usersInfo?.name}` : ''}</p>
                                    {isCheckboxEnabled && (
                                        <Form.Group controlId="formUpdateToSalesforce">
                                            <Form.Check
                                                type="checkbox"
                                                label="Update to Salesforce"
                                                checked={updateToSalesforce}
                                                onChange={(e) => setUpdateToSalesforce(e.target.checked)}
                                                disabled={!isCheckboxEnabled}
                                            />
                                        </Form.Group>
                                    )}

                                </div>

                                <Modal
                                    show={show}
                                    onHide={handleClose}
                                    backdrop="static"
                                    keyboard={false}
                                    className='user-upload-modal'
                                >
                                    <Modal.Header className='p-2'>
                                        <h5 className='m-0 px-3 py-2'>Uploaded Customers</h5>
                                    </Modal.Header>
                                    <Modal.Body>
                                        <ul className="list-group">
                                            <li className="list-group-item d-flex justify-content-between align-items-center danger">
                                                Created Customers
                                                <div className='list-status'>
                                                   <span className="badge badge-primary badge-pill mx-3" > {xlFileSuccess?.length || 0}</span>
                                                <Button className='ml-3' variant="success" size='sm' disabled={xlFileSuccess?.length === 0} onClick={() => downloadExcelReport("success")}>Download</Button>
                                                </div>
                                            </li>
                                            <li className="list-group-item d-flex justify-content-between align-items-center">
                                                Failed Customers
                                                <div className='list-status'>
                                                    <span className="badge badge-primary badge-pill mx-3"> {xlFileFail?.length || 0}</span>
                                                    <Button className='ml-3' variant="success" size='sm' disabled={xlFileFail?.length === 0} onClick={() => downloadExcelReport("failed")}>Download</Button>
                                                </div>
                                            </li>
                                        </ul>
                                    </Modal.Body>
                                    <Modal.Footer>
                                        <Button variant="secondary"
                                            onClick={handleClose}
                                        >
                                            Close
                                        </Button>
                                    </Modal.Footer>
                                </Modal>
                            </div>
                            <div className="col-md-12">
                                <div className='footer-btn-upload'>
                                    <Button className='submit-btn btn btn-primary mt-4' variant="primary" onClick={() => onSubmit(usersInfo)} disabled={!usersInfo}><span><MdOutlineCheck /></span>{bulkImportApiIsLoading ? <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" /> : 'Submit'}</Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default CustomerUpload;
