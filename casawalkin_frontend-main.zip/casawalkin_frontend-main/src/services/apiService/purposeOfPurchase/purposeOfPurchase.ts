import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { config } from '../../../config/index'
import { urlConstants } from '../../../constants/urlConstants'

export const PurposeOfPurchaseApi = createApi({
    reducerPath: 'PurposeOfPurchaseApi',
    baseQuery: fetchBaseQuery({
        baseUrl: config().BASE_URL,
        prepareHeaders: (headers: any) => {
            headers.set("Authorization", `Token ${localStorage.getItem('cw-token')}`)
            return headers
        }    }),
    tagTypes: ['purposeOfPurchase'],
    endpoints: (builder) => ({
        createPurposeOfPurchase: builder.mutation<any, any>({
            query: (body: any) => ({
                url: urlConstants.PURPOSE_OF_PURCHASE_CREATE,
                method: 'POST',
                body: body

            }), invalidatesTags: ['purposeOfPurchase']
        }),
      
        getPurposeOfPurchaseList:builder.query<any, void>({
            query: () => ({
                url: urlConstants.PURPOSE_OF_PURCHASE_LIST,
                method: 'GET',
            }),
            providesTags: ['purposeOfPurchase']
        }), 
        editPurposeOfPurchase: builder.mutation<any, any>({
            query: ({body,id}:any) => ({
                url: `${urlConstants.PURPOSE_OF_PURCHASE}/${id}`,
                method: 'PUT',
                body: body

            }), invalidatesTags: ['purposeOfPurchase']
        }),
        getSinglePurposeOfPurchase: builder.query<any,any>({
            query: (id:any) => ({
                url:  `${urlConstants.PURPOSE_OF_PURCHASE}/${id}`,
                method: 'GET',
            }),
            providesTags: ['purposeOfPurchase']
        }), 
         deletePurposeOfPurchase: builder.mutation<any, any>({
            query: (id: any) => ({
                url: `${urlConstants.PURPOSE_OF_PURCHASE}/${id}`,
                method: 'DELETE',

            }), invalidatesTags: ['purposeOfPurchase']
        }),
      
    })

})
export const {
    useCreatePurposeOfPurchaseMutation,
    useGetSinglePurposeOfPurchaseQuery,
    useGetPurposeOfPurchaseListQuery,
    useEditPurposeOfPurchaseMutation,
    useDeletePurposeOfPurchaseMutation
} = PurposeOfPurchaseApi