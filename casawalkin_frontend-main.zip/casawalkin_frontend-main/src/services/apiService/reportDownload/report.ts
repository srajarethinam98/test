import { config } from '../../../config/index';
import { urlConstants } from '../../../constants/urlConstants';
import { doNotify } from '../../../utils/utils';

const downloadFileHelper = async (url: string, dispatch: any) => {
    const headers = {
        headers: {
            Authorization: `Token ${localStorage.getItem('cw-token')}`,
        },
    };

    try {
        const response = await fetch(url, headers);
        if (!response.ok) {
            doNotify('error', 'Failed to download report', dispatch);
            return;
        }
        const blob = await response.blob();
        const fileUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = fileUrl;
        a.download = 'Report.xlsx';
        a.click();
        URL.revokeObjectURL(fileUrl);
    } catch (error) {
        doNotify('error', 'Failed to download report', dispatch);
    }
};

export const downloadFile = (searchPrams: any, dispatch: any) => {
    const url = `${config().BASE_URL}${urlConstants.DOWNLOAD_REPORT}?fromDate=${searchPrams?.startDate}&toDate=${searchPrams?.endDate}&projectId=${searchPrams?.project}&status=${searchPrams?.status}`;
    return downloadFileHelper(url, dispatch);
};

export const downloadReviewReportFile = (searchPrams: any, dispatch: any) => {
    const url = `${config().BASE_URL}${urlConstants.DOWNLOAD_REVIEW_REPORT}?fromDate=${searchPrams?.startDate}&toDate=${searchPrams?.endDate}&projectId=${searchPrams?.project}`;
    return downloadFileHelper(url, dispatch);
};
