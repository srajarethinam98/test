import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { config } from '../../../config/index'
import { urlConstants } from '../../../constants/urlConstants'

export const PreferredUnitApi = createApi({
    reducerPath: 'PreferredUnitApi',
    baseQuery: fetchBaseQuery({
        baseUrl: config().BASE_URL,
        prepareHeaders: (headers: any) => {
            headers.set("Authorization", `Token ${localStorage.getItem('cw-token')}`)
            return headers
        }    }),
    tagTypes: ['preferredUnit'],
    endpoints: (builder) => ({
        createPreferredUnit: builder.mutation<any, any>({
            query: (body: any) => ({
                url: urlConstants.PREFERRED_UNIT_CREATE,
                method: 'POST',
                body: body

            }), invalidatesTags: ['preferredUnit']
        }),
      
        getPreferredUnitList:builder.query<any, void>({
            query: () => ({
                url: urlConstants.PREFERRED_UNIT_LIST,
                method: 'GET',
            }),
            providesTags: ['preferredUnit']
        }), 
        editPreferredUnit: builder.mutation<any, any>({
            query: ({body,id}:any) => ({
                url: `${urlConstants.PREFERRED_UNIT}/${id}`,
                method: 'PUT',
                body: body

            }), invalidatesTags: ['preferredUnit']
        }),
        getSinglePreferredUnit: builder.query<any,any>({
            query: (id:any) => ({
                url:  `${urlConstants.PREFERRED_UNIT}/${id}`,
                method: 'GET',
            }),
            providesTags: ['preferredUnit']
        }), 
         deletePreferredUnit: builder.mutation<any, any>({
            query: (id: any) => ({
                url: `${urlConstants.PREFERRED_UNIT}/${id}`,
                method: 'DELETE',

            }), invalidatesTags: ['preferredUnit']
        }),
      
    })

})
export const {
    useCreatePreferredUnitMutation,
    useGetSinglePreferredUnitQuery,
    useGetPreferredUnitListQuery,
    useEditPreferredUnitMutation,
    useDeletePreferredUnitMutation
} = PreferredUnitApi