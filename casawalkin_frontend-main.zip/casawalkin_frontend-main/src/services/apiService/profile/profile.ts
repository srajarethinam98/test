
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { config } from '../../../config'
import { urlConstants } from '../../../constants/urlConstants'

export const profileApi = createApi({
    reducerPath: 'profileApi',
    baseQuery: fetchBaseQuery({
        baseUrl: config().BASE_URL,
        prepareHeaders: (headers: any) => {
            headers.set("Authorization", `Token ${localStorage.getItem('cw-token')}`)
            return headers
        }
    }),
    
    tagTypes: ['profile'],
    endpoints: (builder) => ({
        getProfile: builder.query<any, void>({
            query: () => ({
                url: urlConstants.PROFILE,
                method: 'GET',
            }),
            providesTags: ['profile']
        })

        
    })

})

export const { useGetProfileQuery} = profileApi