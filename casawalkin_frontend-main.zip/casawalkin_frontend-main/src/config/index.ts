export const config = () => {
  let BASE_URL: string | any;
  BASE_URL = process.env.REACT_APP_API_URL
  return {
    BASE_URL
  };
};
