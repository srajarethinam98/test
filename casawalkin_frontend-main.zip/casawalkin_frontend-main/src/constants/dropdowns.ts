import moment from "moment"
type optionType = {
    value: string;
    label: string;
}

export type searchParamsType = {
    searchString: string,
    currentPage: number,
    startDate: string;
    endDate: string;
    selectedStartDate: any;
    selectedEndDate: any;
    svStatus: string,
    fls: string,
    searchType: any
}
export const searchParamsInitialData: searchParamsType = {
    currentPage: 1,
    searchString: '',
    startDate: '',
    endDate: '',
    selectedStartDate: moment(),
    selectedEndDate: moment(),
    svStatus: '',
    fls:'',
    searchType: ''
}

export const sfStatusList: optionType[] = [
    { value: 'New', label: 'New' },
    { value: 'Incoming', label: 'Open' },
    { value: 'Open', label:'Incoming'},
    { value: 'open', label:'Incoming'},
    { value: 'Prospect', label: 'Qualified' },
    { value: 'Qualified', label: 'Prospect'},
    { value: 'Site Visit Scheduled', label: 'Site Visit Booked' },
    { value: 'Site Visit Happened', label: 'Site Visit Happened' },
    { value: 'Lost', label: 'Unqualified' },
    { value : 'Unqualified', label : 'Lost'},
    { value : 'Site Visit Booked' , label: 'Site Visit Booked'},
    { value: 'booked' , label: 'booked'}    
]

export const salesRoles: optionType[] = [
    { value: 'svc', label: 'SVC' },
    { value: 'svctl', label: 'SVC TL' },
    { value: 'fls', label: 'FLS' },
    { value: 'flstl', label: 'FLS TL' },
]

export const leadStatusList: optionType[] = [
    { value: 'New', label: 'New' },
    { value: 'Incoming', label: 'Incoming' },
    { value: 'Prospect', label: 'Prospect' },
    { value: 'Site Visit Scheduled', label: 'Site Visit Scheduled' },
    { value: 'Site Visit Happened', label: 'Site Visit Happened' },
    { value: 'Lost', label: 'Lost' },
]
export const svStatusList = [
    { value: 'Scheduled', label: 'Scheduled' },
    { value: 'Not Scheduled', label: 'Not Scheduled' },
    { value: 'Revisit', label: 'Revisit' }
];