export default {
    emptyField: 'Kindly enter your',
    invalidEmail: 'Email is not valid',
    emptypassword: "Kindly enter your password",
    invalidPassword: 'Password must contain at least 8 characters.',
    invalidMobile: "Mobile No should contain 10 numeric digits",
    select: 'Kindly select',
    invalidBhk: 'Preferred BHK should be numeric and not equal to 0',
    startsWithSpace: 'field should not start with space',
    startsWithSpaceAndString: 'should be alphanumeric and not begin with a space',
    fillAllRequiredFields: 'Please fill all the required details before proceeding to the next step.',
    numeric: 'should be positive numeric',
    alphanumeric: 'should be positive alpha numeric'
}