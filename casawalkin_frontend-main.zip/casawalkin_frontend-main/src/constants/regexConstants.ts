export const regex = {
    emailRegex:/^([a-zA-Z0-9])(([a-zA-Z0-9])*([._-])?([a-zA-Z0-9]))*@(([a-zA-Z0-9\-])+(\.))+([a-zA-Z]{2,4})+$/i,
    mobileRegex: /^\d{10}$/,
    BHKRegex: /^[1-9]\d*$/,
    numericRegex: /^\d+$/,
    stringRegex : /^[a-zA-Z\s]+$/,
    budgetRangeRegex : /^(0|[1-9]\d*)(\.\d+)?([a-zA-Z]*)$/i,
    preferredSize: /^(0|[1-9]\d*)([a-zA-Z]*)$/i,
    spString: /^[a-zA-Z0-9\s\W]*$/i,
    commonRegex : /^[a-zA-Z0-9 ]*$/i,
}