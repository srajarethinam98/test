import { useEffect, useLayoutEffect, useState } from 'react';
import "./header.scss";
import { Outlet } from 'react-router-dom';
import classNames from 'classnames';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { OverlayTrigger, Tooltip, Placeholder, Container, Nav, Navbar } from 'react-bootstrap';
import logo from '../../../assets/cg-logo-nobg.png';
import logosm from '../../../assets/cg-logo-small.svg';
import { PATH } from '../../../constants/path';
import { useAppSelector, useCustomNavigate } from '../../../base/hooks/hooks';
import Userimg from '../../../assets/profile-img.png';
import { logoutHandler } from '../../../utils/commonUtils';
import { checkPermission, higlightPath, modulesList, showParent } from './headerController';
import { SCREEN_CODES } from "../../../constants/screensConstants";
import { useGetRolePermissionsQuery } from '../../../services/apiService/roles/roles';
import { useGetProfileQuery } from '../../../services/apiService/profile/profile';
import Sidebarloader from '../../../pages/miscellanious/sidebarLoader/index'
import { CiViewList } from "react-icons/ci";
import { MdOutlineDashboard, MdOutlineSensorOccupied } from 'react-icons/md';
import { GoCodeSquare, GoProject } from "react-icons/go";
import { PiUserCircleGear, PiCaretDownLight, PiUserSquareLight, PiUsersThree } from "react-icons/pi";
import { LiaUserTieSolid, LiaUserSolid } from "react-icons/lia";
import { GrUserPolice, GrStatusUnknown } from "react-icons/gr";
import { LuPersonStanding } from "react-icons/lu";
import { TbBrandUnity, TbReport, TbUpload } from "react-icons/tb";
import { FaRegMoneyBill1 } from "react-icons/fa6";
import { CgSize } from "react-icons/cg";
import { BiPurchaseTagAlt } from "react-icons/bi";
import { AiOutlineMenuFold, AiOutlineForm, AiOutlineMenuUnfold } from "react-icons/ai";

const Sidebar = () => {
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);
  const [highlight, setHighlight]: any = useState("");
  const [module, setModule] = useState<string>("");
  const [imgsLoaded, setImgsLoaded] = useState(false)

  const navigate = useCustomNavigate();
  const { unAuthorized } = useAppSelector((state) => state.ErrorMessageReducer)
  const { data: permissionsList, isLoading: permissionsListIsLoading } = useGetRolePermissionsQuery()
  const { data: profileResponse, isError: getProfileApiIsError, error: getProfileApiError, isLoading: getProfileApiIsLoading }: any = useGetProfileQuery()

  const openNav = () => setIsSidebarExpanded(!isSidebarExpanded)

  function handleResize() {
    if (window.innerWidth <= 992) {
        setIsSidebarExpanded(false);
    } else {
        setIsSidebarExpanded(true);
    }
  }

  const doNavigate = (Path: any) => {
    let url: any = window.location.pathname.split('=')
    higlightPath(Path, setHighlight, setModule, navigate)
    navigate(Path)
  }

  const handleDynamicPath = (moduleName: any) => {
    module === moduleName ? setModule('') : setModule(moduleName)
  };

  useLayoutEffect(() => {
    const token: any = localStorage.getItem('cw-token')
    if (!token) {
      logoutHandler(navigate)
    }
  }, [])

  useEffect(() => {
    window.addEventListener('resize', handleResize);
    if (permissionsListIsLoading) {
      handleResize()
    }
    let url: any = window.location.pathname.split('=')
    let ogUrl = url.length > 0 && url[0];
    higlightPath(ogUrl, setHighlight, setModule, navigate)

    if (getProfileApiIsError && getProfileApiError?.status === 401) {
      logoutHandler(navigate)
    }

    if (unAuthorized) {
      logoutHandler(navigate)
    }
  }, [getProfileApiError, unAuthorized, window.location.pathname])

  return (
    <div>
      <div id="mySidebar" style={{ width: isSidebarExpanded ? '224px' : '70px' }} className={classNames('sidebar', { 'collapsed': !isSidebarExpanded })}>
        <div className='demo-logo-vertical'>
          <a href='#'>
            <figure className='logo-expanded'>
              <img src={logo} loading="lazy" alt="Logo" />
            </figure>
            <figure className='logo-collapsed'>
              <img src={logosm} loading="lazy" alt="Logo" />
            </figure>
          </a>
        </div>

        {!permissionsListIsLoading ? <ul className='navList'>
          {checkPermission(permissionsList, SCREEN_CODES.DASHBOARD) &&
            <li className={highlight === PATH.DASHBOARD ? 'active' : ''} onClick={() => doNavigate(PATH.DASHBOARD)}>
              <div className='d-flex align-items-center h-50 px-3'>
                {isSidebarExpanded ? (
                  <>
                    <MdOutlineDashboard onClick={() => doNavigate(PATH.DASHBOARD)} />
                    <span onClick={() => doNavigate(PATH.DASHBOARD)}>Dashboard</span>
                  </>
                ) : (
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Dashboard
                    </Tooltip>
                  }>
                    <div>
                      <MdOutlineDashboard />
                    </div>
                  </OverlayTrigger>
                )}
              </div>
            </li>
          }

          {showParent('acquisition', permissionsList) ? <li onClick={() => handleDynamicPath(modulesList[0])} className={module === modulesList[0] ? 'active' : ''}>
            <div className='d-flex align-items-center h-50 px-3'>
              {isSidebarExpanded ? <GoCodeSquare /> : <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                <Tooltip id={`tooltip-right`}>
                  Acquisition
                </Tooltip>
              }>
                <div>
                  <GoCodeSquare />
                </div>
              </OverlayTrigger>}
              {isSidebarExpanded && <span>Acquisition<span className='down-arrow'><PiCaretDownLight className='react-icon' /></span></span>}
            </div>
            {module === modulesList[0] && (
              <ul id="list" className='submenu' onClick={(e) => e.stopPropagation()}>
                {checkPermission(permissionsList, SCREEN_CODES.AQUISITION_LIST) && <li className={highlight === PATH.ACQUISITION_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.ACQUISITION_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Acquisition List
                    </Tooltip>
                  }>
                    <div>
                      <CiViewList />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Acquisition List</span></a></li>}
                {checkPermission(permissionsList, SCREEN_CODES.AQUISITION_FORM) && <li className={highlight === PATH.ACQUISITION_FORM ? 'active' : ''} onClick={() => doNavigate(PATH.ACQUISITION_FORM)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Acquisition Form
                    </Tooltip>
                  }>
                    <div>
                      <AiOutlineForm />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Acquisition Form</span></a></li>}
              </ul>
            )}
          </li> : null}

          {showParent('userConfig', permissionsList) ?
            <li onClick={() => handleDynamicPath(modulesList[1])} className={module === modulesList[1] ? 'active' : ''}>
              <div className='d-flex align-items-center h-50 px-3'>
                {isSidebarExpanded ? <PiUserCircleGear /> : <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                  <Tooltip id={`tooltip-right`}>
                    UserConfig
                  </Tooltip>
                }>
                  <div>
                    <PiUserCircleGear />
                  </div>
                </OverlayTrigger>}
                {isSidebarExpanded && <span>UserConfig<span className='down-arrow'><PiCaretDownLight className='react-icon' /></span></span>}
              </div>

              {module === modulesList[1] && (
                <ul id="list" className='submenu' onClick={(e) => e.stopPropagation()}>
                  {checkPermission(permissionsList, SCREEN_CODES.DEPARTMENT) && <li className={highlight === PATH.DEPARTMENT_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.DEPARTMENT_LIST)}><a><span className='sub-icon'>
                    <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                      <Tooltip id={`tooltip-right`}>
                        Department
                      </Tooltip>
                    }>
                      <div>
                        <PiUserSquareLight />
                      </div>
                    </OverlayTrigger></span> <span className='sub-title'>Department</span></a></li>}
                  {checkPermission(permissionsList, SCREEN_CODES.FIELD_EMPLOYEES) && <li className={highlight === PATH.FIELD_EMPLOYEES_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.FIELD_EMPLOYEES_LIST)}><a><span className='sub-icon'>
                    <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                      <Tooltip id={`tooltip-right`}>
                        Field Employees
                      </Tooltip>
                    }>
                      <div>
                        <PiUsersThree />
                      </div>
                    </OverlayTrigger></span> <span className='sub-title'>Field Employees</span></a></li>}
                  {checkPermission(permissionsList, SCREEN_CODES.ROLE) && <li className={highlight === PATH.ROLES_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.ROLES_LIST)}><a><span className='sub-icon'>
                    <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                      <Tooltip id={`tooltip-right`}>
                        Role
                      </Tooltip>
                    }>
                      <div>
                        <LiaUserTieSolid />
                      </div>
                    </OverlayTrigger></span> <span className='sub-title'>Role</span></a></li>}
                  {checkPermission(permissionsList, SCREEN_CODES.USER) && <li className={highlight === PATH.USERS_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.USERS_LIST)}><a><span className='sub-icon'>
                    <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                      <Tooltip id={`tooltip-right`}>
                        User
                      </Tooltip>
                    }>
                      <div>
                        <LiaUserSolid />
                      </div>
                    </OverlayTrigger></span> <span className='sub-title'>User</span></a></li>}
                </ul>
              )}

            </li> : null}

          {showParent('master', permissionsList) ? <li onClick={() => handleDynamicPath(modulesList[2])} className={module === modulesList[2] ? 'active' : ''}>
            <div className='d-flex align-items-center h-50 px-3'>
              {isSidebarExpanded ? <GrUserPolice /> : <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                <Tooltip id={`tooltip-right`}>
                  Master
                </Tooltip>
              }>
                <div>
                  <GrUserPolice />
                </div>
              </OverlayTrigger>}
              {isSidebarExpanded && <span>Master<span className='down-arrow'><PiCaretDownLight className='react-icon' /></span></span>}
            </div>

            {module === modulesList[2] && (
              <ul id="list" className='submenu' onClick={(e) => e.stopPropagation()}>
                {checkPermission(permissionsList, SCREEN_CODES.AGE) && <li className={highlight === PATH.AGE_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.AGE_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Age
                    </Tooltip>
                  }>
                    <div>
                      <LuPersonStanding />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Age</span></a></li>}
                {checkPermission(permissionsList, SCREEN_CODES.KNOW_ABOUT_US) && <li className={highlight === PATH.KNOW_ABOUT_US_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.KNOW_ABOUT_US_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Know About Us
                    </Tooltip>
                  }>
                    <div>
                      <GrStatusUnknown />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Know About Us</span></a></li>}
                {checkPermission(permissionsList, SCREEN_CODES.OCCUPATION) && <li className={highlight === PATH.OCCUPATION_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.OCCUPATION_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Occupation
                    </Tooltip>
                  }>
                    <div>
                      <MdOutlineSensorOccupied />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Occupation</span></a></li>}
                {checkPermission(permissionsList, SCREEN_CODES.PREFERRED_UNIT) && <li className={highlight === PATH.PREFERRED_UNITS_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.PREFERRED_UNITS_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Preffered Units
                    </Tooltip>
                  }>
                    <div>
                      <TbBrandUnity />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Preffered Units</span></a></li>}
                {checkPermission(permissionsList, SCREEN_CODES.PREFERRED_BUDGET) && <li className={highlight === PATH.PREFERRED_BUDGET_RANGE_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.PREFERRED_BUDGET_RANGE_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Preffered Budget Range
                    </Tooltip>
                  }>
                    <div>
                      <FaRegMoneyBill1 />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Preffered Budget Range</span></a></li>}
                {checkPermission(permissionsList, SCREEN_CODES.PREFERRED_SIZE) && <li className={highlight === PATH.PREFERRED_SIZE_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.PREFERRED_SIZE_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Preffered Size
                    </Tooltip>
                  }>
                    <div>
                      <CgSize />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Preffered Size</span></a></li>}
                {checkPermission(permissionsList, SCREEN_CODES.PURPOSE_OF_PURCHASE) && <li className={highlight === PATH.PURPOSE_OF_PURCHASE_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.PURPOSE_OF_PURCHASE_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Purpose Of Purchase
                    </Tooltip>
                  }>
                    <div>
                      <BiPurchaseTagAlt />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Purpose Of Purchase</span></a></li>}
                {checkPermission(permissionsList, SCREEN_CODES.PROJECT) && <li className={highlight === PATH.PROJECT_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.PROJECT_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Project
                    </Tooltip>
                  }>
                    <div>
                      <GoProject />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Project</span></a></li>}
                  
                  {checkPermission(permissionsList, SCREEN_CODES.CUSTOMER_REVIEW_FORM) &&
                  <li className={highlight === PATH.CUSTOMER_REVIEW_FORM_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.CUSTOMER_REVIEW_FORM_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Customer Review Form
                    </Tooltip>
                  }>
                    <div>
                      <GoProject />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Customer Review Form</span></a></li>}
                  {/* {checkPermission(permissionsList, SCREEN_CODES.CUSTOMER_REVIEW_FORM) && */}
                  <li className={highlight === PATH.AREAOFRESIDENT_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.AREAOFRESIDENT_LIST)}><a><span className='sub-icon'>
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Area of Current Residence
                    </Tooltip>
                  }>
                    <div>
                      <GoProject />
                    </div>
                  </OverlayTrigger></span> <span className='sub-title'>Area of Current Residence</span></a></li>
                  {/* } */}

                  
                {/* {checkPermission(permissionsList, SCREEN_CODES.STATUS) && <li className={highlight===PATH.STATUS_LIST ? 'active' : ''} onClick={() => doNavigate(PATH.STATUS_LIST)}><a>Status</a></li>} */}
              </ul>
            )}
          </li> : null}

          {checkPermission(permissionsList, SCREEN_CODES.REPORT) &&
            <li onClick={() => handleDynamicPath('reports')} className={highlight === PATH.REPORT_LIST ? 'active' : ''}>
              <div className='d-flex align-items-center h-50 px-3'>
                {isSidebarExpanded ? <TbReport onClick={() => doNavigate(PATH.REPORT_LIST)} /> :
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Reports
                    </Tooltip>
                  }>
                    <div>
                      <TbReport onClick={() => doNavigate(PATH.REPORT_LIST)} />
                    </div>
                  </OverlayTrigger>
                }
                {isSidebarExpanded && <span onClick={() => doNavigate(PATH.REPORT_LIST)}>Reports<span></span></span>}
              </div>
            </li>}
            {checkPermission(permissionsList, SCREEN_CODES.CUSTOMER_REVIEW_REPORT) &&
            <li onClick={() => handleDynamicPath('reviewReports')} className={highlight === PATH.CUSTOMER_REVIEW_REPORT ? 'active' : ''}>
              <div className='d-flex align-items-center h-50 px-3'>
                {isSidebarExpanded ? <TbReport onClick={() => doNavigate(PATH.CUSTOMER_REVIEW_REPORT)} /> :
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Review Reports
                    </Tooltip>
                  }>
                    <div>
                      <TbReport onClick={() => doNavigate(PATH.CUSTOMER_REVIEW_REPORT)} />
                    </div>
                  </OverlayTrigger>
                }
                {isSidebarExpanded && <span onClick={() => doNavigate(PATH.CUSTOMER_REVIEW_REPORT)}>Review Reports<span></span></span>}
              </div>
            </li>
            }
            {/* {checkPermission(permissionsList, SCREEN_CODES.customerUpload) && */}
            <li onClick={() => handleDynamicPath('customerUpload')} className={highlight === PATH.CUSTOMER_UPLOAD ? 'active' : ''}>
              <div className='d-flex align-items-center h-50 px-3'>
                {isSidebarExpanded ? <TbUpload onClick={() => doNavigate(PATH.CUSTOMER_UPLOAD)} /> :
                  <OverlayTrigger trigger={['hover', 'focus']} placement="right" overlay={
                    <Tooltip id={`tooltip-right`}>
                      Customer Upload
                    </Tooltip>
                  }>
                    <div>
                      <TbUpload onClick={() => doNavigate(PATH.CUSTOMER_UPLOAD)} />
                    </div>
                  </OverlayTrigger>
                }
                {isSidebarExpanded && <span onClick={() => doNavigate(PATH.CUSTOMER_UPLOAD)}>Customer Upload<span></span></span>}
              </div>
            </li>
            {/* } */}

        </ul> : <Sidebarloader />
        }
      </div>

      <div id="main" style={{ marginLeft: isSidebarExpanded ? '224px' : '70px' }}>
        <header className={`layout-header`}>
          <button className="openbtn"
          aria-label={isSidebarExpanded ? "Collapse Menu" : "Expand Menu"}

           onClick={openNav}>
            {isSidebarExpanded ? <AiOutlineMenuFold /> : <AiOutlineMenuUnfold />}
          </button>

          <div className="header-item d-flex align-items-center">
            <Navbar expand="lg" className="bg-body-tertiary">
              <Container className='p-0'>
                <Navbar id="basic-navbar-nav">
                  <Nav className="me-auto">
                    <NavDropdown title={
                      <span className='d-flex user-dropdown'>
                        <img className='user-image' alt="profile" loading="lazy" src={Userimg} />
                        <div className='user-name'>
                          {
                            !getProfileApiIsLoading ?
                              <>
                                <p>{profileResponse?.data?.user?.userName}</p>
                                <label>{profileResponse?.data?.user?.email}</label>
                              </> : <>
                                <div style={{ width: '10rem', backgroundColor: 'transparent', display: "flex", flexDirection: 'column' }}>
                                  <Placeholder animation="glow">
                                    <Placeholder xs={6} />
                                  </Placeholder>
                                  <Placeholder animation="glow">
                                    <Placeholder xs={10} />
                                  </Placeholder>
                                </div>
                              </>
                          }
                        </div>
                      </span>
                    }
                      id="basic-nav-dropdown">
                      <NavDropdown.Item >Role:{profileResponse?.data?.user?.role?.title}</NavDropdown.Item>
                      {!profileResponse?.data?.user?.role?.adminRole &&
                        <NavDropdown.Item >Project-{profileResponse?.data?.user?.project}</NavDropdown.Item>}
                      <NavDropdown.Item onClick={() => logoutHandler(navigate)}>Logout</NavDropdown.Item>
                    </NavDropdown>
                  </Nav>
                </Navbar>
              </Container>
            </Navbar>
          </div>
        </header>

        <section className='content'>
          <Outlet />
        </section>

      </div >
    </div >
  );
};

export default Sidebar;
