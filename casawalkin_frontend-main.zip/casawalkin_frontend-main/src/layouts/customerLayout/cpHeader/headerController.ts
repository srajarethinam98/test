import { PATH } from "../../../constants/path";
import { SCREEN_CODES } from "../../../constants/screensConstants";
export const modulesList = ['acquisition', 'userConfig', 'master', 'reports', 'reviewReports', 'customerUpload']

export const checkPermission = (permissionList: any, screensName: any,) => {
    const screenObj = permissionList?.data?.permissions?.find((activeList: any) => activeList.screenCode === screensName);
    return screenObj?.isSelected ? true : false;
}
export const higlightPath = (dynamcPath: any, setHighlight: any, setModule: any, navigate: any) => {
    const path = dynamcPath.split('/')
    switch (dynamcPath) {
        case PATH.DASHBOARD:
            setHighlight(PATH.DASHBOARD);
            setModule("")
            break;

        case PATH.ACQUISITION_LIST:
        case "/acquisition/acquisition-list/acquisition-assign/":
            setHighlight(PATH.ACQUISITION_LIST);
            setModule(modulesList[0])
            break;

        case PATH.ACQUISITION_FORM:
        case "/acquisition/edit-acquisition/":
            setHighlight(PATH.ACQUISITION_FORM);
            setModule(modulesList[0])
            break;

        case PATH.ACQUISITION_FEEDBACK:
            setHighlight(PATH.ACQUISITION_FEEDBACK);
            setModule(modulesList[0])
            break;

        case PATH.DEPARTMENT_LIST:
        case PATH.DEPARTMENT_ADD:
        case "/department/edit-department/":
            setHighlight(PATH.DEPARTMENT_LIST);
            setModule(modulesList[1])
            break;

        case PATH.ROLES_LIST:
        case PATH.ADD_ROLE:
        case "/role/edit-role/":
            setHighlight(PATH.ROLES_LIST);
            setModule(modulesList[1])
            break;

        case PATH.USERS_LIST:
        case PATH.ADD_USER:
        case "/user/edit-user/":
            setHighlight(PATH.USERS_LIST);
            setModule(modulesList[1])
            break;

        case PATH.FIELD_EMPLOYEES_LIST:
        case PATH.FIELD_EMPLOYEES_ADD:
        case "/field-employees/edit-employee/":
            setHighlight(PATH.FIELD_EMPLOYEES_LIST);
            setModule(modulesList[1])
            break;

        case PATH.AGE_LIST:
        case PATH.AGE_ADD:
        case "/age/edit-age/":
            setHighlight(PATH.AGE_LIST);
            setModule(modulesList[2])
            break;

        case PATH.KNOW_ABOUT_US_LIST:
        case PATH.KNOW_ABOUT_US_ADD:
        case "/knowAboutUs/edit-knowAboutUs/":
            setHighlight(PATH.KNOW_ABOUT_US_LIST);
            setModule(modulesList[2])
            break;

        case PATH.OCCUPATION_LIST:
        case PATH.OCCUPATION_ADD:
        case "/occupation/edit-occupation/":
            setHighlight(PATH.OCCUPATION_LIST);
            setModule(modulesList[2])
            break;

        case PATH.PREFERRED_UNITS_LIST:
        case PATH.PREFERRED_UNITS_ADD:
        case "/preferred-units/edit-unit/":
            setHighlight(PATH.PREFERRED_UNITS_LIST);
            setModule(modulesList[2])
            break;

        case PATH.PREFERRED_BUDGET_RANGE_LIST:
        case PATH.PREFERRED_BUDGET_RANGE_ADD:
        case "/budget/edit-budget/":
            setHighlight(PATH.PREFERRED_BUDGET_RANGE_LIST);
            setModule(modulesList[2])
            break;

        case PATH.PREFERRED_SIZE_LIST:
        case PATH.PREFERRED_SIZE_ADD:
        case "/preferred-size/edit-size/":
            setHighlight(PATH.PREFERRED_SIZE_LIST);
            setModule(modulesList[2])
            break;

        case PATH.PURPOSE_OF_PURCHASE_LIST:
        case PATH.PURPOSE_OF_PURCHASE_ADD:
        case "/purpose-of-purchase/edit-purpose/":
            setHighlight(PATH.PURPOSE_OF_PURCHASE_LIST);
            setModule(modulesList[2])
            break;

        case PATH.PROJECT_LIST:
        case PATH.PROJECT_ADD:
        case "/project/edit-project/":
            setHighlight(PATH.PROJECT_LIST);
            setModule(modulesList[2])
            break;

        case PATH.STATUS_LIST:
        case PATH.STATUS_ADD:
        case "/status/edit-status/":
            setHighlight(PATH.STATUS_LIST);
            setModule(modulesList[2])
            break;
        case PATH.REPORT_LIST:
            setHighlight(PATH.REPORT_LIST);
            setModule(modulesList[3])
            break;
        case "/existing-lead/":
                setHighlight(PATH.EXISTING_LEAD);
                setModule(modulesList[0])
                break;

        case PATH.CUSTOMER_REVIEW_FORM_LIST:
        case PATH.CUSTOMER_REVIEW_FORM_ADD:
        case "/customer-review-form/edit-review-form/":
            setHighlight(PATH.CUSTOMER_REVIEW_FORM_LIST);
            setModule(modulesList[2])
            break;

        case PATH.CUSTOMER_REVIEW_REPORT:
        case "/customer-review-report":
            setHighlight(PATH.CUSTOMER_REVIEW_REPORT);
            setModule(modulesList[4])
            break;   

        case PATH.AREAOFRESIDENT_ADD:
            case PATH.AREAOFRESIDENT_LIST:
            case "/area-of-residence/edit-area-of-residence/":
                setHighlight(PATH.AREAOFRESIDENT_LIST);
                setModule(modulesList[2])
                break;  
        
        case PATH.CUSTOMER_UPLOAD:
            setHighlight(PATH.CUSTOMER_UPLOAD);
            setModule(modulesList[5])
            break;

            default:
            navigate('/page-not-found')

    }
}

export const showParent = (parent: string, permissionsList: any) => {
    switch (parent) {
        case "acquisition":
            return checkPermission(permissionsList, SCREEN_CODES.AQUISITION_LIST) || checkPermission(permissionsList, SCREEN_CODES.AQUISITION_FORM)
        case "userConfig":
            return checkPermission(permissionsList, SCREEN_CODES.DEPARTMENT) || checkPermission(permissionsList, SCREEN_CODES.ROLE) ||
                checkPermission(permissionsList, SCREEN_CODES.USER) || checkPermission(permissionsList, SCREEN_CODES.FIELD_EMPLOYEES)
        case "master":
            return checkPermission(permissionsList, SCREEN_CODES.AGE) || checkPermission(permissionsList, SCREEN_CODES.KNOW_ABOUT_US) ||
                checkPermission(permissionsList, SCREEN_CODES.OCCUPATION) || checkPermission(permissionsList, SCREEN_CODES.PREFERRED_UNIT) ||
                checkPermission(permissionsList, SCREEN_CODES.PREFERRED_BUDGET) || checkPermission(permissionsList, SCREEN_CODES.PREFERRED_SIZE) ||
                checkPermission(permissionsList, SCREEN_CODES.PURPOSE_OF_PURCHASE) || checkPermission(permissionsList, SCREEN_CODES.PROJECT) ||
                checkPermission(permissionsList, SCREEN_CODES.CUSTOMER_REVIEW_FORM)
    }
}