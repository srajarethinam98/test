import CpHeader from '../customerLayout/cpHeader/index'

function Index (){
    return (
        <>
            <CpHeader/>
        </>
    )
}
export default Index